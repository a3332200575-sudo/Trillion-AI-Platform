# TrillionAI Design Philosophy

## Design Direction: Futuristic Minimalism with Precision Engineering

**Theme**: A premium, forward-thinking platform that embodies technological sophistication and financial confidence. The design bridges cutting-edge AI innovation with accessible, trustworthy automation.

**Design Movement**: Bauhaus meets contemporary fintech—clean geometry, purposeful typography, and strategic use of color to convey power and precision without visual clutter.

## Core Principles

1. **Precision Over Decoration**: Every element serves a function. Minimal ornamentation, maximum clarity.
2. **Hierarchical Clarity**: Information architecture guides users intuitively through complex concepts.
3. **Technological Confidence**: Design language reflects advanced AI and automation capabilities without appearing intimidating.
4. **Scalability**: Visual system scales from hero sections to detailed dashboards seamlessly.

## Color Philosophy

- **Primary**: Deep Indigo (`#1a1f3a`) — represents stability, intelligence, and trust in financial/tech sectors.
- **Accent**: Vibrant Cyan (`#00d9ff`) — symbolizes innovation, energy, and real-time automation.
- **Secondary**: Soft Gray (`#f5f7fa`) — clean backgrounds that emphasize content.
- **Tertiary**: Gold (`#ffd700`) — highlights premium features and high-value opportunities.

**Emotional Intent**: Trustworthy yet innovative; professional yet approachable.

## Layout Paradigm

- **Asymmetric Hero**: Large, bold headline paired with a subtle animated visualization on the right.
- **Card-Based Solutions Grid**: Five solutions displayed as interactive cards with hover depth effects.
- **Dashboard Mockup Section**: A realistic dashboard preview showing how "Money Machines" operate.
- **Staggered Content Blocks**: Alternating left-right layouts for solution deep-dives to maintain visual rhythm.

## Signature Elements

1. **Animated Circuit Patterns**: Subtle SVG animations showing interconnected nodes and flows—representing integration automation.
2. **Gradient Overlays**: Strategic use of indigo-to-cyan gradients on hero sections and CTAs.
3. **Floating Cards**: Solution cards with slight elevation and shadow, responding to hover with scale and glow effects.

## Interaction Philosophy

- **Smooth Transitions**: All state changes (hover, click, scroll) use 300ms ease-out curves.
- **Micro-interactions**: Buttons scale on press (0.97 scale), cards lift on hover, counters animate when visible.
- **Scroll-Triggered Reveals**: Content fades in and slides up as users scroll—creating a sense of progressive discovery.

## Animation Guidelines

- Hero section: Subtle parallax on scroll (background moves slower than foreground).
- Solution cards: Scale 1.05 and add glow shadow on hover (150ms ease-out).
- CTA buttons: Press animation (scale 0.97, 100ms), hover glow effect (cyan shadow).
- Counter animations: Numbers increment when scrolled into view (1s duration).
- Entrance animations: Elements fade in + slide up (200ms stagger per item).

## Typography System

- **Display Font**: Poppins Bold (700) — headlines, hero text, solution titles.
- **Heading Font**: Poppins SemiBold (600) — section headers, card titles.
- **Body Font**: Inter Regular (400) — body text, descriptions, metadata.
- **Accent Font**: Poppins Medium (500) — CTAs, badges, highlights.

**Hierarchy**:
- H1: 56px, Poppins 700 (hero headline)
- H2: 36px, Poppins 600 (section headers)
- H3: 24px, Poppins 600 (card titles)
- Body: 16px, Inter 400 (descriptions)
- Small: 14px, Inter 400 (metadata, secondary text)

## Brand Essence

**Positioning**: TrillionAI is the autonomous integration platform for enterprises building trillion-dollar "money machines"—where AI agents orchestrate complex workflows without human intervention.

**Personality Adjectives**: Visionary, Trustworthy, Relentless

## Brand Voice

- **Headlines**: Bold, confident, action-oriented. Examples: "Automate Your Trillion-Dollar Opportunity" | "Let AI Agents Build Your Money Machine"
- **CTAs**: Direct, outcome-focused. Examples: "Launch Your Machine" | "Deploy Autonomous Integration"
- **Microcopy**: Clear, technical but accessible. Avoid generic filler like "Get started today"—instead: "Configure your first agent"

## Wordmark & Logo

**Logo Concept**: A stylized circuit node with three interconnected paths forming a triangle—representing the trinity of automation, integration, and AI. The symbol is bold, geometric, and works at any scale. Color: Gradient from indigo to cyan.

**Wordmark**: "TrillionAI" in Poppins Bold, with the "AI" portion in cyan to emphasize the artificial intelligence aspect.

## Signature Brand Color

**Cyan (`#00d9ff`)** — Unmistakably TrillionAI. Used for accents, CTAs, hover states, and key visual elements. It represents the real-time, always-on nature of autonomous agents.

## Style Decisions

- **Spacing**: Use 8px grid system (8, 16, 24, 32, 48, 64px).
- **Border Radius**: 12px for cards, 8px for buttons, 4px for inputs.
- **Shadows**: Soft shadows (0 4px 12px rgba(0, 0, 0, 0.1)) for depth; glow shadows (0 0 20px rgba(0, 217, 255, 0.3)) for interactive states.
- **Backdrop Blur**: 10px blur for overlays and floating elements.
- **Gradients**: Indigo-to-cyan (135deg) for hero sections; subtle gray gradients for card backgrounds.
