import { describe, expect, it, vi } from "vitest";

const { mockGetDb, mockGetWorkspaceAccess, mockRecordActivity, mockExecuteEmail } = vi.hoisted(() => ({
  mockGetDb: vi.fn(),
  mockGetWorkspaceAccess: vi.fn(),
  mockRecordActivity: vi.fn(),
  mockExecuteEmail: vi.fn(),
}));

vi.mock("./db", () => ({ getDb: mockGetDb }));
vi.mock("./integrations", () => ({ executeEmailAction: mockExecuteEmail }));
vi.mock("./collaboration", () => ({
  getWorkspaceAccess: mockGetWorkspaceAccess,
  recordWorkspaceActivity: mockRecordActivity,
  collaborationTiming: { presenceActiveWindowMs: 90_000 },
}));

import { addWorkflowComment, exportWorkspaceActivity } from "./collaboration-extra";

describe("workflow comment mention notifications", () => {
  it("notifies an active mentioned teammate through the workspace owner provider", async () => {
    const selectRows = [
      [{ id: 77, userId: 20 }],
      [{ id: 1 }],
      [{ userId: 8, email: "teammate@example.com" }],
      [{ id: 5, agentId: 9 }],
    ];
    const insertRows = [[{ insertId: 101 }], [{ insertId: 202 }]];
    const db = {
      select: vi.fn(() => {
        const rows = selectRows.shift() ?? [];
        const chain = {
          from: vi.fn(() => chain),
          where: vi.fn(() => chain),
          limit: vi.fn(async () => rows),
          then: (resolve: (value: unknown) => unknown) => Promise.resolve(resolve(rows)),
        };
        return chain;
      }),
      insert: vi.fn(() => ({ values: vi.fn(async () => insertRows.shift() ?? []) })),
      update: vi.fn(() => ({
        set: vi.fn(() => ({ where: vi.fn(async () => undefined) })),
      })),
    };
    mockGetDb.mockResolvedValue(db);
    mockGetWorkspaceAccess.mockResolvedValue({ role: "editor", workspaceOwnerId: 99 });
    mockExecuteEmail.mockResolvedValue({ output: { provider: "resend" } });

    const result = await addWorkflowComment(7, 12, 77, "Please review this, @teammate@example.com");

    expect(result).toEqual({ commentId: 101, mentionsNotified: 1 });
    expect(mockExecuteEmail).toHaveBeenCalledWith(
      99,
      9,
      5,
      expect.objectContaining({ to: "teammate@example.com" })
    );
    expect(mockRecordActivity).toHaveBeenCalledWith(
      12,
      7,
      "workflow_comment.created",
      "comment",
      101,
      { workflowId: 77 },
      77
    );
  });

  it("returns capped activity rows for workflow-scoped export filters", async () => {
    mockGetWorkspaceAccess.mockResolvedValue({ role: "viewer", workspaceOwnerId: 99 });
    const row = { id: 1, workflowId: 77, eventType: "workflow_comment.created" };
    const db = {
      select: vi.fn(() => {
        const chain = {
          from: vi.fn(() => chain),
          leftJoin: vi.fn(() => chain),
          where: vi.fn(() => chain),
          orderBy: vi.fn(() => chain),
          limit: vi.fn(async () => [row]),
        };
        return chain;
      }),
    };
    mockGetDb.mockResolvedValue(db);

    const result = await exportWorkspaceActivity(7, 12, {
      workflowId: 77,
      eventType: "workflow_comment.created",
      startDate: "2026-01-01",
      endDate: "2026-01-31",
      timezone: "America/Los_Angeles",
    });

    expect(result).toEqual([row]);
    expect(db.select).toHaveBeenCalledOnce();
  });

  it("rejects a reversed activity date range before querying", async () => {
    mockGetWorkspaceAccess.mockResolvedValue({ role: "viewer", workspaceOwnerId: 99 });
    mockGetDb.mockClear();

    await expect(exportWorkspaceActivity(7, 12, { startDate: "2026-02-01", endDate: "2026-01-31" }))
      .rejects.toThrow("start date must be on or before");
    expect(mockGetDb).not.toHaveBeenCalled();
  });

  it("rejects an invalid IANA timezone before querying", async () => {
    mockGetWorkspaceAccess.mockResolvedValue({ role: "viewer", workspaceOwnerId: 99 });
    mockGetDb.mockClear();

    await expect(exportWorkspaceActivity(7, 12, { startDate: "2026-01-01", timezone: "Mars/Olympus" }))
      .rejects.toThrow("valid IANA timezone");
    expect(mockGetDb).not.toHaveBeenCalled();
  });
});
