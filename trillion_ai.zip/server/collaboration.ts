import { randomBytes } from "node:crypto";
import { and, desc, eq, gt, gte, lt, ne, or } from "drizzle-orm";
import {
  integrations,
  users,
  workflowComments,
  workflowShares,
  workflows,
  workspaceActivity,
  workspaceMembers,
  workspacePresence,
  workspaceReportingPresets,
  workspaces,
} from "../drizzle/schema";
import { getDb } from "./db";
import { executeEmailAction } from "./integrations";
import { createHeartbeatJob, deleteHeartbeatJob, updateHeartbeatJob } from "./_core/heartbeat";

export type WorkspaceRole = "owner" | "editor" | "viewer";
export type WorkflowPermission = "viewer" | "editor";

const makeToken = () => randomBytes(24).toString("hex");
const normalizeEmail = (email: string) => email.trim().toLowerCase();
const assertIanaTimezone = (timezone: string) => {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: timezone }).format();
  } catch {
    throw new Error("Timezone must be a valid IANA timezone");
  }
};
const assertDateOnly = (value: string) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("Preset dates must use YYYY-MM-DD format");
  const parsed = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) {
    throw new Error("Preset date is invalid");
  }
};
const INVITE_TTL_MS = 72 * 60 * 60 * 1000;
const INVITE_RESEND_COOLDOWN_MS = 10 * 60 * 1000;
const PRESENCE_ACTIVE_WINDOW_MS = 90 * 1000;

export const collaborationTiming = {
  inviteTtlMs: INVITE_TTL_MS,
  inviteResendCooldownMs: INVITE_RESEND_COOLDOWN_MS,
  presenceActiveWindowMs: PRESENCE_ACTIVE_WINDOW_MS,
};

export async function recordWorkspaceActivity(
  workspaceId: number,
  actorUserId: number | null,
  eventType: string,
  entityType: string,
  entityId: number | null,
  metadata: Record<string, unknown> = {},
  workflowId?: number | null
) {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(workspaceActivity).values({
      workspaceId,
      actorUserId,
      eventType,
      entityType,
      entityId,
      workflowId: workflowId ?? null,
      metadata,
    });
  } catch (error) {
    // Audit logging must not take down an otherwise successful collaboration action.
    console.warn("Unable to record workspace activity", error);
  }
}

async function getWorkspaceById(workspaceId: number) {
  const db = await getDb();
  if (!db) return null;
  const [workspace] = await db
    .select()
    .from(workspaces)
    .where(eq(workspaces.id, workspaceId))
    .limit(1);
  return workspace ?? null;
}

export async function ensureWorkspace(userId: number, ownerEmail?: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [existing] = await db
    .select()
    .from(workspaces)
    .where(eq(workspaces.ownerId, userId))
    .limit(1);

  if (existing) {
    return existing;
  }

  const suffix = randomBytes(5).toString("hex");
  const name = "TrillionAI Workspace";
  const slug = `workspace-${userId}-${suffix}`;
  const result = await db.insert(workspaces).values({ ownerId: userId, name, slug });
  const workspaceId = Number((result as any)[0]?.insertId ?? (result as any).insertId);
  if (!workspaceId) throw new Error("Unable to create workspace");

  await db.insert(workspaceMembers).values({
    workspaceId,
    userId,
    email: normalizeEmail(ownerEmail || `owner-${userId}@workspace.local`),
    role: "owner",
    status: "active",
    invitedBy: userId,
    inviteToken: makeToken(),
  });
  await recordWorkspaceActivity(workspaceId, userId, "workspace.created", "workspace", workspaceId, { name });

  const workspace = await getWorkspaceById(workspaceId);
  if (!workspace) throw new Error("Unable to load workspace");
  return workspace;
}

export async function getWorkspaceAccess(userId: number, workspaceId: number) {
  const db = await getDb();
  if (!db) return null;

  const [member] = await db
    .select({
      id: workspaceMembers.id,
      workspaceId: workspaceMembers.workspaceId,
      userId: workspaceMembers.userId,
      email: workspaceMembers.email,
      role: workspaceMembers.role,
      status: workspaceMembers.status,
      timezoneOverride: workspaceMembers.timezoneOverride,
      workspaceOwnerId: workspaces.ownerId,
      timezonePolicy: workspaces.timezonePolicy,
      workspaceTimezone: workspaces.timezone,
    })
    .from(workspaceMembers)
    .innerJoin(workspaces, eq(workspaces.id, workspaceMembers.workspaceId))
    .where(
      and(
        eq(workspaceMembers.workspaceId, workspaceId),
        eq(workspaceMembers.userId, userId),
        eq(workspaceMembers.status, "active")
      )
    )
    .limit(1);

  return member ?? null;
}

export async function getWorkspaceTimezoneSettings(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  return {
    policy: access.timezonePolicy,
    workspaceTimezone: access.workspaceTimezone,
    memberTimezoneOverride: access.timezoneOverride,
    canManagePolicy: access.role === "owner",
  };
}

export async function updateWorkspaceTimezonePolicy(
  userId: number,
  workspaceId: number,
  policy: "member" | "workspace",
  timezone: string
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") throw new Error("Only workspace owners can change timezone policy");
  assertIanaTimezone(timezone);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(workspaces).set({ timezonePolicy: policy, timezone }).where(eq(workspaces.id, workspaceId));
  await recordWorkspaceActivity(workspaceId, userId, "workspace.timezone_policy_updated", "workspace", workspaceId, { policy, timezone });
  return { policy, workspaceTimezone: timezone };
}

export async function updateMemberTimezoneOverride(userId: number, workspaceId: number, timezone: string | null) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  if (timezone) assertIanaTimezone(timezone);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(workspaceMembers).set({ timezoneOverride: timezone }).where(eq(workspaceMembers.id, access.id));
  await recordWorkspaceActivity(workspaceId, userId, "member.timezone_override_updated", "member", access.id, { timezone });
  return { timezoneOverride: timezone };
}

export async function listWorkspaceReportingPresets(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: workspaceReportingPresets.id,
      name: workspaceReportingPresets.name,
      startDate: workspaceReportingPresets.startDate,
      endDate: workspaceReportingPresets.endDate,
      timezone: workspaceReportingPresets.timezone,
      createdBy: workspaceReportingPresets.createdBy,
      scheduleCron: workspaceReportingPresets.scheduleCron,
      scheduleDeliveryEmail: workspaceReportingPresets.scheduleDeliveryEmail,
      scheduleEnabled: workspaceReportingPresets.scheduleEnabled,
      lastDeliveredAt: workspaceReportingPresets.lastDeliveredAt,
      createdAt: workspaceReportingPresets.createdAt,
    })
    .from(workspaceReportingPresets)
    .where(eq(workspaceReportingPresets.workspaceId, workspaceId))
    .orderBy(desc(workspaceReportingPresets.createdAt));
}

export async function createWorkspaceReportingPreset(
  userId: number,
  workspaceId: number,
  name: string,
  startDate: string,
  endDate: string,
  timezone: string
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) throw new Error("Editor access required");
  const trimmedName = name.trim();
  if (!trimmedName) throw new Error("Preset name is required");
  assertDateOnly(startDate);
  assertDateOnly(endDate);
  if (startDate > endDate) throw new Error("Preset start date must be on or before the end date");
  assertIanaTimezone(timezone);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [duplicate] = await db
    .select({ id: workspaceReportingPresets.id, name: workspaceReportingPresets.name })
    .from(workspaceReportingPresets)
    .where(and(
      eq(workspaceReportingPresets.workspaceId, workspaceId),
      eq(workspaceReportingPresets.startDate, startDate),
      eq(workspaceReportingPresets.endDate, endDate),
      eq(workspaceReportingPresets.timezone, timezone),
      eq(workspaceReportingPresets.name, trimmedName)
    ))
    .limit(1);
  if (duplicate) throw new Error("A shared preset with the same name, date range, and timezone already exists");
  const result = await db.insert(workspaceReportingPresets).values({
    workspaceId,
    name: trimmedName,
    startDate,
    endDate,
    timezone,
    createdBy: userId,
  });
  const presetId = Number((result as any)[0]?.insertId ?? (result as any).insertId);
  await recordWorkspaceActivity(workspaceId, userId, "reporting_preset.created", "reporting_preset", presetId, { name: trimmedName, startDate, endDate, timezone });
  return { id: presetId, name: trimmedName, startDate, endDate, timezone };
}

export async function updateWorkspaceReportingPreset(
  userId: number,
  workspaceId: number,
  presetId: number,
  name: string,
  startDate: string,
  endDate: string,
  timezone: string
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) throw new Error("Editor access required");
  const trimmedName = name.trim();
  if (!trimmedName) throw new Error("Preset name is required");
  assertDateOnly(startDate);
  assertDateOnly(endDate);
  if (startDate > endDate) throw new Error("Preset start date must be on or before the end date");
  assertIanaTimezone(timezone);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [existing] = await db
    .select({ id: workspaceReportingPresets.id, createdBy: workspaceReportingPresets.createdBy })
    .from(workspaceReportingPresets)
    .where(and(eq(workspaceReportingPresets.id, presetId), eq(workspaceReportingPresets.workspaceId, workspaceId)))
    .limit(1);
  if (!existing) throw new Error("Reporting preset not found");
  const [duplicate] = await db
    .select({ id: workspaceReportingPresets.id })
    .from(workspaceReportingPresets)
    .where(and(
      eq(workspaceReportingPresets.workspaceId, workspaceId),
      ne(workspaceReportingPresets.id, presetId),
      eq(workspaceReportingPresets.startDate, startDate),
      eq(workspaceReportingPresets.endDate, endDate),
      eq(workspaceReportingPresets.timezone, timezone),
      eq(workspaceReportingPresets.name, trimmedName)
    ))
    .limit(1);
  if (duplicate) throw new Error("A shared preset with the same name, date range, and timezone already exists");
  await db.update(workspaceReportingPresets).set({ name: trimmedName, startDate, endDate, timezone }).where(eq(workspaceReportingPresets.id, presetId));
  await recordWorkspaceActivity(workspaceId, userId, "reporting_preset.updated", "reporting_preset", presetId, { name: trimmedName, startDate, endDate, timezone });
  return { id: presetId, name: trimmedName, startDate, endDate, timezone };
}

const assertCronExpression = (cron: string) => {
  if (cron.trim().split(/\s+/).length !== 6) throw new Error("Schedule must use a six-field UTC cron expression");
};

const assertEmail = (email: string) => {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("A valid delivery email is required");
};

const nextCalendarDate = (value: string) => {
  const date = new Date(`${value}T00:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + 1);
  return date.toISOString().slice(0, 10);
};

const timezoneOffsetMs = (instant: Date, timezone: string) => {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(instant);
  const values = Object.fromEntries(parts.filter((part) => part.type !== "literal").map((part) => [part.type, Number(part.value)]));
  return Date.UTC(values.year, values.month - 1, values.day, values.hour, values.minute, values.second) - instant.getTime();
};

const localDateToUtc = (value: string, timezone: string) => {
  const guess = new Date(`${value}T00:00:00.000Z`);
  const first = new Date(guess.getTime() - timezoneOffsetMs(guess, timezone));
  return new Date(guess.getTime() - timezoneOffsetMs(first, timezone));
};

export async function upsertWorkspaceReportingSchedule(
  userId: number,
  workspaceId: number,
  presetId: number,
  cron: string,
  deliveryEmail: string,
  sessionToken: string
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) throw new Error("Editor access required");
  assertCronExpression(cron);
  assertEmail(deliveryEmail);
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [preset] = await db.select().from(workspaceReportingPresets).where(and(eq(workspaceReportingPresets.id, presetId), eq(workspaceReportingPresets.workspaceId, workspaceId))).limit(1);
  if (!preset) throw new Error("Reporting preset not found");
  const job = preset.scheduleCronTaskUid
    ? await updateHeartbeatJob(preset.scheduleCronTaskUid, { cron, enable: true, description: `TrillionAI report: ${preset.name}` }, sessionToken)
    : await createHeartbeatJob({
      name: `trillionai-report-${workspaceId}-${presetId}`,
      cron,
      path: "/api/scheduled/deliverReport",
      description: `TrillionAI report: ${preset.name}`,
    }, sessionToken);
  await db.update(workspaceReportingPresets).set({ scheduleCronTaskUid: preset.scheduleCronTaskUid ?? job.taskUid, scheduleCron: cron, scheduleDeliveryEmail: normalizeEmail(deliveryEmail), scheduleEnabled: true }).where(eq(workspaceReportingPresets.id, presetId));
  await recordWorkspaceActivity(workspaceId, userId, "reporting_preset.schedule_updated", "reporting_preset", presetId, { cron, deliveryEmail: normalizeEmail(deliveryEmail), enabled: true });
  return { scheduleEnabled: true, scheduleCron: cron, scheduleDeliveryEmail: normalizeEmail(deliveryEmail), nextExecutionAt: job.nextExecutionAt ?? null };
}

export async function setWorkspaceReportingScheduleEnabled(userId: number, workspaceId: number, presetId: number, enabled: boolean, sessionToken: string) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) throw new Error("Editor access required");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [preset] = await db.select().from(workspaceReportingPresets).where(and(eq(workspaceReportingPresets.id, presetId), eq(workspaceReportingPresets.workspaceId, workspaceId))).limit(1);
  if (!preset?.scheduleCronTaskUid) throw new Error("This preset does not have a schedule yet");
  const job = await updateHeartbeatJob(preset.scheduleCronTaskUid, { enable: enabled }, sessionToken);
  await db.update(workspaceReportingPresets).set({ scheduleEnabled: enabled }).where(eq(workspaceReportingPresets.id, presetId));
  await recordWorkspaceActivity(workspaceId, userId, "reporting_preset.schedule_updated", "reporting_preset", presetId, { cron: preset.scheduleCron, deliveryEmail: preset.scheduleDeliveryEmail, enabled });
  return { scheduleEnabled: enabled, nextExecutionAt: job.nextExecutionAt ?? null };
}

export async function removeWorkspaceReportingSchedule(userId: number, workspaceId: number, presetId: number, sessionToken: string) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) throw new Error("Editor access required");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [preset] = await db.select().from(workspaceReportingPresets).where(and(eq(workspaceReportingPresets.id, presetId), eq(workspaceReportingPresets.workspaceId, workspaceId))).limit(1);
  if (!preset) throw new Error("Reporting preset not found");
  if (preset.scheduleCronTaskUid) await deleteHeartbeatJob(preset.scheduleCronTaskUid, sessionToken);
  await db.update(workspaceReportingPresets).set({ scheduleCronTaskUid: null, scheduleCron: null, scheduleDeliveryEmail: null, scheduleEnabled: false }).where(eq(workspaceReportingPresets.id, presetId));
  await recordWorkspaceActivity(workspaceId, userId, "reporting_preset.schedule_removed", "reporting_preset", presetId, {});
  return { scheduleEnabled: false } as const;
}

export async function deliverScheduledReportingPreset(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [preset] = await db.select({
    id: workspaceReportingPresets.id,
    workspaceId: workspaceReportingPresets.workspaceId,
    name: workspaceReportingPresets.name,
    startDate: workspaceReportingPresets.startDate,
    endDate: workspaceReportingPresets.endDate,
    timezone: workspaceReportingPresets.timezone,
    deliveryEmail: workspaceReportingPresets.scheduleDeliveryEmail,
    enabled: workspaceReportingPresets.scheduleEnabled,
    ownerId: workspaces.ownerId,
  }).from(workspaceReportingPresets).innerJoin(workspaces, eq(workspaces.id, workspaceReportingPresets.workspaceId)).where(eq(workspaceReportingPresets.scheduleCronTaskUid, taskUid)).limit(1);
  if (!preset) return { ok: true, skipped: "orphan" } as const;
  if (!preset.enabled || !preset.deliveryEmail) return { ok: true, skipped: "disabled" } as const;
  const start = localDateToUtc(preset.startDate, preset.timezone);
  const end = localDateToUtc(nextCalendarDate(preset.endDate), preset.timezone);
  const rows = await db.select({ eventType: workspaceActivity.eventType, createdAt: workspaceActivity.createdAt }).from(workspaceActivity).where(and(eq(workspaceActivity.workspaceId, preset.workspaceId), gte(workspaceActivity.createdAt, start), lt(workspaceActivity.createdAt, end))).orderBy(desc(workspaceActivity.createdAt)).limit(500);
  const [integration] = await db.select({ id: integrations.id, agentId: integrations.agentId }).from(integrations).where(and(eq(integrations.userId, preset.ownerId), eq(integrations.status, "connected"), or(eq(integrations.type, "email"), eq(integrations.type, "resend"), eq(integrations.type, "sendgrid")))).orderBy(desc(integrations.updatedAt)).limit(1);
  if (!integration) throw new Error("No connected email integration is available for this scheduled report");
  const counts = rows.reduce<Record<string, number>>((result, row) => { result[row.eventType] = (result[row.eventType] ?? 0) + 1; return result; }, {});
  await executeEmailAction(preset.ownerId, integration.agentId, integration.id, {
    to: preset.deliveryEmail,
    subject: `TrillionAI report: ${preset.name}`,
    body: [`Shared reporting preset: ${preset.name}`, `Range: ${preset.startDate} through ${preset.endDate}`, `Timezone: ${preset.timezone}`, `Activity events: ${rows.length}`, "", ...Object.entries(counts).map(([eventType, count]) => `${eventType}: ${count}`)].join("\n"),
  });
  const deliveredAt = new Date();
  await db.update(workspaceReportingPresets).set({ lastDeliveredAt: deliveredAt }).where(eq(workspaceReportingPresets.id, preset.id));
  await recordWorkspaceActivity(preset.workspaceId, null, "reporting_preset.report_delivered", "reporting_preset", preset.id, { name: preset.name, deliveryEmail: preset.deliveryEmail, eventCount: rows.length });
  return { ok: true, deliveredAt, eventCount: rows.length } as const;
}

export async function deleteWorkspaceReportingPreset(userId: number, workspaceId: number, presetId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [preset] = await db
    .select({ id: workspaceReportingPresets.id, createdBy: workspaceReportingPresets.createdBy, name: workspaceReportingPresets.name })
    .from(workspaceReportingPresets)
    .where(and(eq(workspaceReportingPresets.id, presetId), eq(workspaceReportingPresets.workspaceId, workspaceId)))
    .limit(1);
  if (!preset) throw new Error("Reporting preset not found");
  if (access.role !== "owner" && preset.createdBy !== userId) throw new Error("Only the preset creator or workspace owner can delete it");
  await db.delete(workspaceReportingPresets).where(eq(workspaceReportingPresets.id, presetId));
  await recordWorkspaceActivity(workspaceId, userId, "reporting_preset.deleted", "reporting_preset", presetId, { name: preset.name });
  return { success: true } as const;
}

export async function listWorkspaceMembers(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");

  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: workspaceMembers.id,
      email: workspaceMembers.email,
      role: workspaceMembers.role,
      status: workspaceMembers.status,
      userId: workspaceMembers.userId,
      inviteSentAt: workspaceMembers.inviteSentAt,
      inviteExpiresAt: workspaceMembers.inviteExpiresAt,
      createdAt: workspaceMembers.createdAt,
    })
    .from(workspaceMembers)
    .where(eq(workspaceMembers.workspaceId, workspaceId))
    .orderBy(desc(workspaceMembers.createdAt));
}

export async function inviteWorkspaceMember(
  userId: number,
  workspaceId: number,
  email: string,
  role: Exclude<WorkspaceRole, "owner">
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") {
    throw new Error("Only workspace owners can invite members");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const normalizedEmail = normalizeEmail(email);
  const now = new Date();
  const inviteExpiresAt = new Date(now.getTime() + INVITE_TTL_MS);
  const [existing] = await db
    .select()
    .from(workspaceMembers)
    .where(
      and(
        eq(workspaceMembers.workspaceId, workspaceId),
        eq(workspaceMembers.email, normalizedEmail)
      )
    )
    .limit(1);

  if (existing?.status === "active") {
    throw new Error("This email is already a workspace member");
  }

  if (
    existing?.status === "pending" &&
    existing.inviteSentAt &&
    now.getTime() - existing.inviteSentAt.getTime() < INVITE_RESEND_COOLDOWN_MS
  ) {
    const remainingSeconds = Math.ceil(
      (INVITE_RESEND_COOLDOWN_MS - (now.getTime() - existing.inviteSentAt.getTime())) / 1000
    );
    throw new Error(`Please wait ${remainingSeconds}s before resending this invitation`);
  }

  const inviteToken = makeToken();
  if (existing) {
    await db
      .update(workspaceMembers)
      .set({
        role,
        status: "pending",
        userId: null,
        invitedBy: userId,
        inviteToken,
        inviteExpiresAt,
        inviteSentAt: null,
      })
      .where(eq(workspaceMembers.id, existing.id));
    await recordWorkspaceActivity(workspaceId, userId, "invitation.resent", "member", existing.id, { email: normalizedEmail, role });
    return { memberId: existing.id, inviteToken, role, email: normalizedEmail };
  }

  const result = await db.insert(workspaceMembers).values({
    workspaceId,
    email: normalizedEmail,
    role,
    status: "pending",
    invitedBy: userId,
    inviteToken,
    inviteExpiresAt,
  });
  const memberId = Number((result as any)[0]?.insertId ?? (result as any).insertId);
  await recordWorkspaceActivity(workspaceId, userId, "invitation.created", "member", memberId, { email: normalizedEmail, role });
  return { memberId, inviteToken, role, email: normalizedEmail };
}

export async function listEmailIntegrations(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") {
    throw new Error("Only workspace owners can send invitations");
  }

  const db = await getDb();
  if (!db) return [];
  return db
    .select({ id: integrations.id, agentId: integrations.agentId, name: integrations.name, type: integrations.type })
    .from(integrations)
    .where(
      and(
        eq(integrations.userId, userId),
        eq(integrations.status, "connected"),
        or(
          eq(integrations.type, "email"),
          eq(integrations.type, "resend"),
          eq(integrations.type, "sendgrid")
        )
      )
    )
    .orderBy(desc(integrations.updatedAt));
}

export async function sendWorkspaceInviteEmail(
  userId: number,
  workspaceId: number,
  memberId: number,
  integrationId: number,
  appOrigin: string
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") {
    throw new Error("Only workspace owners can send invitations");
  }

  let origin: URL;
  try {
    origin = new URL(appOrigin);
  } catch {
    throw new Error("A valid application origin is required");
  }
  if (origin.protocol !== "https:" && origin.protocol !== "http:") {
    throw new Error("The application origin must use HTTP or HTTPS");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [member] = await db
    .select()
    .from(workspaceMembers)
    .where(
      and(
        eq(workspaceMembers.id, memberId),
        eq(workspaceMembers.workspaceId, workspaceId),
        eq(workspaceMembers.status, "pending")
      )
    )
    .limit(1);
  if (!member?.inviteToken) throw new Error("Pending invitation not found or already accepted");

  const now = new Date();
  if (member.inviteSentAt && now.getTime() - member.inviteSentAt.getTime() < INVITE_RESEND_COOLDOWN_MS) {
    const remainingSeconds = Math.ceil(
      (INVITE_RESEND_COOLDOWN_MS - (now.getTime() - member.inviteSentAt.getTime())) / 1000
    );
    throw new Error(`Please wait ${remainingSeconds}s before resending this invitation`);
  }

  let inviteToken = member.inviteToken;
  let inviteExpiresAt = member.inviteExpiresAt;
  if (!inviteExpiresAt || inviteExpiresAt.getTime() <= now.getTime()) {
    inviteToken = makeToken();
    inviteExpiresAt = new Date(now.getTime() + INVITE_TTL_MS);
    await db
      .update(workspaceMembers)
      .set({ inviteToken, inviteExpiresAt, inviteSentAt: null })
      .where(eq(workspaceMembers.id, member.id));
    await recordWorkspaceActivity(workspaceId, userId, "invitation.rotated", "member", member.id, { reason: "expired" });
  }

  const [integration] = await db
    .select({ id: integrations.id, agentId: integrations.agentId, type: integrations.type })
    .from(integrations)
    .where(
      and(
        eq(integrations.id, integrationId),
        eq(integrations.userId, userId),
        eq(integrations.status, "connected"),
        or(
          eq(integrations.type, "email"),
          eq(integrations.type, "resend"),
          eq(integrations.type, "sendgrid")
        )
      )
    )
    .limit(1);
  if (!integration) throw new Error("Connected email integration not found");

  const inviteLink = new URL("/collaboration", origin);
  inviteLink.searchParams.set("invite", inviteToken);
  const result = await executeEmailAction(userId, integration.agentId, integration.id, {
    to: member.email,
    subject: "You have been invited to a TrillionAI workspace",
    body: [
      `You have been invited to collaborate in TrillionAI as a ${member.role}.`,
      "",
      `Accept the invitation: ${inviteLink.toString()}`,
      "",
      "This link is one-time and can only be accepted by the invited email address.",
    ].join("\n"),
  });

  const sentAt = new Date();
  await db
    .update(workspaceMembers)
    .set({ inviteSentAt: sentAt })
    .where(eq(workspaceMembers.id, member.id));
  await recordWorkspaceActivity(workspaceId, userId, "invitation.email_sent", "member", member.id, {
    email: member.email,
    expiresAt: inviteExpiresAt?.toISOString() ?? null,
    provider: result.output.provider,
  });

  return { ...result.output, sentAt };
}

export async function acceptWorkspaceInvite(userId: number, email: string | null | undefined, inviteToken: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const normalizedEmail = normalizeEmail(email || "");
  if (!normalizedEmail) throw new Error("An authenticated email is required to accept an invite");

  const [invite] = await db
    .select()
    .from(workspaceMembers)
    .where(
      and(
        eq(workspaceMembers.inviteToken, inviteToken),
        eq(workspaceMembers.status, "pending")
      )
    )
    .limit(1);

  if (!invite) throw new Error("Invitation not found or already accepted");
  if (!invite.inviteExpiresAt || invite.inviteExpiresAt.getTime() <= Date.now()) {
    throw new Error("This invitation has expired. Ask the workspace owner to resend it");
  }
  if (invite.email !== normalizedEmail) {
    throw new Error("This invitation was issued to a different email address");
  }

  await db
    .update(workspaceMembers)
    .set({ userId, status: "active", inviteToken: null })
    .where(eq(workspaceMembers.id, invite.id));
  await recordWorkspaceActivity(invite.workspaceId, userId, "invitation.accepted", "member", invite.id, {
    email: normalizedEmail,
    role: invite.role,
  });

  return { workspaceId: invite.workspaceId, role: invite.role };
}

export async function revokeWorkspaceMember(userId: number, workspaceId: number, memberId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") {
    throw new Error("Only workspace owners can revoke members");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [member] = await db
    .select()
    .from(workspaceMembers)
    .where(and(eq(workspaceMembers.id, memberId), eq(workspaceMembers.workspaceId, workspaceId)))
    .limit(1);
  if (!member) throw new Error("Workspace member not found");
  if (member.role === "owner") throw new Error("The workspace owner cannot be revoked");

  await db
    .update(workspaceMembers)
    .set({ status: "revoked", userId: null })
    .where(eq(workspaceMembers.id, memberId));
  await recordWorkspaceActivity(workspaceId, userId, "member.revoked", "member", memberId, { email: member.email, role: member.role });
  return { success: true } as const;
}

export async function updateWorkspaceMemberRole(
  userId: number,
  workspaceId: number,
  memberId: number,
  role: Exclude<WorkspaceRole, "owner">
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") {
    throw new Error("Only workspace owners can change member roles");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [member] = await db
    .select()
    .from(workspaceMembers)
    .where(and(eq(workspaceMembers.id, memberId), eq(workspaceMembers.workspaceId, workspaceId)))
    .limit(1);
  if (!member) throw new Error("Workspace member not found");
  if (member.role === "owner") throw new Error("The workspace owner role cannot be changed");

  await db.update(workspaceMembers).set({ role }).where(eq(workspaceMembers.id, memberId));
  await recordWorkspaceActivity(workspaceId, userId, "member.role_changed", "member", memberId, {
    email: member.email,
    from: member.role,
    to: role,
  });
  return { success: true, role } as const;
}

async function assertWorkspaceContributor(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) {
    throw new Error("Editor access required");
  }
  return access;
}

export async function shareWorkflow(
  userId: number,
  workspaceId: number,
  workflowId: number,
  permission: WorkflowPermission
) {
  await assertWorkspaceContributor(userId, workspaceId);
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [workflow] = await db
    .select({ id: workflows.id, userId: workflows.userId })
    .from(workflows)
    .where(eq(workflows.id, workflowId))
    .limit(1);
  if (!workflow) throw new Error("Workflow not found");
  if (workflow.userId !== userId) {
    throw new Error("Only the workflow owner can create a share");
  }

  const [existing] = await db
    .select()
    .from(workflowShares)
    .where(
      and(
        eq(workflowShares.workspaceId, workspaceId),
        eq(workflowShares.workflowId, workflowId)
      )
    )
    .limit(1);

  if (existing) {
    await db
      .update(workflowShares)
      .set({ permission, createdBy: userId })
      .where(eq(workflowShares.id, existing.id));
    await recordWorkspaceActivity(workspaceId, userId, "workflow_share.permission_changed", "workflow", workflowId, {
      shareId: existing.id,
      permission,
    });
    return { shareId: existing.id, permission };
  }

  const result = await db.insert(workflowShares).values({
    workspaceId,
    workflowId,
    permission,
    createdBy: userId,
  });
  const shareId = Number((result as any)[0]?.insertId ?? (result as any).insertId);
  await recordWorkspaceActivity(workspaceId, userId, "workflow_share.created", "workflow", workflowId, {
    shareId,
    permission,
  });
  return { shareId, permission };
}

export async function listWorkflowShares(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");

  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: workflowShares.id,
      workflowId: workflowShares.workflowId,
      workflowName: workflows.name,
      permission: workflowShares.permission,
      createdAt: workflowShares.createdAt,
    })
    .from(workflowShares)
    .innerJoin(workflows, eq(workflows.id, workflowShares.workflowId))
    .where(eq(workflowShares.workspaceId, workspaceId))
    .orderBy(desc(workflowShares.createdAt));
}

export async function unshareWorkflow(userId: number, workspaceId: number, shareId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || access.role !== "owner") {
    throw new Error("Only workspace owners can remove workflow shares");
  }

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .delete(workflowShares)
    .where(and(eq(workflowShares.id, shareId), eq(workflowShares.workspaceId, workspaceId)));
  await recordWorkspaceActivity(workspaceId, userId, "workflow_share.removed", "share", shareId);
  return { success: true } as const;
}
