import { describe, expect, it, vi } from "vitest";

const { mockGetDb } = vi.hoisted(() => ({ mockGetDb: vi.fn() }));
vi.mock("./db", () => ({ getDb: mockGetDb }));

import { executeDatabaseAction, executeEmailAction } from "./integrations";

const makeIntegrationDb = (integration: any) => ({
  select: vi.fn(() => ({
    from: vi.fn(() => ({
      where: vi.fn(() => ({
        limit: vi.fn().mockResolvedValue(integration ? [integration] : []),
      })),
    })),
  })),
});

describe("production integration adapters", () => {
  it("sends through the owner-scoped Resend adapter", async () => {
    mockGetDb.mockResolvedValueOnce(makeIntegrationDb({
      id: 4,
      userId: 7,
      agentId: 2,
      type: "email",
      status: "connected",
      credentials: { provider: "resend", apiKey: "secret", from: "noreply@example.com" },
    }));
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ id: "msg_123" }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    const result = await executeEmailAction(7, 2, 4, {
      to: "customer@example.com",
      subject: "Welcome",
      body: "Hello",
    });

    expect(result.output).toMatchObject({ accepted: true, provider: "resend", messageId: "msg_123" });
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.resend.com/emails",
      expect.objectContaining({ method: "POST", headers: expect.objectContaining({ authorization: "Bearer secret" }) })
    );
    vi.unstubAllGlobals();
  });

  it("rejects an integration owned by another user", async () => {
    mockGetDb.mockResolvedValueOnce(makeIntegrationDb(null));

    await expect(executeEmailAction(7, 2, 4, {
      to: "customer@example.com",
      subject: "Welcome",
      body: "Hello",
    })).rejects.toThrow("Integration not found");
  });

  it("rejects multi-statement database input before opening a connection", async () => {
    mockGetDb.mockResolvedValueOnce(makeIntegrationDb({
      id: 8,
      userId: 7,
      agentId: 2,
      type: "mysql",
      status: "connected",
      credentials: { host: "db.example.com", user: "app", password: "secret", database: "app" },
    }));

    await expect(executeDatabaseAction(7, 2, 8, {
      query: "SELECT 1; DROP TABLE users",
      params: [],
    })).rejects.toThrow("one parameterized statement");
  });
});
