import type { IncomingMessage, Server as HttpServer } from "node:http";
import { WebSocket, WebSocketServer } from "ws";
import { sdk } from "./_core/sdk";
import { getWorkspaceAccess } from "./collaboration";
import { heartbeatPresence, listWorkspacePresence } from "./collaboration-extra";

type PresenceSocket = WebSocket & { workspaceId?: number; userId?: number };
const clients = new Map<number, Set<PresenceSocket>>();
const wss = new WebSocketServer({ noServer: true });

async function broadcastPresence(workspaceId: number, userId: number) {
  const current = await listWorkspacePresence(userId, workspaceId);
  const payload = JSON.stringify({ type: "presence:update", workspaceId, presence: current });
  clients.get(workspaceId)?.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) client.send(payload);
  });
}

async function handleConnection(socket: PresenceSocket, request: IncomingMessage) {
  let user;
  try {
    user = await sdk.authenticateRequest(request as never);
  } catch {
    socket.close(1008, "Authentication required");
    return;
  }
  const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
  const workspaceId = Number(url.searchParams.get("workspaceId"));
  if (!Number.isInteger(workspaceId) || workspaceId < 1) return socket.close(1008, "A valid workspaceId is required");
  if (!(await getWorkspaceAccess(user.id, workspaceId))) return socket.close(1008, "Workspace access denied");

  socket.workspaceId = workspaceId;
  socket.userId = user.id;
  const group = clients.get(workspaceId) ?? new Set<PresenceSocket>();
  group.add(socket);
  clients.set(workspaceId, group);
  await heartbeatPresence(user.id, workspaceId, "collaboration");
  socket.send(JSON.stringify({ type: "presence:ready", workspaceId }));
  await broadcastPresence(workspaceId, user.id);

  socket.on("message", async (raw) => {
    try {
      const message = JSON.parse(raw.toString()) as { type?: string; currentPage?: string; currentWorkflowId?: number | null };
      if (message.type === "heartbeat") {
        await heartbeatPresence(user.id, workspaceId, message.currentPage, message.currentWorkflowId);
        await broadcastPresence(workspaceId, user.id);
      }
    } catch {
      // Ignore malformed frames.
    }
  });
  socket.on("close", () => {
    group.delete(socket);
    if (!group.size) clients.delete(workspaceId);
    void broadcastPresence(workspaceId, user.id);
  });
}

wss.on("connection", (socket, request) => void handleConnection(socket as PresenceSocket, request));

export function registerPresenceWebSocket(server: HttpServer) {
  server.on("upgrade", (request, socket, head) => {
    const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
    if (url.pathname !== "/ws/presence") return;
    wss.handleUpgrade(request, socket, head, (client) => wss.emit("connection", client, request));
  });
}
