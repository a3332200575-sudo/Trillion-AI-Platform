import { describe, expect, it, vi } from "vitest";

const { mockGetDb, mockGetWorkflowById } = vi.hoisted(() => ({
  mockGetDb: vi.fn(),
  mockGetWorkflowById: vi.fn(),
}));

vi.mock("./db", () => ({ getDb: mockGetDb }));
vi.mock("./workflows", () => ({ getWorkflowById: mockGetWorkflowById }));

import { executeWorkflow } from "./execution";

const makeDb = () => ({
  insert: vi.fn(() => ({
    values: vi.fn().mockResolvedValue({ insertId: 123 }),
  })),
  update: vi.fn(() => ({
    set: vi.fn(() => ({
      where: vi.fn().mockResolvedValue({ affectedRows: 1 }),
    })),
  })),
});

describe("workflow execution engine", () => {
  it("persists a successful webhook execution and returns its output", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValueOnce(db);
    mockGetWorkflowById.mockResolvedValueOnce({
      id: 9,
      userId: 7,
      agentId: 2,
      name: "Transform lead",
      trigger: "webhook",
      isActive: true,
      actions: [
        {
          type: "transform_data",
          integrationId: 0,
          config: { operation: "set", field: "processed", value: true },
        },
      ],
    });

    const result = await executeWorkflow(
      7,
      9,
      { payload: { email: "lead@example.com" } },
      { source: "webhook", deliveryId: 44 }
    );

    expect(result).toMatchObject({ executionLogId: 123, status: "success" });
    expect(result.output).toMatchObject({ data: { processed: true } });
    expect(db.insert).toHaveBeenCalled();
    expect(db.update).toHaveBeenCalled();
  });

  it("records a failed execution for an unsupported action instead of throwing", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValueOnce(db);
    mockGetWorkflowById.mockResolvedValueOnce({
      id: 10,
      userId: 7,
      agentId: 2,
      name: "Unsupported workflow",
      trigger: "webhook",
      isActive: true,
      actions: [{ type: "unknown_action", integrationId: 0, config: {} }],
    });

    const result = await executeWorkflow(7, 10, { payload: {} }, { source: "webhook" });

    expect(result).toMatchObject({ executionLogId: 123, status: "failed" });
    expect(result.error).toContain("Unsupported workflow action");
  });

  it("guards webhook execution against non-webhook workflows", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValueOnce(db);
    mockGetWorkflowById.mockResolvedValueOnce({
      id: 11,
      userId: 7,
      agentId: 2,
      name: "Manual workflow",
      trigger: "manual",
      isActive: true,
      actions: [],
    });

    await expect(
      executeWorkflow(7, 11, {}, { source: "webhook" })
    ).rejects.toThrow("Webhook execution requires a webhook-triggered workflow");
    expect(db.insert).not.toHaveBeenCalled();
  });

  it("blocks private-network API targets", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValueOnce(db);
    mockGetWorkflowById.mockResolvedValueOnce({
      id: 12,
      userId: 7,
      agentId: 2,
      name: "Private target",
      trigger: "webhook",
      isActive: true,
      actions: [{ type: "api_call", integrationId: 0, config: { url: "http://127.0.0.1/admin" } }],
    });

    const result = await executeWorkflow(7, 12, {}, { source: "webhook" });

    expect(result.status).toBe("failed");
    expect(result.error).toContain("private network");
  });

  it("retries transient action failures with the configured bounded policy", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValueOnce(db);
    mockGetWorkflowById.mockResolvedValueOnce({
      id: 13,
      userId: 7,
      agentId: 2,
      name: "Retrying workflow",
      trigger: "webhook",
      isActive: true,
      retryPolicy: { maxAttempts: 3, backoffMs: 0, maxBackoffMs: 0 },
      actions: [{ type: "api_call", integrationId: 0, config: { method: "GET", url: "https://api.example.com/health" } }],
    });
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(new Response("temporary", { status: 503 }))
      .mockResolvedValueOnce(new Response("temporary", { status: 503 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ ok: true }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    const result = await executeWorkflow(7, 13, {}, { source: "webhook" });

    expect(result.status).toBe("success");
    expect(fetchMock).toHaveBeenCalledTimes(3);
    vi.unstubAllGlobals();
  });
});
