import { and, desc, eq, gte, inArray, lt, or } from "drizzle-orm";
import {
  integrations,
  users,
  workflowComments,
  workflowShares,
  workflows,
  workspaceActivity,
  workspaceCommentMentions,
  workspaceMembers,
  workspacePresence,
} from "../drizzle/schema";
import { getDb } from "./db";
import { executeEmailAction } from "./integrations";
import {
  getWorkspaceAccess,
  recordWorkspaceActivity,
  collaborationTiming,
} from "./collaboration";

async function assertCommentAccess(userId: number, workspaceId: number, workflowId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [workflow] = await db
    .select({ id: workflows.id, userId: workflows.userId })
    .from(workflows)
    .where(eq(workflows.id, workflowId))
    .limit(1);
  if (!workflow) throw new Error("Workflow not found");
  if (workflow.userId === userId) return access;

  const [share] = await db
    .select({ id: workflowShares.id })
    .from(workflowShares)
    .where(
      and(
        eq(workflowShares.workspaceId, workspaceId),
        eq(workflowShares.workflowId, workflowId)
      )
    )
    .limit(1);
  if (!share) throw new Error("Workflow is not shared with this workspace");
  return access;
}

type ActivityFilters = {
  workflowId?: number;
  eventType?: string;
  startDate?: string;
  endDate?: string;
  timezone?: string;
  limit?: number;
};

const assertTimezone = (timezone: string) => {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: timezone }).format();
  } catch {
    throw new Error("Activity timezone must be a valid IANA timezone");
  }
};

const nextCalendarDate = (value: string) => {
  const parsed = new Date(`${value}T00:00:00.000Z`);
  parsed.setUTCDate(parsed.getUTCDate() + 1);
  return parsed.toISOString().slice(0, 10);
};

const timezoneOffsetMs = (instant: Date, timezone: string) => {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(instant);
  const values = Object.fromEntries(parts.filter((part) => part.type !== "literal").map((part) => [part.type, Number(part.value)]));
  return Date.UTC(values.year, values.month - 1, values.day, values.hour, values.minute, values.second) - instant.getTime();
};

const parseActivityDate = (value: string, timezone: string) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("Activity dates must use YYYY-MM-DD format");
  const calendarDate = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(calendarDate.getTime()) || calendarDate.toISOString().slice(0, 10) !== value) throw new Error("Activity date is invalid");
  const utcGuess = calendarDate;
  const firstOffset = timezoneOffsetMs(utcGuess, timezone);
  const firstCandidate = new Date(utcGuess.getTime() - firstOffset);
  const correctedOffset = timezoneOffsetMs(firstCandidate, timezone);
  return new Date(utcGuess.getTime() - correctedOffset);
};

export async function listWorkspaceActivity(userId: number, workspaceId: number, options: ActivityFilters = {}) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  const timezone = options.timezone ?? "UTC";
  assertTimezone(timezone);
  const start = options.startDate ? parseActivityDate(options.startDate, timezone) : undefined;
  if (options.endDate) parseActivityDate(options.endDate, timezone);
  const endExclusive = options.endDate ? parseActivityDate(nextCalendarDate(options.endDate), timezone) : undefined;
  if (start && endExclusive && start >= endExclusive) throw new Error("Activity start date must be on or before the end date");
  const db = await getDb();
  if (!db) return [];
  const filters = [eq(workspaceActivity.workspaceId, workspaceId)];
  if (options.workflowId) filters.push(eq(workspaceActivity.workflowId, options.workflowId));
  if (options.eventType) filters.push(eq(workspaceActivity.eventType, options.eventType));
  if (start) filters.push(gte(workspaceActivity.createdAt, start));
  if (endExclusive) filters.push(lt(workspaceActivity.createdAt, endExclusive));
  return db
    .select({
      id: workspaceActivity.id,
      eventType: workspaceActivity.eventType,
      entityType: workspaceActivity.entityType,
      entityId: workspaceActivity.entityId,
      workflowId: workspaceActivity.workflowId,
      metadata: workspaceActivity.metadata,
      createdAt: workspaceActivity.createdAt,
      actorName: users.name,
      actorEmail: users.email,
    })
    .from(workspaceActivity)
    .leftJoin(users, eq(users.id, workspaceActivity.actorUserId))
    .where(and(...filters))
    .orderBy(desc(workspaceActivity.createdAt))
    .limit(Math.min(Math.max(options.limit ?? 80, 1), 500));
}

export async function exportWorkspaceActivity(userId: number, workspaceId: number, options: Omit<ActivityFilters, "limit"> = {}) {
  return listWorkspaceActivity(userId, workspaceId, { ...options, limit: 500 });
}

export async function listWorkspaceTimezoneHistory(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: workspaceActivity.id,
      eventType: workspaceActivity.eventType,
      metadata: workspaceActivity.metadata,
      createdAt: workspaceActivity.createdAt,
      actorName: users.name,
      actorEmail: users.email,
    })
    .from(workspaceActivity)
    .leftJoin(users, eq(users.id, workspaceActivity.actorUserId))
    .where(and(eq(workspaceActivity.workspaceId, workspaceId), eq(workspaceActivity.eventType, "workspace.timezone_policy_updated")))
    .orderBy(desc(workspaceActivity.createdAt))
    .limit(50);
}

export async function heartbeatPresence(
  userId: number,
  workspaceId: number,
  currentPage?: string,
  currentWorkflowId?: number | null
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const [existing] = await db
    .select({ id: workspacePresence.id })
    .from(workspacePresence)
    .where(eq(workspacePresence.userId, userId))
    .limit(1);
  if (existing) {
    await db
      .update(workspacePresence)
      .set({ workspaceId, status: "active", currentPage: currentPage ?? null, currentWorkflowId: currentWorkflowId ?? null, lastSeenAt: now })
      .where(eq(workspacePresence.id, existing.id));
  } else {
    await db.insert(workspacePresence).values({
      workspaceId,
      userId,
      status: "active",
      currentPage: currentPage ?? null,
      currentWorkflowId: currentWorkflowId ?? null,
      lastSeenAt: now,
    });
  }
  return { lastSeenAt: now };
}

export async function listWorkspacePresence(userId: number, workspaceId: number) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access) throw new Error("Workspace access denied");
  const db = await getDb();
  if (!db) return [];
  const cutoff = new Date(Date.now() - collaborationTiming.presenceActiveWindowMs);
  return db
    .select({
      userId: workspacePresence.userId,
      status: workspacePresence.status,
      currentWorkflowId: workspacePresence.currentWorkflowId,
      currentPage: workspacePresence.currentPage,
      lastSeenAt: workspacePresence.lastSeenAt,
      name: users.name,
      email: users.email,
    })
    .from(workspacePresence)
    .innerJoin(users, eq(users.id, workspacePresence.userId))
    .where(and(eq(workspacePresence.workspaceId, workspaceId), gte(workspacePresence.lastSeenAt, cutoff)))
    .orderBy(desc(workspacePresence.lastSeenAt));
}

export async function listWorkflowComments(userId: number, workspaceId: number, workflowId: number) {
  await assertCommentAccess(userId, workspaceId, workflowId);
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: workflowComments.id,
      workflowId: workflowComments.workflowId,
      body: workflowComments.body,
      resolved: workflowComments.resolved,
      createdAt: workflowComments.createdAt,
      updatedAt: workflowComments.updatedAt,
      authorUserId: workflowComments.authorUserId,
      authorName: users.name,
      authorEmail: users.email,
    })
    .from(workflowComments)
    .innerJoin(users, eq(users.id, workflowComments.authorUserId))
    .where(
      and(
        eq(workflowComments.workspaceId, workspaceId),
        eq(workflowComments.workflowId, workflowId)
      )
    )
    .orderBy(desc(workflowComments.createdAt))
    .limit(100);
}

const extractMentionEmails = (body: string) =>
  Array.from(body.matchAll(/@([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})/gi))
    .map((match) => match[1].toLowerCase())
    .filter((email, index, emails) => emails.indexOf(email) === index);

export async function addWorkflowComment(
  userId: number,
  workspaceId: number,
  workflowId: number,
  body: string
) {
  const access = await assertCommentAccess(userId, workspaceId, workflowId);
  const normalizedBody = body.trim();
  if (!normalizedBody) throw new Error("Comment cannot be empty");
  if (normalizedBody.length > 2_000) throw new Error("Comment cannot exceed 2,000 characters");

  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(workflowComments).values({
    workspaceId,
    workflowId,
    authorUserId: userId,
    body: normalizedBody,
    resolved: false,
  });
  const commentId = Number((result as any)[0]?.insertId ?? (result as any).insertId);
  await recordWorkspaceActivity(workspaceId, userId, "workflow_comment.created", "comment", commentId, { workflowId }, workflowId);

  let mentionsNotified = 0;
  const mentionedEmails = extractMentionEmails(normalizedBody);
  if (mentionedEmails.length) {
    const mentionedMembers = await db.select({ userId: workspaceMembers.userId, email: workspaceMembers.email })
      .from(workspaceMembers)
      .where(and(eq(workspaceMembers.workspaceId, workspaceId), eq(workspaceMembers.status, "active"), inArray(workspaceMembers.email, mentionedEmails)));
    const [emailIntegration] = await db.select({ id: integrations.id, agentId: integrations.agentId })
      .from(integrations)
      .where(and(eq(integrations.userId, access.workspaceOwnerId), eq(integrations.status, "connected"), or(eq(integrations.type, "email"), eq(integrations.type, "resend"), eq(integrations.type, "sendgrid"))))
      .limit(1);
    for (const member of mentionedMembers) {
      if (!member.userId || member.userId === userId) continue;
      const mentionResult = await db.insert(workspaceCommentMentions).values({ workspaceId, commentId, mentionedUserId: member.userId, mentionedEmail: member.email });
      const mentionId = Number((mentionResult as any)[0]?.insertId ?? (mentionResult as any).insertId);
      if (!emailIntegration) continue;
      try {
        await executeEmailAction(access.workspaceOwnerId, emailIntegration.agentId, emailIntegration.id, {
          to: member.email,
          subject: "You were mentioned in a TrillionAI workflow comment",
          body: [`You were mentioned in a comment on workflow #${workflowId}.`, "", normalizedBody, "", "Open TrillionAI to review the workflow discussion."].join("\n"),
        });
        await db.update(workspaceCommentMentions).set({ notifiedAt: new Date() }).where(eq(workspaceCommentMentions.id, mentionId));
        mentionsNotified += 1;
        await recordWorkspaceActivity(workspaceId, userId, "workflow_comment.mention_notified", "comment", commentId, { mentionedEmail: member.email, workflowId }, workflowId);
      } catch (error) {
        console.warn("Unable to notify workflow comment mention", error);
      }
    }
  }
  return { commentId, mentionsNotified };
}

export async function setWorkflowCommentResolved(
  userId: number,
  workspaceId: number,
  commentId: number,
  resolved: boolean
) {
  const access = await getWorkspaceAccess(userId, workspaceId);
  if (!access || (access.role !== "owner" && access.role !== "editor")) {
    throw new Error("Editor access required");
  }
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [comment] = await db
    .select({ id: workflowComments.id, workflowId: workflowComments.workflowId })
    .from(workflowComments)
    .where(and(eq(workflowComments.id, commentId), eq(workflowComments.workspaceId, workspaceId)))
    .limit(1);
  if (!comment) throw new Error("Comment not found");

  await db.update(workflowComments).set({ resolved }).where(eq(workflowComments.id, commentId));
  await recordWorkspaceActivity(workspaceId, userId, "workflow_comment.resolved_changed", "comment", commentId, { workflowId: comment.workflowId, resolved }, comment.workflowId);
  return { success: true, resolved } as const;
}
