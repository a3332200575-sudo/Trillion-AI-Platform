import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "../_core/context";

const {
  mockEnsureWorkspace,
  mockGetWorkspaceAccess,
  mockListWorkspaceMembers,
  mockInviteWorkspaceMember,
  mockListEmailIntegrations,
  mockSendWorkspaceInviteEmail,
  mockListWorkspaceActivity,
  mockListWorkspacePresence,
  mockHeartbeatPresence,
  mockUpdateWorkspaceMemberRole,
  mockListWorkflowComments,
  mockAddWorkflowComment,
  mockSetWorkflowCommentResolved,
  mockAcceptWorkspaceInvite,
  mockRevokeWorkspaceMember,
  mockListWorkflowShares,
  mockShareWorkflow,
  mockUnshareWorkflow,
  mockGetWorkspaceTimezoneSettings,
  mockUpdateWorkspaceTimezonePolicy,
  mockUpdateMemberTimezoneOverride,
  mockListWorkspaceReportingPresets,
  mockCreateWorkspaceReportingPreset,
  mockDeleteWorkspaceReportingPreset,
  mockListWorkspaceTimezoneHistory,
} = vi.hoisted(() => ({
  mockEnsureWorkspace: vi.fn(),
  mockGetWorkspaceAccess: vi.fn(),
  mockListWorkspaceMembers: vi.fn(),
  mockInviteWorkspaceMember: vi.fn(),
  mockListEmailIntegrations: vi.fn(),
  mockSendWorkspaceInviteEmail: vi.fn(),
  mockListWorkspaceActivity: vi.fn(),
  mockListWorkspacePresence: vi.fn(),
  mockHeartbeatPresence: vi.fn(),
  mockUpdateWorkspaceMemberRole: vi.fn(),
  mockListWorkflowComments: vi.fn(),
  mockAddWorkflowComment: vi.fn(),
  mockSetWorkflowCommentResolved: vi.fn(),
  mockAcceptWorkspaceInvite: vi.fn(),
  mockRevokeWorkspaceMember: vi.fn(),
  mockListWorkflowShares: vi.fn(),
  mockShareWorkflow: vi.fn(),
  mockUnshareWorkflow: vi.fn(),
  mockGetWorkspaceTimezoneSettings: vi.fn(),
  mockUpdateWorkspaceTimezonePolicy: vi.fn(),
  mockUpdateMemberTimezoneOverride: vi.fn(),
  mockListWorkspaceReportingPresets: vi.fn(),
  mockCreateWorkspaceReportingPreset: vi.fn(),
  mockDeleteWorkspaceReportingPreset: vi.fn(),
  mockListWorkspaceTimezoneHistory: vi.fn(),
}));

vi.mock("../collaboration", () => ({
  ensureWorkspace: mockEnsureWorkspace,
  getWorkspaceAccess: mockGetWorkspaceAccess,
  listWorkspaceMembers: mockListWorkspaceMembers,
  inviteWorkspaceMember: mockInviteWorkspaceMember,
  listEmailIntegrations: mockListEmailIntegrations,
  sendWorkspaceInviteEmail: mockSendWorkspaceInviteEmail,
  listWorkspaceActivity: mockListWorkspaceActivity,
  listWorkspacePresence: mockListWorkspacePresence,
  heartbeatPresence: mockHeartbeatPresence,
  updateWorkspaceMemberRole: mockUpdateWorkspaceMemberRole,
  listWorkflowComments: mockListWorkflowComments,
  addWorkflowComment: mockAddWorkflowComment,
  setWorkflowCommentResolved: mockSetWorkflowCommentResolved,
  acceptWorkspaceInvite: mockAcceptWorkspaceInvite,
  revokeWorkspaceMember: mockRevokeWorkspaceMember,
  listWorkflowShares: mockListWorkflowShares,
  shareWorkflow: mockShareWorkflow,
  unshareWorkflow: mockUnshareWorkflow,
  getWorkspaceTimezoneSettings: mockGetWorkspaceTimezoneSettings,
  updateWorkspaceTimezonePolicy: mockUpdateWorkspaceTimezonePolicy,
  updateMemberTimezoneOverride: mockUpdateMemberTimezoneOverride,
  listWorkspaceReportingPresets: mockListWorkspaceReportingPresets,
  createWorkspaceReportingPreset: mockCreateWorkspaceReportingPreset,
  deleteWorkspaceReportingPreset: mockDeleteWorkspaceReportingPreset,
}));

vi.mock("../collaboration-extra", () => ({
  listWorkspaceActivity: mockListWorkspaceActivity,
  listWorkspacePresence: mockListWorkspacePresence,
  heartbeatPresence: mockHeartbeatPresence,
  listWorkflowComments: mockListWorkflowComments,
  addWorkflowComment: mockAddWorkflowComment,
  setWorkflowCommentResolved: mockSetWorkflowCommentResolved,
  listWorkspaceTimezoneHistory: mockListWorkspaceTimezoneHistory,
}));

import { collaborationRouter } from "./collaboration";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

const context = (): TrpcContext => ({
  user: {
    id: 7,
    openId: "collaboration-user",
    email: "owner@example.com",
    name: "Workspace Owner",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  } satisfies AuthenticatedUser,
  req: { protocol: "https", headers: { host: "app.example.com" } } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("collaboration router", () => {
  it("returns the authenticated user's workspace and role", async () => {
    mockEnsureWorkspace.mockResolvedValueOnce({ id: 12, name: "Team Ops", slug: "team-ops" });
    mockGetWorkspaceAccess.mockResolvedValueOnce({ role: "owner" });

    const result = await collaborationRouter.createCaller(context()).workspace();

    expect(result).toMatchObject({ id: 12, name: "Team Ops", access: "owner" });
    expect(mockEnsureWorkspace).toHaveBeenCalledWith(7, "owner@example.com");
  });

  it("validates invitation email and forwards the selected role", async () => {
    mockInviteWorkspaceMember.mockResolvedValueOnce({
      memberId: 22,
      inviteToken: "a".repeat(48),
      email: "operator@example.com",
      role: "editor",
    });

    const result = await collaborationRouter.createCaller(context()).invite({
      workspaceId: 12,
      email: "operator@example.com",
      role: "editor",
    });

    expect(result.role).toBe("editor");
    expect(mockInviteWorkspaceMember).toHaveBeenCalledWith(
      7,
      12,
      "operator@example.com",
      "editor"
    );
    await expect(
      collaborationRouter.createCaller(context()).invite({
        workspaceId: 12,
        email: "not-an-email",
        role: "viewer",
      })
    ).rejects.toThrow();
  });

  it("accepts a secure invite and shares a workflow with least privilege", async () => {
    mockAcceptWorkspaceInvite.mockResolvedValueOnce({ workspaceId: 12, role: "viewer" });
    mockShareWorkflow.mockResolvedValueOnce({ shareId: 31, permission: "viewer" });

    const caller = collaborationRouter.createCaller(context());
    const accepted = await caller.acceptInvite({ inviteToken: "b".repeat(48) });
    const shared = await caller.shareWorkflow({
      workspaceId: 12,
      workflowId: 44,
      permission: "viewer",
    });

    expect(accepted).toEqual({ workspaceId: 12, role: "viewer" });
    expect(shared).toEqual({ shareId: 31, permission: "viewer" });
    expect(mockShareWorkflow).toHaveBeenCalledWith(7, 12, 44, "viewer");
  });

  it("lists safe email-provider metadata and sends only when explicitly requested", async () => {
    mockListEmailIntegrations.mockResolvedValueOnce([{ id: 5, agentId: 2, name: "Resend", type: "email" }]);
    mockSendWorkspaceInviteEmail.mockResolvedValueOnce({ accepted: true, provider: "resend" });

    const caller = collaborationRouter.createCaller(context());
    const providers = await caller.emailIntegrations({ workspaceId: 12 });
    const result = await caller.sendInviteEmail({ workspaceId: 12, memberId: 22, integrationId: 5 });

    expect(providers).toEqual([{ id: 5, agentId: 2, name: "Resend", type: "email" }]);
    expect(result).toMatchObject({ accepted: true, provider: "resend" });
    expect(mockSendWorkspaceInviteEmail).toHaveBeenCalledWith(7, 12, 22, 5, "https://app.example.com");
  });

  it("exposes protected activity, presence, role, and comment operations", async () => {
    mockListWorkspaceActivity.mockResolvedValueOnce([{ id: 1, eventType: "member.role_changed" }]);
    mockListWorkspacePresence.mockResolvedValueOnce([{ userId: 7, status: "active" }]);
    mockHeartbeatPresence.mockResolvedValueOnce({ lastSeenAt: new Date() });
    mockUpdateWorkspaceMemberRole.mockResolvedValueOnce({ success: true, role: "viewer" });
    mockListWorkflowComments.mockResolvedValueOnce([{ id: 3, body: "Ship it" }]);
    mockAddWorkflowComment.mockResolvedValueOnce({ commentId: 3 });
    mockSetWorkflowCommentResolved.mockResolvedValueOnce({ success: true, resolved: true });

    const caller = collaborationRouter.createCaller(context());
    expect(await caller.activity({ workspaceId: 12 })).toHaveLength(1);
    expect(await caller.presence({ workspaceId: 12 })).toHaveLength(1);
    await caller.heartbeat({ workspaceId: 12, currentPage: "collaboration" });
    await caller.updateMemberRole({ workspaceId: 12, memberId: 22, role: "viewer" });
    expect(await caller.comments({ workspaceId: 12, workflowId: 44 })).toHaveLength(1);
    await caller.addComment({ workspaceId: 12, workflowId: 44, body: "Ship it" });
    await caller.resolveComment({ workspaceId: 12, commentId: 3, resolved: true });

    expect(mockHeartbeatPresence).toHaveBeenCalledWith(7, 12, "collaboration", undefined);
    expect(mockUpdateWorkspaceMemberRole).toHaveBeenCalledWith(7, 12, 22, "viewer");
    expect(mockAddWorkflowComment).toHaveBeenCalledWith(7, 12, 44, "Ship it");
    expect(mockSetWorkflowCommentResolved).toHaveBeenCalledWith(7, 12, 3, true);
  });

  it("forwards member revocation and workflow unsharing actions", async () => {
    mockRevokeWorkspaceMember.mockResolvedValueOnce({ success: true });
    mockUnshareWorkflow.mockResolvedValueOnce({ success: true });

    const caller = collaborationRouter.createCaller(context());
    await caller.revokeMember({ workspaceId: 12, memberId: 22 });
    await caller.unshareWorkflow({ workspaceId: 12, shareId: 31 });

    expect(mockRevokeWorkspaceMember).toHaveBeenCalledWith(7, 12, 22);
    expect(mockUnshareWorkflow).toHaveBeenCalledWith(7, 12, 31);
  });

  it("exposes workspace policy and personal timezone override settings", async () => {
    mockGetWorkspaceTimezoneSettings.mockResolvedValueOnce({
      policy: "member",
      workspaceTimezone: "UTC",
      memberTimezoneOverride: "Asia/Kolkata",
      canManagePolicy: true,
    });
    mockUpdateWorkspaceTimezonePolicy.mockResolvedValueOnce({ policy: "workspace", workspaceTimezone: "Europe/London" });
    mockUpdateMemberTimezoneOverride.mockResolvedValueOnce({ timezoneOverride: "America/New_York" });

    const caller = collaborationRouter.createCaller(context());
    expect(await caller.timezoneSettings({ workspaceId: 12 })).toMatchObject({ memberTimezoneOverride: "Asia/Kolkata" });
    await caller.updateTimezonePolicy({ workspaceId: 12, policy: "workspace", timezone: "Europe/London" });
    await caller.updateTimezoneOverride({ workspaceId: 12, timezone: "America/New_York" });

    expect(mockUpdateWorkspaceTimezonePolicy).toHaveBeenCalledWith(7, 12, "workspace", "Europe/London");
    expect(mockUpdateMemberTimezoneOverride).toHaveBeenCalledWith(7, 12, "America/New_York");
  });

  it("exposes timezone history and shared reporting preset lifecycle", async () => {
    mockListWorkspaceTimezoneHistory.mockResolvedValueOnce([{ id: 4, eventType: "workspace.timezone_policy_updated" }]);
    mockListWorkspaceReportingPresets.mockResolvedValueOnce([{ id: 9, name: "Quarter close", startDate: "2026-10-01", endDate: "2026-10-31", timezone: "UTC", createdBy: 7 }]);
    mockCreateWorkspaceReportingPreset.mockResolvedValueOnce({ id: 10, name: "Launch window", startDate: "2026-11-01", endDate: "2026-11-06", timezone: "UTC" });
    mockDeleteWorkspaceReportingPreset.mockResolvedValueOnce({ success: true });

    const caller = collaborationRouter.createCaller(context());
    expect(await caller.timezoneHistory({ workspaceId: 12 })).toHaveLength(1);
    expect(await caller.reportingPresets({ workspaceId: 12 })).toHaveLength(1);
    await caller.createReportingPreset({ workspaceId: 12, name: "Launch window", startDate: "2026-11-01", endDate: "2026-11-06", timezone: "UTC" });
    await caller.deleteReportingPreset({ workspaceId: 12, presetId: 10 });

    expect(mockCreateWorkspaceReportingPreset).toHaveBeenCalledWith(7, 12, "Launch window", "2026-11-01", "2026-11-06", "UTC");
    expect(mockDeleteWorkspaceReportingPreset).toHaveBeenCalledWith(7, 12, 10);
  });
});
