import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { invokeLLM } from "../_core/llm";
import { EXECUTABLE_ACTION_TYPES } from "../execution";

interface WorkflowNode {
  id: string;
  type: "trigger" | "action" | "end";
  label: string;
  icon: string;
  actionType?: string;
  config?: Record<string, unknown>;
}

interface GeneratedWorkflow {
  name: string;
  description: string;
  nodes: WorkflowNode[];
  connections: Array<{ from: string; to: string }>;
}

const TRIGGER_TYPES = [
  { id: "manual", name: "Manual", icon: "▶️" },
  { id: "schedule", name: "Schedule", icon: "⏰" },
  { id: "webhook", name: "Webhook", icon: "🔗" },
  { id: "event", name: "Event", icon: "📡" },
];

const ACTION_TYPES = [
  { id: "api_call", name: "API Call", icon: "🌐" },
  { id: "database_query", name: "Database Query", icon: "🗄️" },
  { id: "send_email", name: "Send Email", icon: "📧" },
  { id: "transform_data", name: "Transform Data", icon: "🔄" },
  { id: "conditional", name: "Conditional", icon: "❓" },
  { id: "delay", name: "Delay", icon: "⏳" },
];

const workflowOutputSchema = {
  type: "object",
  properties: {
    name: { type: "string", minLength: 1, maxLength: 120 },
    description: { type: "string", maxLength: 500 },
    trigger: {
      type: "object",
      properties: {
        type: { type: "string", enum: TRIGGER_TYPES.map((type) => type.id) },
        config: { type: "object", additionalProperties: true },
      },
      required: ["type", "config"],
      additionalProperties: false,
    },
    actions: {
      type: "array",
      minItems: 1,
      maxItems: 12,
      items: {
        type: "object",
        properties: {
          type: { type: "string", enum: ACTION_TYPES.map((type) => type.id) },
          config: { type: "object", additionalProperties: true },
        },
        required: ["type", "config"],
        additionalProperties: false,
      },
    },
  },
  required: ["name", "description", "trigger", "actions"],
  additionalProperties: false,
} as const;

const generatedWorkflowSchema = z.object({
  name: z.string().min(1).max(120),
  description: z.string().max(500),
  trigger: z.object({
    type: z.enum(["manual", "schedule", "webhook", "event"]),
    config: z.record(z.string(), z.unknown()),
  }),
  actions: z.array(
    z.object({
      type: z.enum(EXECUTABLE_ACTION_TYPES),
      config: z.record(z.string(), z.unknown()),
    })
  ).min(1).max(12),
});

const getTextContent = (content: unknown) => {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .filter((part): part is { type: "text"; text: string } =>
      Boolean(part && typeof part === "object" && "text" in part && typeof part.text === "string")
    )
    .map((part) => part.text)
    .join("\n");
};

const normalizeGeneratedWorkflow = (workflow: z.infer<typeof generatedWorkflowSchema>): GeneratedWorkflow => {
  const triggerId = "trigger-1";
  const nodes: WorkflowNode[] = [{
    id: triggerId,
    type: "trigger",
    label: TRIGGER_TYPES.find((type) => type.id === workflow.trigger.type)?.name || "Manual",
    icon: TRIGGER_TYPES.find((type) => type.id === workflow.trigger.type)?.icon || "▶️",
    config: { type: workflow.trigger.type, ...workflow.trigger.config },
  }];
  const connections: Array<{ from: string; to: string }> = [];
  let previousNodeId = triggerId;

  workflow.actions.forEach((action, index) => {
    const definition = ACTION_TYPES.find((type) => type.id === action.type)!;
    const nodeId = `action-${index + 1}`;
    nodes.push({
      id: nodeId,
      type: "action",
      label: definition.name,
      icon: definition.icon,
      actionType: action.type,
      config: action.config,
    });
    connections.push({ from: previousNodeId, to: nodeId });
    previousNodeId = nodeId;
  });

  nodes.push({ id: "end-1", type: "end", label: "Complete", icon: "✓" });
  connections.push({ from: previousNodeId, to: "end-1" });

  return { name: workflow.name, description: workflow.description, nodes, connections };
};

const invokeWorkflowModel = async (prompt: string, context?: unknown) => {
  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: `You design executable TrillionAI workflows. Return only JSON matching the provided schema. Use exactly one supported trigger type (${TRIGGER_TYPES.map((type) => type.id).join(", ")}) and 1-12 supported action types (${ACTION_TYPES.map((type) => type.id).join(", ")}). Keep configs practical and safe: never include secrets, credentials, destructive SQL, or invented integration IDs. If the request is ambiguous, choose a manual trigger and a minimal API call or transform action.`,
      },
      {
        role: "user",
        content: `Create a workflow from this request:\n${prompt}\n\nAdditional context (may be empty):\n${JSON.stringify(context ?? {})}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "trillionai_workflow",
        strict: true,
        schema: workflowOutputSchema,
      },
    },
    maxTokens: 1800,
  });

  const content = response.choices[0]?.message?.content;
  if (!content) throw new Error("The AI returned an empty workflow");
  const parsed = generatedWorkflowSchema.parse(JSON.parse(getTextContent(content)));
  return normalizeGeneratedWorkflow(parsed);
};

const parseWorkflowDescription = (description: string): GeneratedWorkflow => {
  const lines = description.split("\n").filter((line) => line.trim());

  let workflowName = "Generated Workflow";
  let workflowDescription = "";
  const nodes: WorkflowNode[] = [];
  const connections: Array<{ from: string; to: string }> = [];

  // Extract workflow name
  const titleMatch = description.match(/workflow[:\s]+([^\n.]+)/i);
  if (titleMatch) {
    workflowName = titleMatch[1].trim();
  }

  // Parse trigger
  const triggerMatch = description.match(/trigger[:\s]+([a-z_]+)/i);
  const triggerType = triggerMatch ? triggerMatch[1].toLowerCase() : "manual";

  const triggerId = "trigger-1";
  nodes.push({
    id: triggerId,
    type: "trigger",
    label: triggerType.charAt(0).toUpperCase() + triggerType.slice(1),
    icon: TRIGGER_TYPES.find((t) => t.id === triggerType)?.icon || "▶️",
    config: { type: triggerType },
  });

  // Parse actions
  let previousNodeId = triggerId;
  let actionIndex = 1;

  const actionMatches = Array.from(
    description.matchAll(
      /(?:action|step)\s*\d*[:\s]+([a-z_\s]+?)(?=action|step|\n|$)/gi
    )
  );

  for (const match of actionMatches) {
    const actionText = match[1].trim();
    const actionType = findBestActionMatch(actionText);

    if (actionType) {
      const nodeId = `action-${actionIndex}`;
      nodes.push({
        id: nodeId,
        type: "action",
        label: actionType.name,
        icon: actionType.icon,
        actionType: actionType.id,
        config: extractActionConfig(actionText, actionType.id),
      });

      connections.push({ from: previousNodeId, to: nodeId });
      previousNodeId = nodeId;
      actionIndex++;
    }
  }

  // Add end node if there are actions
  if (nodes.length > 1) {
    const endNodeId = "end-1";
    nodes.push({
      id: endNodeId,
      type: "end",
      label: "Complete",
      icon: "✓",
    });
    connections.push({ from: previousNodeId, to: endNodeId });
  }

  return {
    name: workflowName,
    description: workflowDescription,
    nodes,
    connections,
  };
};

const findBestActionMatch = (
  actionText: string
): (typeof ACTION_TYPES)[0] | null => {
  const lowerText = actionText.toLowerCase();

  if (
    lowerText.includes("email") ||
    lowerText.includes("send") ||
    lowerText.includes("notify")
  ) {
    return ACTION_TYPES.find((a) => a.id === "send_email") || null;
  }
  if (
    lowerText.includes("api") ||
    lowerText.includes("call") ||
    lowerText.includes("request")
  ) {
    return ACTION_TYPES.find((a) => a.id === "api_call") || null;
  }
  if (
    lowerText.includes("database") ||
    lowerText.includes("query") ||
    lowerText.includes("insert") ||
    lowerText.includes("update")
  ) {
    return ACTION_TYPES.find((a) => a.id === "database_query") || null;
  }
  if (
    lowerText.includes("transform") ||
    lowerText.includes("format") ||
    lowerText.includes("map")
  ) {
    return ACTION_TYPES.find((a) => a.id === "transform_data") || null;
  }
  if (
    lowerText.includes("if") ||
    lowerText.includes("condition") ||
    lowerText.includes("check")
  ) {
    return ACTION_TYPES.find((a) => a.id === "conditional") || null;
  }
  if (lowerText.includes("wait") || lowerText.includes("delay")) {
    return ACTION_TYPES.find((a) => a.id === "delay") || null;
  }

  return null;
};

const extractActionConfig = (
  actionText: string,
  actionType: string
): Record<string, unknown> => {
  const config: Record<string, unknown> = {};

  switch (actionType) {
    case "send_email": {
      const emailMatch = actionText.match(/to[:\s]+([^\n,]+)/i);
      if (emailMatch) config.to = emailMatch[1].trim();
      config.subject = "Automated Email";
      config.body = "Automated workflow notification";
      break;
    }

    case "api_call":
      const methodMatch = actionText.match(/(get|post|put|delete|patch)/i);
      if (methodMatch) config.method = methodMatch[1].toUpperCase();
      const urlMatch = actionText.match(/(?:to|call|url)[:\s]+([^\s,\n]+)/i);
      if (urlMatch) config.url = urlMatch[1].trim();
      break;

    case "database_query": {
      const queryMatch = actionText.match(
        /(?:query|select|insert|update)[:\s]+([^\n]+)/i
      );
      if (queryMatch) config.query = queryMatch[1].trim();
      break;
    }

    case "transform_data":
      config.script = "return data;";
      break;

    case "conditional":
      const condMatch = actionText.match(/if[:\s]+([^\n]+)/i);
      if (condMatch) config.condition = condMatch[1].trim();
      break;

    case "delay":
      const delayMatch = actionText.match(/(\d+)\s*(seconds?|minutes?|hours?)/i);
      if (delayMatch) config.duration = parseInt(delayMatch[1]);
      break;
  }

  return config;
};

export const aiRouter = router({
  generateWorkflow: publicProcedure
    .input(
      z.object({
        prompt: z.string().min(10).max(1000),
        context: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const workflow = await invokeWorkflowModel(input.prompt, input.context);

        return {
          success: true,
          workflow,
          rawDescription: `${workflow.name}\n\n${workflow.description}`,
        };
      } catch (error) {
        return {
          success: false,
          error: (error as Error).message,
          workflow: null,
        };
      }
    }),

  refineWorkflow: publicProcedure
    .input(
      z.object({
        workflow: z.any(),
        feedback: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Simulate workflow refinement
        const refinedDescription = `Refined Workflow based on feedback:
${input.feedback}

The workflow has been updated to incorporate your suggestions. You can now review the changes in the canvas.`;

        const refinedWorkflow = parseWorkflowDescription(refinedDescription);

        return {
          success: true,
          workflow: refinedWorkflow,
          rawDescription: refinedDescription,
        };
      } catch (error) {
        return {
          success: false,
          error: (error as Error).message,
        };
      }
    }),

  suggestOptimizations: publicProcedure
    .input(
      z.object({
        workflow: z.any(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const suggestions = `Workflow Optimization Suggestions:

1. **Performance**: Add caching for frequently accessed data
2. **Error Handling**: Implement retry logic with exponential backoff
3. **Validation**: Add input validation before database operations
4. **Security**: Use encrypted connections for API calls
5. **Cost**: Consider batch processing to reduce API calls

These optimizations will improve reliability, security, and cost-efficiency.`;

        return {
          success: true,
          suggestions,
        };
      } catch (error) {
        return {
          success: false,
          error: (error as Error).message,
        };
      }
    }),

  explainWorkflow: publicProcedure
    .input(
      z.object({
        workflow: z.any(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const explanation = `Workflow Explanation:

**What it does**: This workflow automates a business process by connecting multiple systems and services.

**When it runs**: The workflow is triggered based on a schedule, webhook, or manual activation.

**Data Processing**: It collects data from various sources, transforms it into a usable format, and stores or sends it to the appropriate destination.

**Expected Outcomes**: The workflow produces automated actions that reduce manual work and improve efficiency.

**Potential Issues**: Monitor for API failures, data validation errors, and ensure proper error handling is configured.`;

        return {
          success: true,
          explanation,
        };
      } catch (error) {
        return {
          success: false,
          error: (error as Error).message,
        };
      }
    }),
});
