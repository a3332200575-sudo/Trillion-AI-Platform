import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "../_core/context";

const {
  mockListWebhooks,
  mockCreateWebhook,
  mockRotateWebhookSecret,
  mockSetWebhookStatus,
  mockGetWebhookDeliveries,
  mockGetWorkflowById,
} = vi.hoisted(() => ({
  mockListWebhooks: vi.fn(),
  mockCreateWebhook: vi.fn(),
  mockRotateWebhookSecret: vi.fn(),
  mockSetWebhookStatus: vi.fn(),
  mockGetWebhookDeliveries: vi.fn(),
  mockGetWorkflowById: vi.fn(),
}));

vi.mock("../webhooks", () => ({
  listWebhooks: mockListWebhooks,
  createWebhook: mockCreateWebhook,
  rotateWebhookSecret: mockRotateWebhookSecret,
  setWebhookStatus: mockSetWebhookStatus,
  getWebhookDeliveries: mockGetWebhookDeliveries,
}));
vi.mock("../workflows", () => ({ getWorkflowById: mockGetWorkflowById }));

import { webhookRouter } from "./webhooks";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

const createContext = (): TrpcContext => ({
  user: {
    id: 7,
    openId: "webhook-test-user",
    email: "webhook@example.com",
    name: "Webhook Tester",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  } as AuthenticatedUser,
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("webhook router", () => {
  it("lists a user’s endpoints", async () => {
    const endpoints = [{ id: 1, userId: 7, workflowId: 10, name: "Leads", status: "active" }];
    mockListWebhooks.mockResolvedValueOnce(endpoints);

    const result = await webhookRouter.createCaller(createContext()).list();

    expect(result).toEqual(endpoints);
    expect(mockListWebhooks).toHaveBeenCalledWith(7);
  });

  it("creates an endpoint only for an accessible workflow", async () => {
    mockGetWorkflowById.mockResolvedValueOnce({ id: 10, userId: 7 });
    mockCreateWebhook.mockResolvedValueOnce({
      id: 1,
      name: "Leads",
      workflowId: 10,
      endpointToken: "token",
      signingSecret: "secret",
      status: "active",
    });

    const result = await webhookRouter.createCaller(createContext()).create({
      name: "Leads",
      workflowId: 10,
    });

    expect(result.signingSecret).toBe("secret");
    expect(mockCreateWebhook).toHaveBeenCalledWith(7, { name: "Leads", workflowId: 10 });
  });

  it("returns delivery history only for a listed endpoint", async () => {
    mockListWebhooks.mockResolvedValueOnce([{ id: 1, userId: 7 }]);
    mockGetWebhookDeliveries.mockResolvedValueOnce([{ id: 4, status: "accepted" }]);

    const result = await webhookRouter.createCaller(createContext()).deliveries({ webhookId: 1 });

    expect(result).toEqual([{ id: 4, status: "accepted" }]);
    expect(mockGetWebhookDeliveries).toHaveBeenCalledWith(7, 1);
  });

  it("rejects delivery history for an endpoint the user cannot access", async () => {
    mockListWebhooks.mockResolvedValueOnce([]);

    await expect(
      webhookRouter.createCaller(createContext()).deliveries({ webhookId: 99 })
    ).rejects.toThrow("Webhook not found");
  });
});
