import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  getUserWorkflows,
  getWorkflowById,
  createWorkflow,
  updateWorkflow,
  deleteWorkflow,
  getAgentIntegrations,
  getWorkflowVersions,
  restoreWorkflowVersion,
} from "../workflows";

const triggerSchema = z.enum(["schedule", "webhook", "event", "manual"]);

const actionSchema = z.object({
  type: z.string(),
  integrationId: z.number(),
  config: z.record(z.string(), z.unknown()),
});

const retryPolicySchema = z.object({
  maxAttempts: z.number().int().min(1).max(5),
  backoffMs: z.number().int().min(0).max(10_000),
  maxBackoffMs: z.number().int().min(0).max(60_000),
});

const workflowInputSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  agentId: z.number(),
  trigger: triggerSchema,
  triggerConfig: z.record(z.string(), z.unknown()).optional(),
  actions: z.array(actionSchema).optional(),
  retryPolicy: retryPolicySchema.optional(),
});

export const workflowRouter = router({
  /**
   * List all workflows for an agent
   */
  list: protectedProcedure
    .input(z.object({ agentId: z.number() }))
    .query(async ({ ctx, input }) => {
      return await getUserWorkflows(ctx.user.id, input.agentId);
    }),

  /**
   * Get a single workflow by ID
   */
  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const workflow = await getWorkflowById(ctx.user.id, input.id);
      if (!workflow) {
        throw new Error("Workflow not found");
      }
      return workflow as any;
    }),

  /**
   * Create a new workflow
   */
  create: protectedProcedure
    .input(workflowInputSchema)
    .mutation(async ({ ctx, input }) => {
      return createWorkflow(ctx.user.id, input.agentId, {
        name: input.name,
        description: input.description,
        trigger: input.trigger,
        triggerConfig: input.triggerConfig,
        actions: input.actions,
        retryPolicy: input.retryPolicy,
      });
    }),

  /**
   * Update an existing workflow
   */
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          trigger: triggerSchema.optional(),
          triggerConfig: z.record(z.string(), z.unknown()).optional(),
          actions: z.array(actionSchema).optional(),
          retryPolicy: retryPolicySchema.optional(),
          isActive: z.boolean().optional(),
          changeSummary: z.string().max(500).optional(),
        }),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const workflow = await getWorkflowById(ctx.user.id, input.id);
      if (!workflow) {
        throw new Error("Workflow not found");
      }
      return await updateWorkflow(ctx.user.id, input.id, input.data);
    }),

  /**
   * List immutable snapshots for a workflow, newest first
   */
  versions: protectedProcedure
    .input(z.object({ workflowId: z.number() }))
    .query(async ({ ctx, input }) => {
      const workflow = await getWorkflowById(ctx.user.id, input.workflowId);
      if (!workflow) throw new Error("Workflow not found");
      return getWorkflowVersions(ctx.user.id, input.workflowId);
    }),

  /**
   * Restore a workflow snapshot and record the restore as a new version
   */
  restoreVersion: protectedProcedure
    .input(
      z.object({
        workflowId: z.number(),
        versionId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const workflow = await getWorkflowById(ctx.user.id, input.workflowId);
      if (!workflow) throw new Error("Workflow not found");
      return restoreWorkflowVersion(
        ctx.user.id,
        input.workflowId,
        input.versionId
      );
    }),

  /**
   * Delete a workflow
   */
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const workflow = await getWorkflowById(ctx.user.id, input.id);
      if (!workflow) {
        throw new Error("Workflow not found");
      }
      return deleteWorkflow(ctx.user.id, input.id);
    }),

  /**
   * Get available integrations for an agent
   */
  getIntegrations: protectedProcedure
    .input(z.object({ agentId: z.number() }))
    .query(async ({ ctx, input }) => {
      return await getAgentIntegrations(ctx.user.id, input.agentId);
    }),

  /**
   * Get available action types
   */
  getActionTypes: protectedProcedure.query(async () => {
    return [
      {
        id: "send_email",
        name: "Send Email",
        description: "Send email through a connected SendGrid or Resend integration",
        icon: "Mail",
        inputs: [
          { key: "to", label: "To", type: "text", required: true },
          { key: "subject", label: "Subject", type: "text", required: true },
          { key: "body", label: "Body", type: "textarea", required: true },
        ],
      },
      {
        id: "api_call",
        name: "API Call",
        description: "Make an HTTP request to an external API",
        icon: "Globe",
        inputs: [
          { key: "method", label: "Method", type: "select", options: ["GET", "POST", "PUT", "DELETE"], required: true },
          { key: "url", label: "URL", type: "text", required: true },
          { key: "headers", label: "Headers", type: "json", required: false },
          { key: "body", label: "Body", type: "json", required: false },
        ],
      },
      {
        id: "database_query",
        name: "Database Query",
        description: "Run one parameterized query through a connected MySQL integration",
        icon: "Database",
        inputs: [
          { key: "query", label: "SQL Query", type: "textarea", required: true },
          { key: "params", label: "Parameters", type: "json", required: false },
        ],
      },
      {
        id: "transform_data",
        name: "Transform Data",
        description: "Transform data using JavaScript",
        icon: "Zap",
        inputs: [
          { key: "script", label: "JavaScript", type: "textarea", required: true },
        ],
      },
      {
        id: "conditional",
        name: "Conditional Branch",
        description: "Branch workflow based on a condition",
        icon: "GitBranch",
        inputs: [
          { key: "condition", label: "Condition", type: "textarea", required: true },
        ],
      },
      {
        id: "delay",
        name: "Delay",
        description: "Delay execution for a specified duration",
        icon: "Clock",
        inputs: [
          { key: "duration", label: "Duration (ms)", type: "number", required: true },
        ],
      },
    ];
  }),

  /**
   * Get available trigger types
   */
  getTriggerTypes: protectedProcedure.query(async () => {
    return [
      {
        id: "schedule",
        name: "Schedule",
        description: "Run on a schedule (cron)",
        icon: "Calendar",
        inputs: [
          { key: "cron", label: "Cron Expression", type: "text", placeholder: "0 0 * * *", required: true },
        ],
      },
      {
        id: "webhook",
        name: "Webhook",
        description: "Trigger via HTTP webhook",
        icon: "Globe",
        inputs: [
          { key: "path", label: "Webhook Path", type: "text", required: true },
        ],
      },
      {
        id: "event",
        name: "Event",
        description: "Trigger on a specific event",
        icon: "Bell",
        inputs: [
          { key: "eventType", label: "Event Type", type: "text", required: true },
        ],
      },
      {
        id: "manual",
        name: "Manual",
        description: "Trigger manually",
        icon: "Play",
        inputs: [],
      },
    ];
  }),
});
