import { describe, expect, it, vi } from "vitest";

const { mockInvokeLLM } = vi.hoisted(() => ({
  mockInvokeLLM: vi.fn(),
}));

vi.mock("../_core/llm", () => ({ invokeLLM: mockInvokeLLM }));

import { aiRouter } from "./ai";

const caller = aiRouter.createCaller({
  user: null,
  req: { protocol: "https", headers: {} } as any,
  res: {} as any,
});

describe("AI workflow generation", () => {
  it("normalizes a structured LLM response into connected workflow nodes", async () => {
    mockInvokeLLM.mockResolvedValueOnce({
      choices: [{
        message: {
          role: "assistant",
          content: JSON.stringify({
            name: "Lead Intake",
            description: "Capture and enrich new leads",
            trigger: { type: "webhook", config: { path: "/leads" } },
            actions: [
              { type: "transform_data", config: { script: "return data" } },
              { type: "api_call", config: { method: "POST", url: "https://api.example.com/leads" } },
            ],
          }),
        },
      }],
    });

    const result = await caller.generateWorkflow({
      prompt: "When a lead arrives, clean it and notify sales by email",
    });

    expect(result.success).toBe(true);
    expect(result.workflow?.name).toBe("Lead Intake");
    expect(result.workflow?.nodes.map((node) => node.type)).toEqual([
      "trigger",
      "action",
      "action",
      "end",
    ]);
    expect(result.workflow?.connections).toEqual([
      { from: "trigger-1", to: "action-1" },
      { from: "action-1", to: "action-2" },
      { from: "action-2", to: "end-1" },
    ]);
    expect(mockInvokeLLM).toHaveBeenCalledOnce();
  });

  it("returns a controlled failure when the model returns invalid JSON", async () => {
    mockInvokeLLM.mockResolvedValueOnce({
      choices: [{ message: { role: "assistant", content: "not-json" } }],
    });

    const result = await caller.generateWorkflow({
      prompt: "Build a workflow that handles customer onboarding",
    });

    expect(result.success).toBe(false);
    expect(result.workflow).toBeNull();
    expect(result.error).toBeTruthy();
  });
});
