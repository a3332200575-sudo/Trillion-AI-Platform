import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createWebhook,
  getWebhookDeliveries,
  listWebhooks,
  rotateWebhookSecret,
  setWebhookStatus,
} from "../webhooks";
import { getWorkflowById } from "../workflows";

export const webhookRouter = router({
  list: protectedProcedure.query(({ ctx }) => listWebhooks(ctx.user.id)),

  create: protectedProcedure
    .input(
      z.object({
        name: z.string().trim().min(1).max(255),
        workflowId: z.number().int().positive(),
      })
    )
    .mutation(({ ctx, input }) => createWebhook(ctx.user.id, input)),

  rotateSecret: protectedProcedure
    .input(z.object({ webhookId: z.number().int().positive() }))
    .mutation(({ ctx, input }) => rotateWebhookSecret(ctx.user.id, input.webhookId)),

  setStatus: protectedProcedure
    .input(
      z.object({
        webhookId: z.number().int().positive(),
        status: z.enum(["active", "disabled"]),
      })
    )
    .mutation(({ ctx, input }) =>
      setWebhookStatus(ctx.user.id, input.webhookId, input.status)
    ),

  deliveries: protectedProcedure
    .input(z.object({ webhookId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const webhooks = await listWebhooks(ctx.user.id);
      if (!webhooks.some((webhook) => webhook.id === input.webhookId)) {
        throw new Error("Webhook not found");
      }
      return getWebhookDeliveries(ctx.user.id, input.webhookId);
    }),

  workflowExists: protectedProcedure
    .input(z.object({ workflowId: z.number().int().positive() }))
    .query(async ({ ctx, input }) => Boolean(await getWorkflowById(ctx.user.id, input.workflowId))),
});
