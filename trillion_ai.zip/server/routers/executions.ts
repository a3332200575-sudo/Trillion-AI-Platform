import { and, desc, eq, gte, lte, lt, or, sql } from "drizzle-orm";
import { z } from "zod";
import { executionLogs, workflows } from "../../drizzle/schema";
import { executeWorkflow } from "../execution";
import { getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

const sourceSchema = z.enum(["webhook", "manual", "schedule", "event"]);

type Cursor = { id: number; createdAt: string };

const encodeCursor = (cursor: Cursor) => Buffer.from(JSON.stringify(cursor)).toString("base64url");
const decodeCursor = (value?: string): Cursor | null => {
  if (!value) return null;
  try {
    const parsed = JSON.parse(Buffer.from(value, "base64url").toString("utf8"));
    if (typeof parsed.id === "number" && typeof parsed.createdAt === "string") return parsed;
  } catch {
    // Invalid cursors are treated as the first page rather than exposing an error.
  }
  return null;
};

const getSource = (input: unknown) => {
  if (!input || typeof input !== "object" || Array.isArray(input)) return "manual" as const;
  const execution = (input as Record<string, unknown>)._execution;
  if (!execution || typeof execution !== "object" || Array.isArray(execution)) return "manual" as const;
  const source = (execution as Record<string, unknown>).source;
  return sourceSchema.safeParse(source).success ? (source as z.infer<typeof sourceSchema>) : "manual" as const;
};

const demoInput = (status: string) => ({
  _demoMode: true,
  _execution: { source: "manual" },
  payload: { demo: true, status },
});

export const executionRouter = router({
  list: protectedProcedure
    .input(z.object({
      status: z.enum(["all", "success", "failed", "pending"]).default("all"),
      workflowId: z.number().int().positive().optional(),
      source: sourceSchema.optional(),
      search: z.string().max(120).optional(),
      from: z.string().datetime().optional(),
      to: z.string().datetime().optional(),
      cursor: z.string().optional(),
      limit: z.number().int().min(1).max(100).default(25),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { items: [], nextCursor: null };
      const conditions = [eq(executionLogs.userId, ctx.user.id)];
      if (input.workflowId) conditions.push(eq(executionLogs.workflowId, input.workflowId));
      if (input.status !== "all") conditions.push(eq(executionLogs.status, input.status));
      if (input.from) conditions.push(gte(executionLogs.createdAt, new Date(input.from)));
      if (input.to) conditions.push(lte(executionLogs.createdAt, new Date(input.to)));

      const cursor = decodeCursor(input.cursor);
      if (cursor) {
        const cursorDate = new Date(cursor.createdAt);
        if (!Number.isNaN(cursorDate.getTime())) {
          conditions.push(
            or(
              lt(executionLogs.createdAt, cursorDate),
              and(eq(executionLogs.createdAt, cursorDate), lt(executionLogs.id, cursor.id))
            )!
          );
        }
      }

      const rows = await db
        .select({
          id: executionLogs.id,
          userId: executionLogs.userId,
          agentId: executionLogs.agentId,
          workflowId: executionLogs.workflowId,
          workflowName: workflows.name,
          status: executionLogs.status,
          input: executionLogs.input,
          output: executionLogs.output,
          error: executionLogs.error,
          executionTime: executionLogs.executionTime,
          attempts: executionLogs.attempts,
          replayedFromId: executionLogs.replayedFromId,
          revenue: executionLogs.revenue,
          createdAt: executionLogs.createdAt,
        })
        .from(executionLogs)
        .leftJoin(workflows, eq(executionLogs.workflowId, workflows.id))
        .where(and(...conditions))
        .orderBy(desc(executionLogs.createdAt), desc(executionLogs.id))
        .limit(Math.min(input.limit * 3 + 1, 200));

      const filtered = rows.filter((row) => {
        if (input.source && getSource(row.input) !== input.source) return false;
        if (!input.search) return true;
        const haystack = `${row.id} ${row.workflowName ?? ""} ${row.error ?? ""}`.toLowerCase();
        return haystack.includes(input.search.toLowerCase());
      });
      const items = filtered.slice(0, input.limit);
      const last = items[items.length - 1];
      return {
        items,
        nextCursor: filtered.length > input.limit && last
          ? encodeCursor({ id: last.id, createdAt: last.createdAt.toISOString() })
          : null,
      };
    }),

  get: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const [row] = await db
        .select()
        .from(executionLogs)
        .where(and(eq(executionLogs.id, input.id), eq(executionLogs.userId, ctx.user.id)))
        .limit(1);
      if (!row) throw new Error("Execution log not found");
      return row;
    }),

  replay: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const [row] = await db
        .select()
        .from(executionLogs)
        .where(and(eq(executionLogs.id, input.id), eq(executionLogs.userId, ctx.user.id)))
        .limit(1);
      if (!row || !row.workflowId) throw new Error("This execution cannot be replayed");
      const originalInput = row.input && typeof row.input === "object" && !Array.isArray(row.input)
        ? { ...(row.input as Record<string, unknown>) }
        : {};
      delete originalInput._execution;
      return executeWorkflow(ctx.user.id, row.workflowId, originalInput, {
        source: getSource(row.input),
        replayedFromId: row.id,
      });
    }),

  demoSeed: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    await db.insert(executionLogs).values([
      { userId: ctx.user.id, agentId: 0, workflowId: null, status: "success", input: demoInput("success"), output: { final: { demo: true, accepted: true } }, error: null, executionTime: 320, attempts: 1, replayedFromId: null, revenue: "0.00" },
      { userId: ctx.user.id, agentId: 0, workflowId: null, status: "failed", input: demoInput("failed"), output: { final: { demo: true } }, error: "Demo provider timeout", executionTime: 840, attempts: 3, replayedFromId: null, revenue: "0.00" },
      { userId: ctx.user.id, agentId: 0, workflowId: null, status: "pending", input: demoInput("pending"), output: null, error: null, executionTime: null, attempts: 1, replayedFromId: null, revenue: "0.00" },
    ]);
    return { seeded: true };
  }),

  demoClear: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");
    await db.delete(executionLogs).where(
      and(eq(executionLogs.userId, ctx.user.id), sql`JSON_EXTRACT(${executionLogs.input}, '$._demoMode') = true`)
    );
    return { cleared: true };
  }),
});
