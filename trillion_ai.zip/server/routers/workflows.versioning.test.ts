import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "../_core/context";

const {
  mockGetWorkflowById,
  mockGetWorkflowVersions,
  mockRestoreWorkflowVersion,
} = vi.hoisted(() => ({
  mockGetWorkflowById: vi.fn(),
  mockGetWorkflowVersions: vi.fn(),
  mockRestoreWorkflowVersion: vi.fn(),
}));

vi.mock("../workflows", () => ({
  getUserWorkflows: vi.fn(),
  getWorkflowById: mockGetWorkflowById,
  createWorkflow: vi.fn(),
  updateWorkflow: vi.fn(),
  deleteWorkflow: vi.fn(),
  getAgentIntegrations: vi.fn(),
  getWorkflowVersions: mockGetWorkflowVersions,
  restoreWorkflowVersion: mockRestoreWorkflowVersion,
}));

import { workflowRouter } from "./workflows";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createWorkflowContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 7,
    openId: "versioning-test-user",
    email: "versioning@example.com",
    name: "Versioning Test User",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const versions = [
  {
    id: 22,
    workflowId: 10,
    userId: 7,
    version: 2,
    name: "Revenue Workflow",
    description: "Updated revenue automation",
    trigger: "manual" as const,
    triggerConfig: {},
    actions: [],
    changeSummary: "Added retry handling",
    createdAt: new Date("2026-10-05T10:00:00Z"),
  },
  {
    id: 21,
    workflowId: 10,
    userId: 7,
    version: 1,
    name: "Revenue Workflow",
    description: "Initial automation",
    trigger: "manual" as const,
    triggerConfig: {},
    actions: [],
    changeSummary: "Initial version",
    createdAt: new Date("2026-10-05T09:00:00Z"),
  },
];

describe("workflow versioning router", () => {
  it("returns newest workflow snapshots for an accessible workflow", async () => {
    mockGetWorkflowById.mockResolvedValueOnce({ id: 10, userId: 7 });
    mockGetWorkflowVersions.mockResolvedValueOnce(versions);

    const caller = workflowRouter.createCaller(createWorkflowContext());
    const result = await caller.versions({ workflowId: 10 });

    expect(result).toEqual(versions);
    expect(result[0].version).toBe(2);
    expect(mockGetWorkflowVersions).toHaveBeenCalledWith(7, 10);
  });

  it("restores the selected version and delegates ownership to the data layer", async () => {
    mockGetWorkflowById.mockResolvedValueOnce({ id: 10, userId: 7 });
    mockRestoreWorkflowVersion.mockResolvedValueOnce({ affectedRows: 1 });

    const caller = workflowRouter.createCaller(createWorkflowContext());
    const result = await caller.restoreVersion({ workflowId: 10, versionId: 21 });

    expect(result).toEqual({ affectedRows: 1 });
    expect(mockRestoreWorkflowVersion).toHaveBeenCalledWith(7, 10, 21);
  });
});
