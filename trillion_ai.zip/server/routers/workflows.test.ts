import { describe, it, expect } from "vitest";
import { workflowRouter } from "./workflows";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createWorkflowContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("workflow router", () => {
  it("should return available action types", async () => {
    const ctx = createWorkflowContext();
    const caller = workflowRouter.createCaller(ctx);

    const actionTypes = await caller.getActionTypes();

    expect(actionTypes).toBeDefined();
    expect(Array.isArray(actionTypes)).toBe(true);
    expect(actionTypes.length).toBeGreaterThan(0);
    expect(actionTypes[0]).toHaveProperty("id");
    expect(actionTypes[0]).toHaveProperty("name");
    expect(actionTypes[0]).toHaveProperty("description");
  });

  it("should return available trigger types", async () => {
    const ctx = createWorkflowContext();
    const caller = workflowRouter.createCaller(ctx);

    const triggerTypes = await caller.getTriggerTypes();

    expect(triggerTypes).toBeDefined();
    expect(Array.isArray(triggerTypes)).toBe(true);
    expect(triggerTypes.length).toBeGreaterThan(0);
    
    const triggerIds = triggerTypes.map((t) => t.id);
    expect(triggerIds).toContain("schedule");
    expect(triggerIds).toContain("webhook");
    expect(triggerIds).toContain("event");
    expect(triggerIds).toContain("manual");
  });

  it("should have proper action type structure", async () => {
    const ctx = createWorkflowContext();
    const caller = workflowRouter.createCaller(ctx);

    const actionTypes = await caller.getActionTypes();
    const sendEmailAction = actionTypes.find((t) => t.id === "api_call");

    expect(sendEmailAction).toBeDefined();
    expect(sendEmailAction?.inputs).toBeDefined();
    expect(Array.isArray(sendEmailAction?.inputs)).toBe(true);
    expect(sendEmailAction?.inputs.length).toBeGreaterThan(0);
  });

  it("should have proper trigger type structure", async () => {
    const ctx = createWorkflowContext();
    const caller = workflowRouter.createCaller(ctx);

    const triggerTypes = await caller.getTriggerTypes();
    const scheduleTrigger = triggerTypes.find((t) => t.id === "schedule");

    expect(scheduleTrigger).toBeDefined();
    expect(scheduleTrigger?.inputs).toBeDefined();
    expect(Array.isArray(scheduleTrigger?.inputs)).toBe(true);
  });

  it("should reject version history for an inaccessible workflow", async () => {
    const ctx = createWorkflowContext();
    const caller = workflowRouter.createCaller(ctx);

    await expect(caller.versions({ workflowId: 999999 })).rejects.toThrow(
      "Workflow not found"
    );
  });

  it("should reject restoring a version from an inaccessible workflow", async () => {
    const ctx = createWorkflowContext();
    const caller = workflowRouter.createCaller(ctx);

    await expect(
      caller.restoreVersion({ workflowId: 999999, versionId: 999999 })
    ).rejects.toThrow("Workflow not found");
  });
});
