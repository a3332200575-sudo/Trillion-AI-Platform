import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "../_core/context";

const { mockGetDb, mockExecuteWorkflow } = vi.hoisted(() => ({
  mockGetDb: vi.fn(),
  mockExecuteWorkflow: vi.fn(),
}));

vi.mock("../db", () => ({ getDb: mockGetDb }));
vi.mock("../execution", () => ({ executeWorkflow: mockExecuteWorkflow }));

import { executionRouter } from "./executions";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

const context = (): TrpcContext => ({
  user: {
    id: 7,
    openId: "execution-user",
    email: "execution@example.com",
    name: "Execution User",
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  } satisfies AuthenticatedUser,
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

const makeDb = (result: unknown) => {
  const builder: any = {
    from: vi.fn(() => builder),
    leftJoin: vi.fn(() => builder),
    where: vi.fn(() => builder),
    orderBy: vi.fn(() => builder),
    limit: vi.fn().mockResolvedValue(result),
  };
  return { select: vi.fn(() => builder) };
};

describe("execution router", () => {
  it("filters execution logs by status, source, and search text", async () => {
    mockGetDb.mockResolvedValueOnce(makeDb([
      {
        id: 12,
        userId: 7,
        agentId: 2,
        workflowId: 9,
        workflowName: "Lead Intake",
        status: "failed",
        input: { _execution: { source: "webhook" } },
        output: {},
        error: "provider timeout",
        executionTime: 1000,
        attempts: 3,
        replayedFromId: null,
        revenue: "0.00",
        createdAt: new Date(),
      },
    ]));

    const result = await executionRouter.createCaller(context()).list({
      status: "failed",
      source: "webhook",
      search: "lead",
      limit: 20,
    });

    expect(result.items).toHaveLength(1);
    expect(result.items[0].id).toBe(12);
    expect(result.nextCursor).toBeNull();
  });

  it("replays an owned execution with its original input and lineage", async () => {
    mockGetDb.mockResolvedValueOnce(makeDb([{
      id: 21,
      userId: 7,
      workflowId: 9,
      status: "failed",
      input: { payload: { leadId: "L-1" }, _execution: { source: "webhook", deliveryId: 4 } },
    }]));
    mockExecuteWorkflow.mockResolvedValueOnce({ executionLogId: 22, status: "success", error: null });

    const result = await executionRouter.createCaller(context()).replay({ id: 21 });

    expect(result.executionLogId).toBe(22);
    expect(mockExecuteWorkflow).toHaveBeenCalledWith(
      7,
      9,
      { payload: { leadId: "L-1" } },
      { source: "webhook", replayedFromId: 21 }
    );
  });

  it("returns an owned execution detail record", async () => {
    mockGetDb.mockResolvedValueOnce(makeDb([{
      id: 31,
      userId: 7,
      workflowId: 9,
      status: "success",
      input: { payload: { leadId: "L-2" } },
      output: { final: { accepted: true } },
      error: null,
      attempts: 2,
      replayedFromId: 21,
    }]));

    const result = await executionRouter.createCaller(context()).get({ id: 31 });

    expect(result).toMatchObject({
      id: 31,
      status: "success",
      attempts: 2,
      replayedFromId: 21,
    });
  });

  it("seeds safe demo executions for the authenticated owner", async () => {
    const values = vi.fn().mockResolvedValue([]);
    mockGetDb.mockResolvedValueOnce({ insert: vi.fn(() => ({ values })) });

    const result = await executionRouter.createCaller(context()).demoSeed();

    expect(result).toEqual({ seeded: true });
    expect(values).toHaveBeenCalledTimes(1);
    expect(values.mock.calls[0][0]).toHaveLength(3);
    expect(values.mock.calls[0][0][0].userId).toBe(7);
    expect(values.mock.calls[0][0][0].workflowId).toBeNull();
    expect(values.mock.calls[0][0][0].input._demoMode).toBe(true);
  });
});
