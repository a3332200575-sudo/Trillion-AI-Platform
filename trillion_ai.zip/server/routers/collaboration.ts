import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  acceptWorkspaceInvite,
  ensureWorkspace,
  getWorkspaceAccess,
  getWorkspaceTimezoneSettings,
  inviteWorkspaceMember,
  listEmailIntegrations,
  listWorkflowShares,
  listWorkspaceMembers,
  revokeWorkspaceMember,
  shareWorkflow,
  sendWorkspaceInviteEmail,
  unshareWorkflow,
  updateWorkspaceMemberRole,
  updateMemberTimezoneOverride,
  updateWorkspaceTimezonePolicy,
  listWorkspaceReportingPresets,
  createWorkspaceReportingPreset,
  deleteWorkspaceReportingPreset,
} from "../collaboration";
import {
  addWorkflowComment,
  exportWorkspaceActivity,
  heartbeatPresence,
  listWorkflowComments,
  listWorkspaceActivity,
  listWorkspacePresence,
  listWorkspaceTimezoneHistory,
  setWorkflowCommentResolved,
} from "../collaboration-extra";

const workspaceIdSchema = z.object({ workspaceId: z.number().int().positive() });
const activityDateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD dates");
const activityFilterSchema = workspaceIdSchema.extend({
  workflowId: z.number().int().positive().optional(),
  eventType: z.string().max(80).optional(),
  startDate: activityDateSchema.optional(),
  endDate: activityDateSchema.optional(),
  timezone: z.string().min(1).max(120).optional(),
});

const getAppOrigin = (req: { protocol: string; headers: Record<string, string | string[] | undefined> }) => {
  const forwardedProto = req.headers["x-forwarded-proto"];
  const forwardedHost = req.headers["x-forwarded-host"];
  const protocol = (Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto)?.split(",")[0] || req.protocol || "https";
  const host = (Array.isArray(forwardedHost) ? forwardedHost[0] : forwardedHost) || req.headers.host;
  if (!host) throw new Error("Unable to determine the application origin");
  return `${protocol}://${host}`;
};

export const collaborationRouter = router({
  workspace: protectedProcedure.query(async ({ ctx }) => {
    const workspace = await ensureWorkspace(ctx.user.id, ctx.user.email);
    const access = await getWorkspaceAccess(ctx.user.id, workspace.id);
    return { ...workspace, access: access?.role ?? "owner" };
  }),

  timezoneSettings: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => getWorkspaceTimezoneSettings(ctx.user.id, input.workspaceId)),

  updateTimezonePolicy: protectedProcedure
    .input(workspaceIdSchema.extend({
      policy: z.enum(["member", "workspace"]),
      timezone: z.string().min(1).max(120),
    }))
    .mutation(({ ctx, input }) => updateWorkspaceTimezonePolicy(ctx.user.id, input.workspaceId, input.policy, input.timezone)),

  updateTimezoneOverride: protectedProcedure
    .input(workspaceIdSchema.extend({ timezone: z.string().min(1).max(120).nullable() }))
    .mutation(({ ctx, input }) => updateMemberTimezoneOverride(ctx.user.id, input.workspaceId, input.timezone)),

  timezoneHistory: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => listWorkspaceTimezoneHistory(ctx.user.id, input.workspaceId)),

  reportingPresets: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => listWorkspaceReportingPresets(ctx.user.id, input.workspaceId)),

  createReportingPreset: protectedProcedure
    .input(workspaceIdSchema.extend({
      name: z.string().trim().min(1).max(120),
      startDate: activityDateSchema,
      endDate: activityDateSchema,
      timezone: z.string().min(1).max(120),
    }))
    .mutation(({ ctx, input }) => createWorkspaceReportingPreset(ctx.user.id, input.workspaceId, input.name, input.startDate, input.endDate, input.timezone)),

  deleteReportingPreset: protectedProcedure
    .input(workspaceIdSchema.extend({ presetId: z.number().int().positive() }))
    .mutation(({ ctx, input }) => deleteWorkspaceReportingPreset(ctx.user.id, input.workspaceId, input.presetId)),

  members: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => listWorkspaceMembers(ctx.user.id, input.workspaceId)),

  activity: protectedProcedure
    .input(activityFilterSchema)
    .query(({ ctx, input }) => listWorkspaceActivity(ctx.user.id, input.workspaceId, input)),

  activityExport: protectedProcedure
    .input(activityFilterSchema)
    .query(({ ctx, input }) => exportWorkspaceActivity(ctx.user.id, input.workspaceId, input)),

  presence: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => listWorkspacePresence(ctx.user.id, input.workspaceId)),

  heartbeat: protectedProcedure
    .input(workspaceIdSchema.extend({ currentPage: z.string().max(120).optional(), currentWorkflowId: z.number().int().positive().nullable().optional() }))
    .mutation(({ ctx, input }) => heartbeatPresence(ctx.user.id, input.workspaceId, input.currentPage, input.currentWorkflowId)),

  invite: protectedProcedure
    .input(
      workspaceIdSchema.extend({
        email: z.string().email(),
        role: z.enum(["editor", "viewer"]),
      })
    )
    .mutation(({ ctx, input }) =>
      inviteWorkspaceMember(ctx.user.id, input.workspaceId, input.email, input.role)
    ),

  emailIntegrations: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => listEmailIntegrations(ctx.user.id, input.workspaceId)),

  sendInviteEmail: protectedProcedure
    .input(
      workspaceIdSchema.extend({
        memberId: z.number().int().positive(),
        integrationId: z.number().int().positive(),
      })
    )
    .mutation(({ ctx, input }) =>
      sendWorkspaceInviteEmail(
        ctx.user.id,
        input.workspaceId,
        input.memberId,
        input.integrationId,
        getAppOrigin(ctx.req)
      )
    ),

  acceptInvite: protectedProcedure
    .input(z.object({ inviteToken: z.string().min(32).max(96) }))
    .mutation(({ ctx, input }) =>
      acceptWorkspaceInvite(ctx.user.id, ctx.user.email, input.inviteToken)
    ),

  revokeMember: protectedProcedure
    .input(workspaceIdSchema.extend({ memberId: z.number().int().positive() }))
    .mutation(({ ctx, input }) =>
      revokeWorkspaceMember(ctx.user.id, input.workspaceId, input.memberId)
    ),

  updateMemberRole: protectedProcedure
    .input(workspaceIdSchema.extend({ memberId: z.number().int().positive(), role: z.enum(["editor", "viewer"]) }))
    .mutation(({ ctx, input }) =>
      updateWorkspaceMemberRole(ctx.user.id, input.workspaceId, input.memberId, input.role)
    ),

  shares: protectedProcedure
    .input(workspaceIdSchema)
    .query(({ ctx, input }) => listWorkflowShares(ctx.user.id, input.workspaceId)),

  shareWorkflow: protectedProcedure
    .input(
      workspaceIdSchema.extend({
        workflowId: z.number().int().positive(),
        permission: z.enum(["viewer", "editor"]),
      })
    )
    .mutation(({ ctx, input }) =>
      shareWorkflow(ctx.user.id, input.workspaceId, input.workflowId, input.permission)
    ),

  unshareWorkflow: protectedProcedure
    .input(workspaceIdSchema.extend({ shareId: z.number().int().positive() }))
    .mutation(({ ctx, input }) =>
      unshareWorkflow(ctx.user.id, input.workspaceId, input.shareId)
    ),

  comments: protectedProcedure
    .input(workspaceIdSchema.extend({ workflowId: z.number().int().positive() }))
    .query(({ ctx, input }) => listWorkflowComments(ctx.user.id, input.workspaceId, input.workflowId)),

  addComment: protectedProcedure
    .input(workspaceIdSchema.extend({ workflowId: z.number().int().positive(), body: z.string().trim().min(1).max(2_000) }))
    .mutation(({ ctx, input }) => addWorkflowComment(ctx.user.id, input.workspaceId, input.workflowId, input.body)),

  resolveComment: protectedProcedure
    .input(workspaceIdSchema.extend({ commentId: z.number().int().positive(), resolved: z.boolean() }))
    .mutation(({ ctx, input }) => setWorkflowCommentResolved(ctx.user.id, input.workspaceId, input.commentId, input.resolved)),
});
