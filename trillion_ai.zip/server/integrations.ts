import { and, eq } from "drizzle-orm";
import { createConnection, type ConnectionOptions } from "mysql2/promise";
import { integrations } from "../drizzle/schema";
import { getDb } from "./db";

type Credentials = Record<string, unknown>;

const asCredentials = (value: unknown): Credentials =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Credentials)
    : {};

const requiredString = (value: unknown, field: string) => {
  if (typeof value !== "string" || !value.trim()) throw new Error(`${field} is required`);
  return value.trim();
};

async function getConnectedIntegration(userId: number, agentId: number, integrationId: number) {
  if (!Number.isInteger(integrationId) || integrationId < 1) {
    throw new Error("This action requires a configured integration");
  }
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const [integration] = await db
    .select()
    .from(integrations)
    .where(
      and(
        eq(integrations.id, integrationId),
        eq(integrations.userId, userId),
        eq(integrations.agentId, agentId)
      )
    )
    .limit(1);
  if (!integration) throw new Error("Integration not found for this workflow agent");
  if (integration.status !== "connected") throw new Error("Integration is not connected");
  return { ...integration, credentials: asCredentials(integration.credentials) };
}

export async function executeEmailAction(
  userId: number,
  agentId: number,
  integrationId: number,
  config: Credentials
) {
  const integration = await getConnectedIntegration(userId, agentId, integrationId);
  const credentials = integration.credentials;
  const provider = String(credentials.provider ?? integration.type).toLowerCase();
  const apiKey = requiredString(credentials.apiKey, "Email integration apiKey");
  const from = requiredString(credentials.from, "Email integration from");
  const to = requiredString(config.to, "send_email to");
  const subject = requiredString(config.subject, "send_email subject");
  const text = requiredString(config.body ?? config.text, "send_email body");

  let endpoint: string;
  let payload: Record<string, unknown>;
  if (provider === "sendgrid") {
    endpoint = String(credentials.endpoint ?? "https://api.sendgrid.com/v3/mail/send");
    payload = {
      personalizations: [{ to: [{ email: to }] }],
      from: { email: from },
      subject,
      content: [{ type: "text/plain", value: text }],
    };
  } else if (provider === "resend" || provider === "email") {
    endpoint = String(credentials.endpoint ?? "https://api.resend.com/emails");
    payload = { from, to: [to], subject, text };
  } else {
    throw new Error(`Unsupported email provider: ${provider}`);
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      accept: "application/json",
      authorization: `Bearer ${apiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  const responseText = await response.text();
  if (!response.ok) throw new Error(`Email provider failed with ${response.status}`);
  let parsed: Record<string, unknown> = {};
  try {
    parsed = responseText ? (JSON.parse(responseText) as Record<string, unknown>) : {};
  } catch {
    // Provider accepted the request with a non-JSON response.
  }
  return {
    output: { accepted: true, provider, messageId: parsed.id ?? null },
    revenue: 0,
  };
}

const buildConnectionOptions = (credentials: Credentials): ConnectionOptions => ({
    host: requiredString(credentials.host, "Database integration host"),
    user: requiredString(credentials.user, "Database integration user"),
    password: requiredString(credentials.password, "Database integration password"),
    database: requiredString(credentials.database, "Database integration database"),
    port: credentials.port === undefined ? 3306 : Number(credentials.port),
    multipleStatements: false,
  });

export async function executeDatabaseAction(
  userId: number,
  agentId: number,
  integrationId: number,
  config: Credentials
) {
  const integration = await getConnectedIntegration(userId, agentId, integrationId);
  const query = requiredString(config.query, "database_query query");
  if (query.includes(";")) throw new Error("database_query accepts one parameterized statement at a time");
  const params = Array.isArray(config.params) ? config.params : [];
  const connection = await createConnection(buildConnectionOptions(integration.credentials));
  try {
    const [rows] = await connection.execute(query, params);
    const safeRows = Array.isArray(rows) ? rows.slice(0, 1000) : rows;
    return { output: { rowCount: Array.isArray(rows) ? rows.length : 0, rows: safeRows }, revenue: 0 };
  } finally {
    await connection.end();
  }
}
