import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import { and, desc, eq } from "drizzle-orm";
import { getDb } from "./db";
import { getWorkflowById } from "./workflows";
import { executeWorkflow } from "./execution";
import { webhookDeliveries, webhooks } from "../drizzle/schema";

type RawRequest = Request & { rawBody?: Buffer };

type WebhookConfig = {
  name: string;
  workflowId: number;
};

const generateToken = () => crypto.randomBytes(24).toString("hex");
const generateSecret = () => crypto.randomBytes(32).toString("base64url");

const safeHeaders = (headers: Request["headers"]): Record<string, string> => {
  const allowed = ["content-type", "user-agent", "x-request-id", "x-trillion-signature"];
  return Object.fromEntries(
    allowed
      .map((key) => [key, headers[key]])
      .filter(([, value]) => typeof value === "string") as Array<[string, string]>
  );
};

const safeBody = (body: unknown): Record<string, unknown> => {
  if (body && typeof body === "object" && !Array.isArray(body)) {
    return body as Record<string, unknown>;
  }
  return { value: body };
};

const signatureMatches = (secret: string, rawBody: string, signature?: string) => {
  if (!signature?.startsWith("sha256=")) return false;
  const received = Buffer.from(signature.slice("sha256=".length), "hex");
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest();
  return received.length === expected.length && crypto.timingSafeEqual(received, expected);
};

export async function listWebhooks(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({
      id: webhooks.id,
      userId: webhooks.userId,
      workflowId: webhooks.workflowId,
      name: webhooks.name,
      endpointToken: webhooks.endpointToken,
      status: webhooks.status,
      lastTriggeredAt: webhooks.lastTriggeredAt,
      createdAt: webhooks.createdAt,
      updatedAt: webhooks.updatedAt,
    })
    .from(webhooks)
    .where(eq(webhooks.userId, userId))
    .orderBy(desc(webhooks.createdAt));
}

export async function createWebhook(userId: number, config: WebhookConfig) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const workflow = await getWorkflowById(userId, config.workflowId);
  if (!workflow) throw new Error("Workflow not found");
  if (workflow.trigger !== "webhook") {
    throw new Error("Webhook endpoints require a webhook-triggered workflow");
  }

  const endpointToken = generateToken();
  const signingSecret = generateSecret();
  const result = await db.insert(webhooks).values({
    userId,
    workflowId: config.workflowId,
    name: config.name,
    endpointToken,
    signingSecret,
    status: "active",
  });

  return {
    id: Number((result as any)[0]?.insertId ?? (result as any).insertId),
    name: config.name,
    workflowId: config.workflowId,
    endpointToken,
    signingSecret,
    status: "active" as const,
  };
}

export async function rotateWebhookSecret(userId: number, webhookId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const signingSecret = generateSecret();
  const result = await db
    .update(webhooks)
    .set({ signingSecret })
    .where(and(eq(webhooks.id, webhookId), eq(webhooks.userId, userId)));

  if (!(result as any)[0]?.affectedRows && !(result as any).affectedRows) {
    throw new Error("Webhook not found");
  }

  return { signingSecret };
}

export async function setWebhookStatus(
  userId: number,
  webhookId: number,
  status: "active" | "disabled"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .update(webhooks)
    .set({ status })
    .where(and(eq(webhooks.id, webhookId), eq(webhooks.userId, userId)));

  if (!(result as any)[0]?.affectedRows && !(result as any).affectedRows) {
    throw new Error("Webhook not found");
  }

  return { success: true, status };
}

export async function getWebhookDeliveries(userId: number, webhookId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(webhookDeliveries)
    .where(
      and(
        eq(webhookDeliveries.userId, userId),
        eq(webhookDeliveries.webhookId, webhookId)
      )
    )
    .orderBy(desc(webhookDeliveries.createdAt))
    .limit(50);
}

async function recordDelivery(
  webhook: typeof webhooks.$inferSelect,
  status: "accepted" | "rejected" | "failed",
  request: RawRequest,
  responseStatus: number,
  error: string | null,
  durationMs: number
) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(webhookDeliveries).values({
    webhookId: webhook.id,
    userId: webhook.userId,
    status,
    requestHeaders: safeHeaders(request.headers),
    requestBody: safeBody(request.body),
    responseStatus,
    error,
    durationMs,
  });

  if (status === "accepted") {
    await db
      .update(webhooks)
      .set({ lastTriggeredAt: new Date() })
      .where(eq(webhooks.id, webhook.id));
  }

  return Number((result as any)[0]?.insertId ?? (result as any).insertId);
}

async function updateDelivery(
  deliveryId: number | null,
  userId: number,
  update: {
    status: "accepted" | "failed";
    responseStatus: number;
    executionLogId?: number | null;
    error?: string | null;
    durationMs: number;
  }
) {
  if (!deliveryId) return;
  const db = await getDb();
  if (!db) return;
  await db
    .update(webhookDeliveries)
    .set({
      executionLogId: update.executionLogId ?? null,
      status: update.status,
      responseStatus: update.responseStatus,
      error: update.error ?? null,
      durationMs: update.durationMs,
    })
    .where(
      and(
        eq(webhookDeliveries.id, deliveryId),
        eq(webhookDeliveries.userId, userId)
      )
    );
}

export function registerWebhookRoutes(app: Express) {
  app.post("/api/webhooks/:token", async (request: Request, response: Response) => {
    const startedAt = Date.now();
    const req = request as RawRequest;
    const db = await getDb();
    if (!db) {
      response.status(503).json({ error: "Webhook service unavailable" });
      return;
    }

    const [webhook] = await db
      .select()
      .from(webhooks)
      .where(eq(webhooks.endpointToken, request.params.token))
      .limit(1);

    if (!webhook) {
      response.status(404).json({ error: "Webhook endpoint not found" });
      return;
    }

    if (webhook.status !== "active") {
      await recordDelivery(webhook, "rejected", req, 410, "Webhook is disabled", Date.now() - startedAt);
      response.status(410).json({ error: "Webhook endpoint is disabled" });
      return;
    }

    const rawBody = req.rawBody?.toString("utf8") ?? JSON.stringify(request.body ?? {});
    if (!signatureMatches(webhook.signingSecret, rawBody, request.header("x-trillion-signature"))) {
      await recordDelivery(webhook, "rejected", req, 401, "Invalid webhook signature", Date.now() - startedAt);
      response.status(401).json({ error: "Invalid webhook signature" });
      return;
    }

    let deliveryId: number | null = null;
    try {
      deliveryId = await recordDelivery(webhook, "accepted", req, 202, null, Date.now() - startedAt);
      const execution = await executeWorkflow(
        webhook.userId,
        webhook.workflowId,
        {
          payload: safeBody(request.body),
          headers: safeHeaders(request.headers),
        },
        { source: "webhook", deliveryId }
      );
      await updateDelivery(deliveryId, webhook.userId, {
        status: execution.status === "success" ? "accepted" : "failed",
        responseStatus: 202,
        executionLogId: execution.executionLogId,
        error: execution.error,
        durationMs: Date.now() - startedAt,
      });
      response.status(202).json({
        accepted: true,
        deliveryId,
        executionLogId: execution.executionLogId,
        executionStatus: execution.status,
      });
    } catch (error) {
      const message = (error as Error).message;
      // The accepted row is updated rather than inserting a second row for the same request.
      await updateDelivery(deliveryId, webhook.userId, {
        status: "failed",
        responseStatus: 500,
        error: message,
        durationMs: Date.now() - startedAt,
      });
      response.status(500).json({ error: "Failed to execute webhook workflow" });
    }
  });
}
