import crypto from "node:crypto";
import { describe, expect, it, vi } from "vitest";

const { mockGetDb, mockExecuteWorkflow, mockGetWorkflowById } = vi.hoisted(() => ({
  mockGetDb: vi.fn(),
  mockExecuteWorkflow: vi.fn(),
  mockGetWorkflowById: vi.fn(),
}));

vi.mock("./db", () => ({ getDb: mockGetDb }));
vi.mock("./execution", () => ({ executeWorkflow: mockExecuteWorkflow }));
vi.mock("./workflows", () => ({ getWorkflowById: mockGetWorkflowById }));

import { registerWebhookRoutes } from "./webhooks";

const secret = "test-signing-secret";
const webhook = {
  id: 5,
  userId: 7,
  workflowId: 42,
  name: "Inbound leads",
  endpointToken: "endpoint-token",
  signingSecret: secret,
  status: "active" as const,
};

function makeDb() {
  return {
    select: vi.fn(() => ({
      from: vi.fn(() => ({
        where: vi.fn(() => ({
          limit: vi.fn().mockResolvedValue([webhook]),
        })),
      })),
    })),
    insert: vi.fn(() => ({ values: vi.fn().mockResolvedValue({ insertId: 77 }) })),
    update: vi.fn(() => ({
      set: vi.fn(() => ({ where: vi.fn().mockResolvedValue({ affectedRows: 1 }) })),
    })),
  };
}

function makeResponse() {
  const response = {
    statusCode: 200,
    body: undefined as unknown,
    status(code: number) {
      response.statusCode = code;
      return response;
    },
    json(body: unknown) {
      response.body = body;
      return response;
    },
  };
  return response;
}

describe("webhook execution dispatch", () => {
  it("executes the linked workflow and returns the execution log ID", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValue(db);
    mockExecuteWorkflow.mockResolvedValue({
      executionLogId: 88,
      status: "success",
      error: null,
    });
    const app = { post: vi.fn() };
    registerWebhookRoutes(app as never);
    const handler = app.post.mock.calls[0][1] as (request: any, response: any) => Promise<void>;

    const body = { lead: { email: "lead@example.com" } };
    const rawBody = JSON.stringify(body);
    const signature = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
    const request = {
      params: { token: "endpoint-token" },
      headers: { "content-type": "application/json", "x-trillion-signature": `sha256=${signature}` },
      body,
      rawBody: Buffer.from(rawBody),
      header(name: string) {
        return this.headers[name.toLowerCase()];
      },
    };
    const response = makeResponse();

    await handler(request, response);

    expect(mockExecuteWorkflow).toHaveBeenCalledWith(
      7,
      42,
      expect.objectContaining({ payload: body }),
      expect.objectContaining({ source: "webhook", deliveryId: 77 })
    );
    expect(response.statusCode).toBe(202);
    expect(response.body).toEqual({
      accepted: true,
      deliveryId: 77,
      executionLogId: 88,
      executionStatus: "success",
    });
  });

  it("updates the accepted delivery when execution throws without inserting a duplicate", async () => {
    const db = makeDb();
    mockGetDb.mockResolvedValue(db);
    mockExecuteWorkflow.mockRejectedValueOnce(new Error("Workflow is inactive"));
    const app = { post: vi.fn() };
    registerWebhookRoutes(app as never);
    const handler = app.post.mock.calls[0][1] as (request: any, response: any) => Promise<void>;

    const body = { lead: { email: "inactive@example.com" } };
    const rawBody = JSON.stringify(body);
    const signature = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
    const request = {
      params: { token: "endpoint-token" },
      headers: { "content-type": "application/json", "x-trillion-signature": `sha256=${signature}` },
      body,
      rawBody: Buffer.from(rawBody),
      header(name: string) {
        return this.headers[name.toLowerCase()];
      },
    };
    const response = makeResponse();

    await handler(request, response);

    expect(response.statusCode).toBe(500);
    expect(db.insert).toHaveBeenCalledTimes(1);
    expect(db.update).toHaveBeenCalledTimes(2);
  });
});
