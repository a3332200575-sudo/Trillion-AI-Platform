import { eq, and, desc, max, or } from "drizzle-orm";
import {
  workflows,
  integrations,
  workflowVersions,
  workflowShares,
  workspaceMembers,
} from "../drizzle/schema";
import { getDb } from "./db";

export async function getUserWorkflows(userId: number, agentId?: number) {
  const db = await getDb();
  if (!db) return [];

  if (agentId) {
    return db
      .select()
      .from(workflows)
      .where(and(eq(workflows.userId, userId), eq(workflows.agentId, agentId)));
  }

  return db
    .select()
    .from(workflows)
    .where(eq(workflows.userId, userId));
}

export async function getWorkflowById(userId: number, workflowId: number) {
  const db = await getDb();
  if (!db) return null;

  const [owned] = await db
    .select()
    .from(workflows)
    .where(and(eq(workflows.id, workflowId), eq(workflows.userId, userId)))
    .limit(1);

  if (owned) return owned;

  const [shared] = await db
    .select({ workflow: workflows })
    .from(workflowShares)
    .innerJoin(workflows, eq(workflows.id, workflowShares.workflowId))
    .innerJoin(
      workspaceMembers,
      and(
        eq(workspaceMembers.workspaceId, workflowShares.workspaceId),
        eq(workspaceMembers.userId, userId),
        eq(workspaceMembers.status, "active")
      )
    )
    .where(eq(workflowShares.workflowId, workflowId))
    .limit(1);

  return shared?.workflow ?? null;
}

async function canEditWorkflow(userId: number, workflowId: number) {
  const db = await getDb();
  if (!db) return false;

  const [owned] = await db
    .select({ id: workflows.id })
    .from(workflows)
    .where(and(eq(workflows.id, workflowId), eq(workflows.userId, userId)))
    .limit(1);
  if (owned) return true;

  const [shared] = await db
    .select({ id: workflowShares.id })
    .from(workflowShares)
    .innerJoin(
      workspaceMembers,
      and(
        eq(workspaceMembers.workspaceId, workflowShares.workspaceId),
        eq(workspaceMembers.userId, userId),
        eq(workspaceMembers.status, "active")
      )
    )
    .where(
      and(
        eq(workflowShares.workflowId, workflowId),
        eq(workflowShares.permission, "editor")
      )
    )
    .limit(1);

  return Boolean(shared);
}

export async function getWorkflowVersions(userId: number, workflowId: number) {
  const db = await getDb();
  if (!db) return [];

  const workflow = await getWorkflowById(userId, workflowId);
  if (!workflow) return [];

  return db
    .select()
    .from(workflowVersions)
    .where(eq(workflowVersions.workflowId, workflowId))
    .orderBy(desc(workflowVersions.version));
}

export async function getWorkflowVersionById(userId: number, versionId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(workflowVersions)
    .where(
      and(
        eq(workflowVersions.id, versionId),
        eq(workflowVersions.userId, userId)
      )
    )
    .limit(1);

  return result[0] || null;
}

async function createWorkflowVersion(
  userId: number,
  workflowId: number,
  snapshot: {
    name: string;
    description?: string | null;
    trigger: string;
    triggerConfig?: Record<string, unknown> | null;
    actions?: Array<{
      type: string;
      integrationId: number;
      config: Record<string, unknown>;
    }> | null;
    retryPolicy?: {
      maxAttempts: number;
      backoffMs: number;
      maxBackoffMs: number;
    } | null;
    changeSummary: string;
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [latest] = await db
    .select({ maxVersion: max(workflowVersions.version) })
    .from(workflowVersions)
    .where(eq(workflowVersions.workflowId, workflowId));

  const version = Number(latest?.maxVersion ?? 0) + 1;

  await db.insert(workflowVersions).values({
    workflowId,
    userId,
    version,
    name: snapshot.name,
    description: snapshot.description ?? null,
    trigger: snapshot.trigger as any,
    triggerConfig: snapshot.triggerConfig ?? {},
    actions: snapshot.actions ?? [],
    retryPolicy: snapshot.retryPolicy ?? null,
    changeSummary: snapshot.changeSummary,
  });

  return version;
}

export async function createWorkflow(
  userId: number,
  agentId: number,
  data: {
    name: string;
    description?: string;
    trigger: string;
    triggerConfig?: Record<string, unknown>;
    actions?: Array<{
      type: string;
      integrationId: number;
      config: Record<string, unknown>;
    }>;
    retryPolicy?: {
      maxAttempts: number;
      backoffMs: number;
      maxBackoffMs: number;
    };
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(workflows).values({
    userId,
    agentId,
    name: data.name,
    description: data.description || null,
    trigger: data.trigger as any,
    triggerConfig: data.triggerConfig || {},
    actions: data.actions || [],
    retryPolicy: data.retryPolicy ?? null,
    isActive: true,
  });

  const workflowId = Number((result as any)[0]?.insertId ?? (result as any).insertId);
  if (workflowId) {
    await createWorkflowVersion(userId, workflowId, {
      name: data.name,
      description: data.description,
      trigger: data.trigger,
      triggerConfig: data.triggerConfig,
      actions: data.actions,
      retryPolicy: data.retryPolicy,
      changeSummary: "Initial version",
    });
  }

  return {
    workflowId,
    version: workflowId ? 1 : null,
  };
}

export async function updateWorkflow(
  userId: number,
  workflowId: number,
  data: {
    name?: string;
    description?: string;
    trigger?: string;
    triggerConfig?: Record<string, unknown>;
    actions?: Array<{
      type: string;
      integrationId: number;
      config: Record<string, unknown>;
    }>;
    retryPolicy?: {
      maxAttempts: number;
      backoffMs: number;
      maxBackoffMs: number;
    };
    isActive?: boolean;
    changeSummary?: string;
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (!(await canEditWorkflow(userId, workflowId))) {
    throw new Error("Editor access required");
  }

  const existing = await getWorkflowById(userId, workflowId);
  if (!existing) throw new Error("Workflow not found");

  const updateData: any = {};
  if (data.name !== undefined) updateData.name = data.name;
  if (data.description !== undefined) updateData.description = data.description;
  if (data.trigger !== undefined) updateData.trigger = data.trigger;
  if (data.triggerConfig !== undefined) updateData.triggerConfig = data.triggerConfig;
  if (data.actions !== undefined) updateData.actions = data.actions;
  if (data.retryPolicy !== undefined) updateData.retryPolicy = data.retryPolicy;
  if (data.isActive !== undefined) updateData.isActive = data.isActive;

  const nextSnapshot = {
    name: data.name ?? existing.name,
    description: data.description ?? existing.description,
    trigger: data.trigger ?? existing.trigger,
    triggerConfig: data.triggerConfig ?? existing.triggerConfig,
    actions: data.actions ?? existing.actions,
    retryPolicy: data.retryPolicy ?? existing.retryPolicy,
  };

  const result = await db
    .update(workflows)
    .set(updateData)
    .where(and(eq(workflows.id, workflowId), eq(workflows.userId, userId)));

  await createWorkflowVersion(userId, workflowId, {
    ...nextSnapshot,
    changeSummary: data.changeSummary || "Workflow updated",
  });

  return result;
}

export async function restoreWorkflowVersion(
  userId: number,
  workflowId: number,
  versionId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (!(await canEditWorkflow(userId, workflowId))) {
    throw new Error("Editor access required");
  }

  const [version] = await db
    .select()
    .from(workflowVersions)
    .where(
      and(
        eq(workflowVersions.id, versionId),
        eq(workflowVersions.workflowId, workflowId)
      )
    )
    .limit(1);
  if (!version || version.workflowId !== workflowId) {
    throw new Error("Workflow version not found");
  }

  const result = await db
    .update(workflows)
    .set({
      name: version.name,
      description: version.description,
      trigger: version.trigger,
      triggerConfig: version.triggerConfig ?? {},
      actions: version.actions ?? [],
      retryPolicy: version.retryPolicy ?? null,
    })
    .where(and(eq(workflows.id, workflowId), eq(workflows.userId, userId)));

  await createWorkflowVersion(userId, workflowId, {
    name: version.name,
    description: version.description,
    trigger: version.trigger,
    triggerConfig: version.triggerConfig,
    actions: version.actions,
    retryPolicy: version.retryPolicy,
    changeSummary: `Restored from version ${version.version}`,
  });

  return result;
}

export async function deleteWorkflow(userId: number, workflowId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .delete(workflows)
    .where(and(eq(workflows.id, workflowId), eq(workflows.userId, userId)));
}

export async function getAgentIntegrations(userId: number, agentId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(integrations)
    .where(and(eq(integrations.userId, userId), eq(integrations.agentId, agentId)));
}
