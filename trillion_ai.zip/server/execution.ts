import { and, eq, sql } from "drizzle-orm";
import { executionLogs, workflows } from "../drizzle/schema";
import { getDb } from "./db";
import { getWorkflowById } from "./workflows";
import { executeDatabaseAction, executeEmailAction } from "./integrations";

type WorkflowInput = Record<string, unknown>;
type Action = {
  type: string;
  integrationId: number;
  config: Record<string, unknown>;
};

type ExecutionContext = {
  source: "webhook" | "manual" | "schedule" | "event";
  deliveryId?: number | null;
  replayedFromId?: number | null;
};

type ActionResult = {
  output: Record<string, unknown>;
  revenue: number;
};

export const EXECUTABLE_ACTION_TYPES = [
  "api_call",
  "send_email",
  "database_query",
  "transform_data",
  "conditional",
  "delay",
] as const;

const MAX_ACTIONS = 20;
const MAX_DELAY_MS = 30_000;
const API_TIMEOUT_MS = 15_000;

type RetryPolicy = {
  maxAttempts: number;
  backoffMs: number;
  maxBackoffMs: number;
};

const asRecord = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};

const getPath = (value: unknown, path: string) =>
  path.split(".").reduce<unknown>((current, key) => {
    if (!current || typeof current !== "object") return undefined;
    return (current as Record<string, unknown>)[key];
  }, value);

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const normalizeRetryPolicy = (value: unknown): RetryPolicy => {
  const policy = asRecord(value);
  const maxAttempts = Math.floor(Number(policy.maxAttempts ?? 3));
  const backoffMs = Math.floor(Number(policy.backoffMs ?? 250));
  const maxBackoffMs = Math.floor(Number(policy.maxBackoffMs ?? 5_000));
  return {
    maxAttempts: Number.isFinite(maxAttempts) ? Math.max(1, Math.min(5, maxAttempts)) : 3,
    backoffMs: Number.isFinite(backoffMs) ? Math.max(0, Math.min(10_000, backoffMs)) : 250,
    maxBackoffMs: Number.isFinite(maxBackoffMs) ? Math.max(0, Math.min(60_000, maxBackoffMs)) : 5_000,
  };
};

const isPrivateHostname = (hostname: string) => {
  const normalized = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    normalized === "localhost" ||
    normalized === "0.0.0.0" ||
    normalized === "::1" ||
    normalized.endsWith(".local")
  ) {
    return true;
  }
  if (/^127\./.test(normalized) || /^10\./.test(normalized) || /^192\.168\./.test(normalized)) {
    return true;
  }
  const octets = normalized.split(".").map(Number);
  return octets.length === 4 && octets.every(Number.isInteger) && octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31;
};

async function executeAction(
  action: Action,
  userId: number,
  agentId: number,
  input: WorkflowInput,
  previousOutput: Record<string, unknown>
): Promise<ActionResult> {
  const config = asRecord(action.config);
  const data = { ...input, previous: previousOutput };

  switch (action.type) {
    case "api_call": {
      const url = typeof config.url === "string" ? config.url : "";
      if (!/^https?:\/\//i.test(url)) {
        throw new Error("api_call requires an http(s) URL");
      }
      const parsedUrl = new URL(url);
      if (isPrivateHostname(parsedUrl.hostname)) {
        throw new Error("api_call cannot target localhost or a private network address");
      }
      const method = typeof config.method === "string" ? config.method.toUpperCase() : "GET";
      if (!["GET", "POST", "PUT", "PATCH", "DELETE"].includes(method)) {
        throw new Error(`Unsupported API method: ${method}`);
      }
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
      try {
        const headers = asRecord(config.headers);
        const body = config.body === undefined ? undefined : JSON.stringify(config.body);
        const response = await fetch(url, {
          method,
          headers: { "content-type": "application/json", ...Object.fromEntries(
            Object.entries(headers).filter(([, value]) => typeof value === "string") as Array<[string, string]>
          ) },
          body: method === "GET" || method === "DELETE" ? undefined : body,
          signal: controller.signal,
        });
        const text = await response.text();
        let parsed: unknown = text;
        try {
          parsed = text ? JSON.parse(text) : null;
        } catch {
          // Keep non-JSON response text as-is.
        }
        if (!response.ok) throw new Error(`API call failed with ${response.status}`);
        return { output: { status: response.status, data: parsed }, revenue: 1 };
      } finally {
        clearTimeout(timeout);
      }
    }

    case "transform_data": {
      const operation = typeof config.operation === "string" ? config.operation : "identity";
      if (operation === "pick") {
        const fields = Array.isArray(config.fields) ? config.fields.filter((field): field is string => typeof field === "string") : [];
        return { output: { data: Object.fromEntries(fields.map((field) => [field, getPath(data, field)])) }, revenue: 0 };
      }
      if (operation === "set") {
        const field = typeof config.field === "string" ? config.field : "";
        if (!field) throw new Error("transform_data set requires a field");
        return { output: { data: { ...data, [field]: config.value } }, revenue: 0 };
      }
      return { output: { data }, revenue: 0 };
    }

    case "conditional": {
      const path = typeof config.path === "string" ? config.path : "";
      const value = path ? getPath(data, path) : undefined;
      const matches = config.equals === undefined ? Boolean(value) : value === config.equals;
      return { output: { matched: matches, value }, revenue: 0 };
    }

    case "delay": {
      const duration = Math.max(0, Math.min(Number(config.duration ?? 0), MAX_DELAY_MS));
      if (!Number.isFinite(duration)) throw new Error("delay requires a finite duration");
      await sleep(duration);
      return { output: { delayedMs: duration }, revenue: 0 };
    }

    case "send_email":
      return executeEmailAction(userId, agentId, action.integrationId, config);

    case "database_query":
      return executeDatabaseAction(userId, agentId, action.integrationId, config);

    default:
      throw new Error(`Unsupported workflow action: ${action.type}`);
  }
}

async function executeActionWithRetry(
  action: Action,
  userId: number,
  agentId: number,
  input: WorkflowInput,
  previousOutput: Record<string, unknown>,
  policy: RetryPolicy
) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= policy.maxAttempts; attempt += 1) {
    try {
      const result = await executeAction(action, userId, agentId, input, previousOutput);
      return { result, attempts: attempt };
    } catch (error) {
      lastError = error;
      if (attempt >= policy.maxAttempts) break;
      const delay = Math.min(policy.maxBackoffMs, policy.backoffMs * 2 ** (attempt - 1));
      if (delay > 0) await sleep(delay);
    }
  }
  const failure = lastError instanceof Error ? lastError : new Error("Action failed");
  (failure as Error & { attempts?: number }).attempts = policy.maxAttempts;
  throw failure;
}

export async function executeWorkflow(
  userId: number,
  workflowId: number,
  input: WorkflowInput,
  context: ExecutionContext
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const workflow = await getWorkflowById(userId, workflowId);
  if (!workflow) throw new Error("Workflow not found");
  if (!workflow.isActive) throw new Error("Workflow is inactive");
  if (context.source === "webhook" && workflow.trigger !== "webhook") {
    throw new Error("Webhook execution requires a webhook-triggered workflow");
  }

  const actions = (workflow.actions || []) as Action[];
  if (actions.length > MAX_ACTIONS) throw new Error(`Workflow exceeds the ${MAX_ACTIONS}-action execution limit`);
  const retryPolicy = normalizeRetryPolicy(workflow.retryPolicy);

  const startedAt = Date.now();
  const pendingResult = await db.insert(executionLogs).values({
    userId,
    agentId: workflow.agentId,
    workflowId: workflow.id,
    status: "pending",
    input: { ...input, _execution: context },
    attempts: 1,
    replayedFromId: context.replayedFromId ?? null,
  });
  const executionLogId = Number(
    (pendingResult as any)?.[0]?.insertId ?? (pendingResult as any)?.insertId
  );

  let previousOutput: Record<string, unknown> = {};
  let totalRevenue = 0;
  let totalAttempts = 0;
  try {
    const outputs: Record<string, unknown>[] = [];
    for (const action of actions) {
      const execution = await executeActionWithRetry(
        action,
        userId,
        workflow.agentId,
        input,
        previousOutput,
        retryPolicy
      );
      totalAttempts += execution.attempts;
      const result = execution.result;
      previousOutput = result.output;
      totalRevenue += result.revenue;
      outputs.push(result.output);
    }

    const executionTime = Date.now() - startedAt;
    await db
      .update(executionLogs)
      .set({
        status: "success",
        output: { steps: outputs, final: previousOutput },
        executionTime,
        attempts: totalAttempts,
        revenue: totalRevenue.toFixed(2),
      })
      .where(and(eq(executionLogs.id, executionLogId), eq(executionLogs.userId, userId)));
    await db
      .update(workflows)
      .set({
        executionCount: sql`${workflows.executionCount} + 1`,
        successCount: sql`${workflows.successCount} + 1`,
        lastExecutedAt: new Date(),
      })
      .where(and(eq(workflows.id, workflow.id), eq(workflows.userId, userId)));

    return { executionLogId, status: "success" as const, output: previousOutput, error: null };
  } catch (error) {
    const executionTime = Date.now() - startedAt;
    const message = (error as Error).message;
    totalAttempts = Math.max(
      totalAttempts + 1,
      (error as Error & { attempts?: number }).attempts ?? 1
    );
    await db
      .update(executionLogs)
      .set({ status: "failed", output: previousOutput, error: message, executionTime, attempts: totalAttempts, revenue: totalRevenue.toFixed(2) })
      .where(and(eq(executionLogs.id, executionLogId), eq(executionLogs.userId, userId)));
    await db
      .update(workflows)
      .set({ executionCount: sql`${workflows.executionCount} + 1`, lastExecutedAt: new Date() })
      .where(and(eq(workflows.id, workflow.id), eq(workflows.userId, userId)));

    return { executionLogId, status: "failed" as const, output: previousOutput, error: message };
  }
}
