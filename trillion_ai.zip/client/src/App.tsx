import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import WorkflowBuilder from "./pages/WorkflowBuilder";
import EnhancedWorkflowBuilder from "./pages/EnhancedWorkflowBuilder";
import ExecutionDashboard from "./pages/ExecutionDashboard";
import Pricing from "./pages/Pricing";
import TemplatesMarketplace from "./pages/TemplatesMarketplace";
import Webhooks from "@/pages/Webhooks";
import Collaboration from "@/pages/Collaboration";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path={"/workflow-builder"} component={WorkflowBuilder} />
      <Route path={"/workflow-builder-advanced"} component={EnhancedWorkflowBuilder} />
      <Route path={"/execution-dashboard"} component={ExecutionDashboard} />
      <Route path={"/pricing"} component={Pricing} />
      <Route path={"/templates"} component={TemplatesMarketplace} />
      <Route path={"/webhooks"} component={Webhooks} />
      <Route path={"/collaboration"} component={Collaboration} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
