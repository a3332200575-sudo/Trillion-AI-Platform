import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Zap, TrendingUp, Heart, ShoppingCart, Layers } from "lucide-react";
import { useEffect, useState } from "react";
import { BrandLogo } from "@/components/BrandLogo";
import { CircuitVisualization } from "@/components/CircuitVisualization";
import { GeometricDivider } from "@/components/GeometricDivider";

/**
 * TrillionAI - Autonomous Integration Platform
 * 
 * Design Philosophy: Futuristic Minimalism with Precision Engineering
 * - Deep Indigo (#1a1f3a) primary with Vibrant Cyan (#00d9ff) accents
 * - Poppins for display, Inter for body
 * - Geometric precision elements, circuit motifs, autonomous agent visualization
 * - Premium fintech aesthetic with engineering discipline
 */

interface Solution {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  details: string;
}

const solutions: Solution[] = [
  {
    id: 1,
    title: "Autonomous FinTech Agents",
    description: "AI-powered financial transaction orchestration",
    icon: <TrendingUp className="w-6 h-6" />,
    category: "FINTECH",
    details: "End-to-end transaction management, portfolio optimization, and fraud detection"
  },
  {
    id: 2,
    title: "Supply Chain Optimization",
    description: "Real-time global supply chain management",
    icon: <Layers className="w-6 h-6" />,
    category: "LOGISTICS",
    details: "Demand forecasting, dynamic routing, inventory optimization"
  },
  {
    id: 3,
    title: "Hyper-Personalized Healthcare",
    description: "AI-driven personalized healthcare pathways",
    icon: <Heart className="w-6 h-6" />,
    category: "HEALTHCARE",
    details: "Personalized treatment plans, continuous monitoring, automated care"
  },
  {
    id: 4,
    title: "E-commerce & Arbitrage",
    description: "Automated retail arbitrage and multi-platform management",
    icon: <ShoppingCart className="w-6 h-6" />,
    category: "COMMERCE",
    details: "Product research, dynamic pricing, inventory sync, profit optimization"
  },
  {
    id: 5,
    title: "White-Label AaaS",
    description: "Customizable AI automation platform",
    icon: <Zap className="w-6 h-6" />,
    category: "PLATFORM",
    details: "Pre-built automation modules, easy integration, recurring revenue"
  }
];

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [visibleCards, setVisibleCards] = useState<number[]>([]);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
      
      const cards = document.querySelectorAll('[data-card]');
      cards.forEach((card, index) => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.8) {
          setVisibleCards(prev => 
            prev.includes(index) ? prev : [...prev, index]
          );
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white text-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-xl border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <BrandLogo className="w-8 h-8" />
            <span className="font-display font-bold text-lg text-primary">
              Trillion<span className="text-accent">AI</span>
            </span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#solutions" className="text-sm font-medium hover:text-accent transition-colors">Solutions</a>
            <a href="#dashboard" className="text-sm font-medium hover:text-accent transition-colors">Dashboard</a>
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <a href="/collaboration" className="text-sm font-medium hover:text-accent transition-colors">Collaboration</a>
                <span className="text-sm text-muted-foreground">{user?.name || user?.email}</span>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => logout()}
                  className="text-sm"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button className="bg-accent hover:bg-accent/90 text-primary font-semibold">
                Launch Machine
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Headline & CTA */}
            <div>
              <div className="inline-block mb-6 px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
                <span className="text-sm font-semibold text-accent">Autonomous Integration Platform</span>
              </div>
              
              <h1 className="text-6xl md:text-7xl font-display font-bold text-primary mb-6 leading-tight">
                Build Your <span className="text-accent">Trillion-Dollar</span> Money Machine
              </h1>
              
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed max-w-xl">
                Deploy autonomous AI agents that orchestrate complex integrations, automate workflows, and generate continuous revenue at scale. From FinTech to Healthcare.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-semibold">
                  Deploy Your First Agent
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-primary text-primary hover:bg-primary/5">
                  Explore Solutions
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-8 pt-8 border-t border-border">
                <div>
                  <div className="text-3xl font-bold text-primary">$500B+</div>
                  <p className="text-xs text-muted-foreground mt-2 uppercase tracking-wide">FinTech Savings</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">$53B</div>
                  <p className="text-xs text-muted-foreground mt-2 uppercase tracking-wide">SCM AI Market</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">$500B+</div>
                  <p className="text-xs text-muted-foreground mt-2 uppercase tracking-wide">Healthcare AI</p>
                </div>
              </div>
            </div>

            {/* Right: Circuit Visualization */}
            <div className="relative h-96 hidden lg:block">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-primary/5 rounded-2xl border border-accent/20">
                <CircuitVisualization />
              </div>
              <div className="absolute -top-4 -right-4 w-20 h-20 rounded-full bg-accent/10 blur-3xl" />
              <div className="absolute -bottom-4 -left-4 w-24 h-24 rounded-full bg-primary/10 blur-3xl" />
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="mt-16">
          <GeometricDivider variant="diagonal" />
        </div>
      </section>

      {/* Solutions Section */}
      <section id="solutions" className="py-24 bg-muted">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-display font-bold text-primary mb-4">
              Five Money Machine Solutions
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Each powered by autonomous AI agents and deep integration automation. Choose your path to trillion-dollar scale.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {solutions.map((solution, index) => (
              <Card
                key={solution.id}
                data-card={index}
                className={`p-8 border-2 border-border hover:border-accent hover:shadow-lg hover:shadow-accent/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:-translate-y-2 bg-white ${
                  visibleCards.includes(index) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{
                  transitionDelay: `${index * 100}ms`
                }}
              >
                {/* Category badge */}
                <div className="mb-4">
                  <span className="text-xs font-bold text-accent uppercase tracking-widest">
                    {solution.category}
                  </span>
                </div>

                {/* Icon */}
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center text-white mb-4">
                  {solution.icon}
                </div>
                
                {/* Title */}
                <h3 className="text-xl font-display font-bold text-primary mb-2">
                  {solution.title}
                </h3>
                
                {/* Description */}
                <p className="text-sm text-muted-foreground mb-4">
                  {solution.description}
                </p>
                
                {/* Divider */}
                <div className="w-8 h-1 bg-gradient-to-r from-accent to-accent/0 mb-4" />
                
                {/* Details */}
                <p className="text-sm text-muted-foreground mb-6">
                  {solution.details}
                </p>
                
                {/* CTA */}
                <Button variant="ghost" className="text-accent hover:text-accent hover:bg-accent/10 p-0">
                  Learn More
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Card>
            ))}
          </div>
        </div>

        {/* Divider */}
        <div className="mt-16">
          <GeometricDivider variant="dots" />
        </div>
      </section>

      {/* Dashboard Preview Section */}
      <section id="dashboard" className="py-24 bg-white">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl font-display font-bold text-primary mb-6">
                Real-Time Agent Orchestration
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Monitor, manage, and optimize your autonomous agents in real-time. Watch as AI orchestrates complex integrations, executes transactions, and generates revenue without human intervention.
              </p>
              
              <ul className="space-y-4 mb-8">
                {[
                  "Live agent performance metrics",
                  "Integration status monitoring",
                  "Automated workflow execution",
                  "Real-time revenue tracking",
                  "AI-powered insights & recommendations"
                ].map((item, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-accent flex-shrink-0" />
                    <span className="text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
              
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-primary font-semibold">
                View Dashboard Demo
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
            
            <div className="relative">
              <div className="rounded-2xl overflow-hidden border-2 border-border shadow-2xl">
                <img 
                  src="/manus-storage/dashboard_mockup_ab50a437.png" 
                  alt="Dashboard Mockup" 
                  className="w-full h-auto"
                />
              </div>
              
              <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-accent/10 blur-3xl" />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 rounded-full bg-primary/10 blur-3xl" />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-primary to-primary/80">
        <div className="container text-center">
          <h2 className="text-5xl font-display font-bold text-white mb-6">
            Ready to Build Your Money Machine?
          </h2>
          <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            Deploy your first autonomous integration agent today and start generating trillion-dollar scale revenue.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-primary font-semibold">
              Launch Your Machine
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <BrandLogo className="w-6 h-6" />
                <span className="font-display font-bold">
                  Trillion<span className="text-accent">AI</span>
                </span>
              </div>
              <p className="text-white/70 text-sm">Autonomous integration platform for trillion-dollar scale.</p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Solutions</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li><a href="#" className="hover:text-white transition">FinTech Agents</a></li>
                <li><a href="#" className="hover:text-white transition">Supply Chain</a></li>
                <li><a href="#" className="hover:text-white transition">Healthcare</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li><a href="#" className="hover:text-white transition">Dashboard</a></li>
                <li><a href="#" className="hover:text-white transition">Documentation</a></li>
                <li><a href="#" className="hover:text-white transition">API</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li><a href="#" className="hover:text-white transition">About</a></li>
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-white/70">
            <p>&copy; 2026 TrillionAI. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition">Privacy</a>
              <a href="#" className="hover:text-white transition">Terms</a>
              <a href="#" className="hover:text-white transition">Security</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
