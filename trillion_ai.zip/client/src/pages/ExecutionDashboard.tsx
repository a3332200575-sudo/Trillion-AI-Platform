import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Activity,
  CheckCircle,
  AlertCircle,
  Clock,
  Zap,
  TrendingUp,
  Download,
  RefreshCw,
  Filter,
  Search,
  Eye,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ExecutionLog {
  id: number;
  workflowName: string;
  workflowId?: number | null;
  status: "success" | "failed" | "pending";
  startTime: Date;
  duration?: number | null;
  attempts: number;
  replayedFromId?: number | null;
  errorMessage?: string | null;
  triggeredBy: "schedule" | "webhook" | "manual" | "event";
}

interface DashboardMetrics {
  totalExecutions: number;
  successRate: number;
  averageDuration: number;
  failedExecutions: number;
  activeWorkflows: number;
}

function ExecutionRowSkeleton({ index }: { index: number }) {
  return (
    <div
      className="flex items-center justify-between rounded-lg bg-slate-50 p-4"
      aria-hidden="true"
      style={{ animationDelay: `${index * 70}ms` }}
    >
      <div className="flex min-w-0 flex-1 items-center gap-4">
        <Skeleton className="h-10 w-10 shrink-0 rounded-full" />
        <div className="min-w-0 flex-1 space-y-2">
          <Skeleton className="h-4 w-2/5" />
          <Skeleton className="h-3 w-1/4" />
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="hidden space-y-2 sm:block">
          <Skeleton className="ml-auto h-3 w-20" />
          <Skeleton className="ml-auto h-3 w-12" />
        </div>
        <Skeleton className="h-6 w-16 rounded-full" />
        <Skeleton className="hidden h-6 w-16 rounded-full md:block" />
        <Skeleton className="h-9 w-16 rounded-md" />
      </div>
    </div>
  );
}

export default function ExecutionDashboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterSource, setFilterSource] = useState<string>("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [cursor, setCursor] = useState<string | undefined>();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [replayTarget, setReplayTarget] = useState<ExecutionLog | null>(null);
  const [replayFeedback, setReplayFeedback] = useState<string | null>(null);
  const [selectedExecutionId, setSelectedExecutionId] = useState<number | null>(null);
  const listExecutions = trpc.execution.list.useQuery({
    status: filterStatus as "all" | "success" | "failed" | "pending",
    source: filterSource === "all" ? undefined : filterSource as "webhook" | "manual" | "schedule" | "event",
    search: searchTerm || undefined,
    from: fromDate ? new Date(`${fromDate}T00:00:00.000Z`).toISOString() : undefined,
    to: toDate ? new Date(`${toDate}T23:59:59.999Z`).toISOString() : undefined,
    cursor,
    limit: 25,
  });
  useEffect(() => {
    setCursor(undefined);
  }, [filterStatus, filterSource, searchTerm, fromDate, toDate]);
  const replayExecution = trpc.execution.replay.useMutation({
    onSuccess: (result) => {
      setReplayTarget(null);
      setReplayFeedback(`Replay started as execution #${result.executionLogId}.`);
      listExecutions.refetch();
    },
    onError: (error) => {
      setReplayFeedback(`Replay failed: ${error.message}`);
    },
  });
  const executionDetail = trpc.execution.get.useQuery(
    { id: selectedExecutionId ?? 0 },
    { enabled: selectedExecutionId !== null }
  );
  const demoSeed = trpc.execution.demoSeed.useMutation({
    onSuccess: () => listExecutions.refetch(),
  });
  const demoClear = trpc.execution.demoClear.useMutation({
    onSuccess: () => listExecutions.refetch(),
  });

  const confirmReplay = () => {
    if (!replayTarget) return;
    setReplayFeedback(null);
    replayExecution.mutate({ id: replayTarget.id });
  };

  const downloadExecutionDetail = (format: "json" | "csv") => {
    const detail = executionDetail.data;
    if (!detail) return;
    const payload = {
      id: detail.id,
      status: detail.status,
      attempts: detail.attempts,
      executionTime: detail.executionTime,
      replayedFromId: detail.replayedFromId,
      error: detail.error,
      input: detail.input,
      output: detail.output,
      createdAt: detail.createdAt,
    };
    const csvEscape = (value: unknown) => `"${String(value ?? "").replaceAll('"', '""')}"`;
    const content = format === "json"
      ? JSON.stringify(payload, null, 2)
      : [
          ["field", "value"],
          ["id", payload.id],
          ["status", payload.status],
          ["attempts", payload.attempts],
          ["executionTime", payload.executionTime],
          ["replayedFromId", payload.replayedFromId],
          ["error", payload.error],
          ["input", JSON.stringify(payload.input ?? {})],
          ["output", JSON.stringify(payload.output ?? {})],
          ["createdAt", payload.createdAt],
        ].map((row) => row.map(csvEscape).join(",")).join("\n");
    const blob = new Blob([content], { type: format === "json" ? "application/json" : "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `execution-${detail.id}.${format}`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const executions = useMemo<ExecutionLog[]>(() => (listExecutions.data?.items ?? []).map((row) => ({
    id: row.id,
    workflowName: row.workflowName ?? `Workflow #${row.workflowId ?? "—"}`,
    workflowId: row.workflowId,
    status: row.status,
    startTime: row.createdAt,
    duration: row.executionTime,
    attempts: row.attempts,
    replayedFromId: row.replayedFromId,
    errorMessage: row.error,
    triggeredBy: (() => {
      const raw = row.input && typeof row.input === "object" && !Array.isArray(row.input)
        ? (row.input as Record<string, unknown>)._execution
        : null;
      const source = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>).source : null;
      return source === "webhook" || source === "schedule" || source === "event" ? source : "manual";
    })(),
  })), [listExecutions.data]);

  const metrics = useMemo<DashboardMetrics>(() => {
    const successful = executions.filter((execution) => execution.status === "success").length;
    const failed = executions.filter((execution) => execution.status === "failed").length;
    const durations = executions.map((execution) => execution.duration).filter((duration): duration is number => typeof duration === "number");
    return {
      totalExecutions: executions.length,
      successRate: executions.length ? (successful / executions.length) * 100 : 0,
      averageDuration: durations.length ? Math.round(durations.reduce((sum, duration) => sum + duration, 0) / durations.length / 1000) : 0,
      failedExecutions: failed,
      activeWorkflows: executions.filter((execution) => execution.status === "pending").length,
    };
  }, [executions]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await listExecutions.refetch();
    setIsRefreshing(false);
  };

  const filteredExecutions = executions;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "running":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "failed":
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case "running":
        return <Activity className="w-5 h-5 text-blue-600 animate-pulse" />;
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-600" />;
      default:
        return <Zap className="w-5 h-5 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Execution Dashboard
          </h1>
          <p className="text-slate-600">
            Monitor and track all workflow executions in real-time
          </p>
        </div>

        {/* Metrics Grid */}
        <div className="grid md:grid-cols-5 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
          >
            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">
                    Total Executions
                  </p>
                  <p className="text-3xl font-bold text-slate-900 mt-2">
                    {metrics.totalExecutions}
                  </p>
                </div>
                <Activity className="w-12 h-12 text-blue-500 opacity-20" />
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">
                    Success Rate
                  </p>
                  <p className="text-3xl font-bold text-green-600 mt-2">
                    {metrics.successRate.toFixed(1)}%
                  </p>
                </div>
                <CheckCircle className="w-12 h-12 text-green-500 opacity-20" />
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">
                    Avg Duration
                  </p>
                  <p className="text-3xl font-bold text-slate-900 mt-2">
                    {metrics.averageDuration}s
                  </p>
                </div>
                <Clock className="w-12 h-12 text-orange-500 opacity-20" />
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">
                    Failed
                  </p>
                  <p className="text-3xl font-bold text-red-600 mt-2">
                    {metrics.failedExecutions}
                  </p>
                </div>
                <AlertCircle className="w-12 h-12 text-red-500 opacity-20" />
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-600 text-sm font-medium">
                    Active
                  </p>
                  <p className="text-3xl font-bold text-blue-600 mt-2">
                    {metrics.activeWorkflows}
                  </p>
                </div>
                <Zap className="w-12 h-12 text-blue-500 opacity-20" />
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Filters and Search */}
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Search workflows..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Status</option>
            <option value="running">Running</option>
            <option value="success">Success</option>
            <option value="failed">Failed</option>
            <option value="pending">Pending</option>
          </select>
          <select
            value={filterSource}
            onChange={(e) => setFilterSource(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Triggers</option>
            <option value="webhook">Webhook</option>
            <option value="schedule">Schedule</option>
            <option value="manual">Manual</option>
            <option value="event">Event</option>
          </select>
          <Input
            type="date"
            aria-label="From date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="w-36"
          />
          <Input
            type="date"
            aria-label="To date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="w-36"
          />
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw
              className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`}
            />
          </Button>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => demoSeed.mutate()}
            disabled={demoSeed.isPending || demoClear.isPending}
          >
            {demoSeed.isPending ? "Loading demo..." : "Load demo data"}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => demoClear.mutate()}
            disabled={demoSeed.isPending || demoClear.isPending}
          >
            {demoClear.isPending ? "Clearing..." : "Clear demo"}
          </Button>
        </div>

        {replayFeedback && (
          <div
            role="status"
            className={`mb-4 rounded-lg border px-4 py-3 text-sm ${
              replayFeedback.startsWith("Replay failed")
                ? "border-red-200 bg-red-50 text-red-800"
                : "border-emerald-200 bg-emerald-50 text-emerald-800"
            }`}
          >
            {replayFeedback}
          </div>
        )}

        {/* Execution Logs */}
        <Card className="bg-white border-slate-200">
          <div className="p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-4">
              Recent Executions
            </h2>

            {listExecutions.isLoading ? (
              <div className="space-y-3" role="status" aria-label="Loading execution logs">
                <span className="sr-only">Loading execution logs...</span>
                {Array.from({ length: 5 }, (_, index) => (
                  <ExecutionRowSkeleton key={index} index={index} />
                ))}
              </div>
            ) : listExecutions.isError ? (
              <div className="py-10 text-center text-red-600" role="alert">
                Unable to load execution logs. Refresh and try again.
              </div>
            ) : <div className="space-y-3">
              {listExecutions.isFetching && (
                <div className="space-y-3" role="status" aria-live="polite">
                  <div className="flex items-center gap-3 rounded-lg border border-blue-100 bg-blue-50/70 px-4 py-3">
                    <Skeleton className="h-4 w-4 rounded-full" />
                    <Skeleton className="h-3 w-44" />
                  </div>
                  {Array.from({ length: 2 }, (_, index) => (
                    <ExecutionRowSkeleton key={`refresh-${index}`} index={index + 5} />
                  ))}
                  <span className="sr-only">Refreshing execution logs...</span>
                </div>
              )}
              <AnimatePresence>
                {filteredExecutions.length > 0 ? (
                  filteredExecutions.map((execution, index) => (
                    <motion.div
                      key={execution.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        {getStatusIcon(execution.status)}
                        <div className="flex-1">
                          <p className="font-semibold text-slate-900">
                            {execution.workflowName}
                          </p>
                          <p className="text-sm text-slate-500">
                            {execution.startTime.toLocaleString()}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          title="View execution details"
                          onClick={() => setSelectedExecutionId(execution.id)}
                        >
                          <Eye className="w-4 h-4 text-slate-600" />
                        </Button>

                        <div className="text-right">
                          <p className="text-sm font-medium text-slate-900">
                            {execution.attempts} attempt{execution.attempts === 1 ? "" : "s"}
                          </p>
                          <p className="text-xs text-slate-500">
                            {execution.duration
                              ? `${(execution.duration / 1000).toFixed(1)}s`
                              : "Running..."}
                          </p>
                        </div>

                        <Badge className={getStatusColor(execution.status)}>
                          {execution.status}
                        </Badge>

                        <Badge variant="outline" className="text-xs">
                          {execution.triggeredBy}
                        </Badge>

                        <Button
                          variant="outline"
                          size="sm"
                          disabled={!execution.workflowId || replayExecution.isPending}
                          onClick={() => setReplayTarget(execution)}
                        >
                          {replayExecution.isPending && replayTarget?.id === execution.id ? "Replaying..." : "Replay"}
                        </Button>

                        {execution.errorMessage && (
                          <Button
                            variant="ghost"
                            size="sm"
                            title={execution.errorMessage}
                          >
                            <AlertCircle className="w-4 h-4 text-red-600" />
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    No executions found
                  </div>
                )}
              </AnimatePresence>
            </div>}
            <div className="mt-5 flex items-center justify-between border-t border-slate-200 pt-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCursor(undefined)}
                disabled={!cursor || listExecutions.isFetching}
              >
                Newest page
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCursor(listExecutions.data?.nextCursor ?? undefined)}
                disabled={!listExecutions.data?.nextCursor || listExecutions.isFetching}
              >
                {listExecutions.isFetching ? "Loading..." : "Load older"}
              </Button>
            </div>
          </div>
        </Card>

        <AlertDialog
          open={replayTarget !== null}
          onOpenChange={(open) => {
            if (!open && !replayExecution.isPending) setReplayTarget(null);
          }}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Replay this workflow execution?</AlertDialogTitle>
              <AlertDialogDescription>
                This will run <strong>{replayTarget?.workflowName}</strong> again with its original input.
                It may call external APIs, send email, or write to a connected database and can create real side effects.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={replayExecution.isPending}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                disabled={replayExecution.isPending}
                onClick={(event) => {
                  event.preventDefault();
                  confirmReplay();
                }}
              >
                {replayExecution.isPending ? "Replaying..." : "Replay execution"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <Dialog
          open={selectedExecutionId !== null}
          onOpenChange={(open) => {
            if (!open) setSelectedExecutionId(null);
          }}
        >
          <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Execution details</DialogTitle>
              <DialogDescription>
                Inspect the immutable input, output, retry attempts, errors, and replay lineage for this run.
              </DialogDescription>
            </DialogHeader>
            {executionDetail.isLoading ? (
              <p className="py-8 text-center text-slate-500">Loading execution details...</p>
            ) : executionDetail.isError ? (
              <p className="py-8 text-center text-red-600" role="alert">
                Unable to load execution details. Please close and try again.
              </p>
            ) : executionDetail.data ? (
              <div className="space-y-5">
                <div className="flex justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => downloadExecutionDetail("json")}>
                    <Download className="mr-2 h-4 w-4" /> JSON
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => downloadExecutionDetail("csv")}>
                    <Download className="mr-2 h-4 w-4" /> CSV
                  </Button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Status</p>
                    <p className="font-semibold text-slate-900">{executionDetail.data.status}</p>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Attempts</p>
                    <p className="font-semibold text-slate-900">{executionDetail.data.attempts}</p>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Duration</p>
                    <p className="font-semibold text-slate-900">{executionDetail.data.executionTime ?? 0} ms</p>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Replayed from</p>
                    <p className="font-semibold text-slate-900">{executionDetail.data.replayedFromId ?? "Original run"}</p>
                  </div>
                </div>
                {executionDetail.data.error && (
                  <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800">
                    <strong>Error:</strong> {executionDetail.data.error}
                  </div>
                )}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="mb-2 text-sm font-semibold text-slate-900">Input</p>
                    <pre className="max-h-64 overflow-auto rounded-lg bg-slate-950 p-4 text-xs text-slate-100">
                      {JSON.stringify(executionDetail.data.input ?? {}, null, 2)}
                    </pre>
                  </div>
                  <div>
                    <p className="mb-2 text-sm font-semibold text-slate-900">Output</p>
                    <pre className="max-h-64 overflow-auto rounded-lg bg-slate-950 p-4 text-xs text-slate-100">
                      {JSON.stringify(executionDetail.data.output ?? {}, null, 2)}
                    </pre>
                  </div>
                </div>
              </div>
            ) : null}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
