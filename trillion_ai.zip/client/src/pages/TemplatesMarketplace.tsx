import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Star,
  Download,
  Eye,
  Code,
  Database,
  Mail,
  Zap,
  TrendingUp,
  Filter,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";

interface Template {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: React.ReactNode;
  rating: number;
  reviews: number;
  downloads: number;
  author: string;
  tags: string[];
  featured?: boolean;
  complexity: "easy" | "medium" | "advanced";
}

const templates: Template[] = [
  {
    id: "email-report",
    name: "Daily Email Report",
    description: "Automatically generate and send daily reports via email",
    category: "Email",
    icon: <Mail className="w-6 h-6" />,
    rating: 4.8,
    reviews: 342,
    downloads: 5200,
    author: "TrillionAI Team",
    tags: ["email", "reporting", "schedule"],
    featured: true,
    complexity: "easy",
  },
  {
    id: "webhook-db",
    name: "Webhook to Database",
    description: "Capture webhook events and store them in your database",
    category: "Database",
    icon: <Database className="w-6 h-6" />,
    rating: 4.9,
    reviews: 521,
    downloads: 8100,
    author: "TrillionAI Team",
    tags: ["webhook", "database", "integration"],
    featured: true,
    complexity: "medium",
  },
  {
    id: "slack-notify",
    name: "Slack Notifications",
    description: "Send custom notifications to Slack channels",
    category: "Communication",
    icon: <Zap className="w-6 h-6" />,
    rating: 4.7,
    reviews: 289,
    downloads: 4300,
    author: "Community",
    tags: ["slack", "notifications", "messaging"],
    complexity: "easy",
  },
  {
    id: "data-sync",
    name: "Data Sync Pipeline",
    description: "Synchronize data between multiple systems automatically",
    category: "Integration",
    icon: <TrendingUp className="w-6 h-6" />,
    rating: 4.6,
    reviews: 198,
    downloads: 2800,
    author: "Community",
    tags: ["sync", "integration", "data"],
    complexity: "advanced",
  },
  {
    id: "form-processor",
    name: "Form Response Processor",
    description: "Process form submissions and send confirmations",
    category: "Forms",
    icon: <Code className="w-6 h-6" />,
    rating: 4.5,
    reviews: 156,
    downloads: 2100,
    author: "Community",
    tags: ["forms", "email", "automation"],
    complexity: "medium",
  },
  {
    id: "api-aggregator",
    name: "API Data Aggregator",
    description: "Fetch data from multiple APIs and combine results",
    category: "API",
    icon: <Code className="w-6 h-6" />,
    rating: 4.4,
    reviews: 112,
    downloads: 1600,
    author: "Community",
    tags: ["api", "data", "aggregation"],
    complexity: "advanced",
  },
  {
    id: "backup-scheduler",
    name: "Database Backup Scheduler",
    description: "Automatically backup your database on a schedule",
    category: "Backup",
    icon: <Database className="w-6 h-6" />,
    rating: 4.9,
    reviews: 445,
    downloads: 6700,
    author: "TrillionAI Team",
    tags: ["backup", "database", "schedule"],
    complexity: "medium",
  },
  {
    id: "lead-enrichment",
    name: "Lead Enrichment Pipeline",
    description: "Enrich lead data with external data sources",
    category: "CRM",
    icon: <TrendingUp className="w-6 h-6" />,
    rating: 4.7,
    reviews: 267,
    downloads: 3900,
    author: "Community",
    tags: ["crm", "leads", "enrichment"],
    complexity: "advanced",
  },
];

const categories = [
  "All",
  "Email",
  "Database",
  "Communication",
  "Integration",
  "Forms",
  "API",
  "Backup",
  "CRM",
];

const complexityColors = {
  easy: "bg-green-100 text-green-800",
  medium: "bg-yellow-100 text-yellow-800",
  advanced: "bg-red-100 text-red-800",
};

export default function TemplatesMarketplace() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortBy, setSortBy] = useState<"downloads" | "rating" | "newest">(
    "downloads"
  );

  const filteredTemplates = templates
    .filter((template) => {
      const matchesSearch =
        template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        template.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        template.tags.some((tag) =>
          tag.toLowerCase().includes(searchTerm.toLowerCase())
        );
      const matchesCategory =
        selectedCategory === "All" || template.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "rating":
          return b.rating - a.rating;
        case "newest":
          return 0; // Would sort by date in real app
        case "downloads":
        default:
          return b.downloads - a.downloads;
      }
    });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Templates Marketplace
          </h1>
          <p className="text-slate-600">
            Discover and clone ready-to-use workflow templates from the community
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Search templates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-11"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedCategory === category
                    ? "bg-blue-600 text-white"
                    : "bg-white text-slate-900 border border-slate-200 hover:border-blue-600"
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="flex gap-4">
            <select
              value={sortBy}
              onChange={(e) =>
                setSortBy(e.target.value as "downloads" | "rating" | "newest")
              }
              className="px-4 py-2 border border-slate-300 rounded-lg bg-white text-slate-900"
            >
              <option value="downloads">Most Downloads</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">Newest</option>
            </select>
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {filteredTemplates.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card
                  className={`p-6 h-full flex flex-col hover:shadow-lg transition-shadow ${
                    template.featured
                      ? "border-2 border-blue-500 bg-blue-50"
                      : "bg-white border-slate-200"
                  }`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-100 rounded-lg text-slate-600">
                        {template.icon}
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900">
                          {template.name}
                        </h3>
                        <p className="text-xs text-slate-500">
                          by {template.author}
                        </p>
                      </div>
                    </div>
                    {template.featured && (
                      <Badge className="bg-blue-600 text-white">Featured</Badge>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-slate-600 mb-4 flex-1">
                    {template.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge
                      className={complexityColors[template.complexity]}
                    >
                      {template.complexity}
                    </Badge>
                    {template.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 py-4 border-t border-b border-slate-200 mb-4">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span className="font-bold text-slate-900">
                          {template.rating}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        {template.reviews} reviews
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Download className="w-4 h-4 text-blue-600" />
                        <span className="font-bold text-slate-900">
                          {(template.downloads / 1000).toFixed(1)}k
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">downloads</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Eye className="w-4 h-4 text-slate-600" />
                        <span className="font-bold text-slate-900">
                          {Math.round(template.downloads * 0.3)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">views</p>
                    </div>
                  </div>

                  {/* CTA Buttons */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      size="sm"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Preview
                    </Button>
                    <Button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Clone
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {filteredTemplates.length === 0 && (
          <div className="text-center py-12">
            <p className="text-slate-600 text-lg">
              No templates found. Try adjusting your filters.
            </p>
          </div>
        )}

        {/* Results Count */}
        <div className="mt-8 text-center text-slate-600">
          Showing {filteredTemplates.length} of {templates.length} templates
        </div>
      </div>
    </div>
  );
}
