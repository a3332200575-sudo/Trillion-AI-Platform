import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Check,
  Clipboard,
  Link2,
  Lock,
  RefreshCw,
  ShieldCheck,
  UserPlus,
  Users,
  Workflow,
  X,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";

const roleDescription = {
  owner: "Full control over members and sharing",
  editor: "Can update shared workflow definitions",
  viewer: "Can inspect shared workflow definitions",
} as const;

const statusStyles = {
  active: "bg-emerald-50 text-emerald-700 border-emerald-200",
  pending: "bg-amber-50 text-amber-700 border-amber-200",
  revoked: "bg-slate-100 text-slate-500 border-slate-200",
} as const;

const supportedTimezones = (() => {
  const intlWithTimezones = Intl as typeof Intl & { supportedValuesOf?: (key: string) => string[] };
  const values = intlWithTimezones.supportedValuesOf?.("timeZone") ?? ["America/New_York", "America/Los_Angeles", "Asia/Kolkata", "Asia/Tokyo", "Europe/London", "Europe/Berlin", "Australia/Sydney"];
  return Array.from(new Set(["UTC", ...values])).sort();
})();

const timezoneRegion = (timezone: string) => timezone === "UTC" ? "UTC" : timezone.split("/")[0] || "Other";

export default function Collaboration() {
  const { user } = useAuth();
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<"editor" | "viewer">("editor");
  const [inviteToken, setInviteToken] = useState(
    () => new URLSearchParams(window.location.search).get("invite") ?? ""
  );
  const [pendingMemberId, setPendingMemberId] = useState<number | null>(null);
  const [emailIntegrationId, setEmailIntegrationId] = useState("");
  const [workflowId, setWorkflowId] = useState("");
  const [workflowPermission, setWorkflowPermission] = useState<"viewer" | "editor">("viewer");
  const [commentWorkflowId, setCommentWorkflowId] = useState("");
  const [commentBody, setCommentBody] = useState("");
  const [activityWorkflowId, setActivityWorkflowId] = useState("");
  const [activityEventType, setActivityEventType] = useState("");
  const [activityStartDate, setActivityStartDate] = useState("");
  const [activityEndDate, setActivityEndDate] = useState("");
  const [activityPreset, setActivityPreset] = useState<"today" | "7d" | "30d" | "thisMonth" | "previousMonth" | "">("");
  const [timezonePolicyDraft, setTimezonePolicyDraft] = useState<"member" | "workspace">("member");
  const [workspaceTimezoneDraft, setWorkspaceTimezoneDraft] = useState("UTC");
  const [memberTimezoneDraft, setMemberTimezoneDraft] = useState("");
  const [timezoneSearch, setTimezoneSearch] = useState("");
  const [activityTimezoneOverride, setActivityTimezoneOverride] = useState<string | null>(null);
  const [presetName, setPresetName] = useState("");
  const [livePresence, setLivePresence] = useState<Array<{ userId: number; status: "active" | "away"; currentWorkflowId: number | null; currentPage: string | null; lastSeenAt: Date | string; name: string | null; email: string | null }>>([]);
  const [presenceTransport, setPresenceTransport] = useState<"websocket" | "polling">("polling");
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const workspace = trpc.collaboration.workspace.useQuery();
  const workspaceId = workspace.data?.id;
  const browserTimezone = useMemo(() => Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC", []);
  const timezoneSettings = trpc.collaboration.timezoneSettings.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined }
  );
  const activityTimezone = timezoneSettings.data?.policy === "workspace"
    ? timezoneSettings.data.workspaceTimezone
    : activityTimezoneOverride || timezoneSettings.data?.memberTimezoneOverride || browserTimezone;
  const filteredTimezones = useMemo(() => {
    const needle = timezoneSearch.trim().toLowerCase();
    return supportedTimezones.filter((timezone) => !needle || timezone.toLowerCase().includes(needle));
  }, [timezoneSearch]);
  const groupedTimezones = useMemo(() => filteredTimezones.reduce<Record<string, string[]>>((groups, timezone) => {
    const region = timezoneRegion(timezone);
    (groups[region] ||= []).push(timezone);
    return groups;
  }, {}), [filteredTimezones]);
  const timezoneHistory = trpc.collaboration.timezoneHistory.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined, refetchInterval: 30_000 }
  );
  const reportingPresets = trpc.collaboration.reportingPresets.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined }
  );
  const members = trpc.collaboration.members.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined }
  );
  const emailIntegrations = trpc.collaboration.emailIntegrations.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined && workspace.data?.access === "owner" }
  );
  const shares = trpc.collaboration.shares.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined }
  );
  const parsedActivityWorkflowId = Number(activityWorkflowId);
  const activityInput = useMemo(() => ({
    workspaceId: workspaceId ?? 0,
    ...(parsedActivityWorkflowId > 0 ? { workflowId: parsedActivityWorkflowId } : {}),
    ...(activityEventType ? { eventType: activityEventType } : {}),
    ...(activityStartDate ? { startDate: activityStartDate } : {}),
    ...(activityEndDate ? { endDate: activityEndDate } : {}),
    timezone: activityTimezone,
  }), [activityEndDate, activityEventType, activityStartDate, activityTimezone, parsedActivityWorkflowId, workspaceId]);
  const activity = trpc.collaboration.activity.useQuery(activityInput, { enabled: workspaceId !== undefined, refetchInterval: 30_000 });
  const activityExport = trpc.collaboration.activityExport.useQuery(activityInput, { enabled: false });
  const presence = trpc.collaboration.presence.useQuery(
    { workspaceId: workspaceId ?? 0 },
    { enabled: workspaceId !== undefined, refetchInterval: 30_000 }
  );
  const parsedCommentWorkflowId = Number(commentWorkflowId);
  const comments = trpc.collaboration.comments.useQuery(
    { workspaceId: workspaceId ?? 0, workflowId: parsedCommentWorkflowId || 0 },
    {
      enabled: workspaceId !== undefined && Number.isInteger(parsedCommentWorkflowId) && parsedCommentWorkflowId > 0,
      refetchInterval: 15_000,
    }
  );
  const utils = trpc.useUtils();

  useEffect(() => {
    if (!timezoneSettings.data) return;
    setTimezonePolicyDraft(timezoneSettings.data.policy);
    setWorkspaceTimezoneDraft(timezoneSettings.data.workspaceTimezone);
    setMemberTimezoneDraft(timezoneSettings.data.memberTimezoneOverride || "");
  }, [timezoneSettings.data]);

  const invite = trpc.collaboration.invite.useMutation({
    onSuccess: (result) => {
      setInviteEmail("");
      setInviteToken(result.inviteToken);
      setPendingMemberId(result.memberId);
      setNotice(`Invitation prepared for ${result.email}. Copy the secure invite link to send it.`);
      setError(null);
      if (workspaceId) {
        void utils.collaboration.members.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const sendInviteEmail = trpc.collaboration.sendInviteEmail.useMutation({
    onSuccess: (result) => {
      setNotice(`Invitation email accepted by ${result.provider}.`);
      setError(null);
      if (workspaceId) {
        void utils.collaboration.members.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const updateTimezonePolicy = trpc.collaboration.updateTimezonePolicy.useMutation({
    onSuccess: async () => {
      setNotice("Workspace timezone policy updated.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.timezoneSettings.invalidate({ workspaceId });
        await utils.collaboration.activity.invalidate();
      }
    },
    onError: (mutationError) => { setError(mutationError.message); setNotice(null); },
  });
  const updateTimezoneOverride = trpc.collaboration.updateTimezoneOverride.useMutation({
    onSuccess: async () => {
      setNotice("Your timezone override was updated.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.timezoneSettings.invalidate({ workspaceId });
        await utils.collaboration.activity.invalidate();
      }
    },
    onError: (mutationError) => { setError(mutationError.message); setNotice(null); },
  });
  const createReportingPreset = trpc.collaboration.createReportingPreset.useMutation({
    onSuccess: async (result) => {
      setPresetName("");
      setNotice(`Shared preset “${result.name}” created.`);
      setError(null);
      if (workspaceId) {
        await utils.collaboration.reportingPresets.invalidate({ workspaceId });
        await utils.collaboration.activity.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => { setError(mutationError.message); setNotice(null); },
  });
  const deleteReportingPreset = trpc.collaboration.deleteReportingPreset.useMutation({
    onSuccess: async () => {
      setNotice("Shared reporting preset deleted.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.reportingPresets.invalidate({ workspaceId });
        await utils.collaboration.activity.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => { setError(mutationError.message); setNotice(null); },
  });
  const { mutate: sendPresenceHeartbeat } = trpc.collaboration.heartbeat.useMutation();
  const updateMemberRole = trpc.collaboration.updateMemberRole.useMutation({
    onSuccess: async () => {
      setNotice("Member role updated.");
      setError(null);
      if (workspaceId) await utils.collaboration.members.invalidate({ workspaceId });
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const addComment = trpc.collaboration.addComment.useMutation({
    onSuccess: async (result) => {
      setCommentBody("");
      setNotice(result.mentionsNotified ? `Comment added. ${result.mentionsNotified} teammate notification${result.mentionsNotified === 1 ? "" : "s"} queued.` : "Comment added to the workflow.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.comments.invalidate({ workspaceId, workflowId: parsedCommentWorkflowId });
        await utils.collaboration.activity.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const resolveComment = trpc.collaboration.resolveComment.useMutation({
    onSuccess: async () => {
      setNotice("Comment status updated.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.comments.invalidate({ workspaceId, workflowId: parsedCommentWorkflowId });
        await utils.collaboration.activity.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const acceptInvite = trpc.collaboration.acceptInvite.useMutation({
    onSuccess: async (result) => {
      setNotice(`You joined workspace #${result.workspaceId} as a ${result.role}.`);
      setInviteToken("");
      setError(null);
      await utils.collaboration.workspace.invalidate();
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const revokeMember = trpc.collaboration.revokeMember.useMutation({
    onSuccess: async () => {
      setNotice("Member access revoked.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.members.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const shareWorkflow = trpc.collaboration.shareWorkflow.useMutation({
    onSuccess: async () => {
      setWorkflowId("");
      setNotice("Workflow share updated.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.shares.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });
  const unshareWorkflow = trpc.collaboration.unshareWorkflow.useMutation({
    onSuccess: async () => {
      setNotice("Workflow is no longer shared with this workspace.");
      setError(null);
      if (workspaceId) {
        await utils.collaboration.shares.invalidate({ workspaceId });
      }
    },
    onError: (mutationError) => {
      setError(mutationError.message);
      setNotice(null);
    },
  });

  const inviteLink = useMemo(() => {
    if (!inviteToken) return "";
    return `${window.location.origin}/collaboration?invite=${inviteToken}`;
  }, [inviteToken]);

  const copyInvite = async () => {
    if (!inviteLink) return;
    await navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const getActivityCalendarDate = (date: Date) => {
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: activityTimezone, year: "numeric", month: "2-digit", day: "2-digit" })
      .formatToParts(date);
    const values = Object.fromEntries(parts.filter((part) => part.type !== "literal").map((part) => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  };
  const shiftActivityDate = (value: string, days: number) => {
    const shifted = new Date(`${value}T00:00:00.000Z`);
    shifted.setUTCDate(shifted.getUTCDate() + days);
    return shifted.toISOString().slice(0, 10);
  };
  const applyActivityPreset = (preset: "today" | "7d" | "30d" | "thisMonth" | "previousMonth") => {
    const today = getActivityCalendarDate(new Date());
    if (preset === "thisMonth" || preset === "previousMonth") {
      const [year, month] = today.split("-").map(Number);
      const currentMonthStart = `${today.slice(0, 7)}-01`;
      const previousMonthStartDate = new Date(Date.UTC(year, month - 2, 1));
      const previousMonthStart = previousMonthStartDate.toISOString().slice(0, 10);
      const previousMonthEnd = shiftActivityDate(currentMonthStart, -1);
      setActivityPreset(preset);
      setActivityStartDate(preset === "thisMonth" ? currentMonthStart : previousMonthStart);
      setActivityEndDate(preset === "thisMonth" ? today : previousMonthEnd);
      return;
    }
    const dayCount = preset === "today" ? 1 : preset === "7d" ? 7 : 30;
    setActivityPreset(preset);
    setActivityStartDate(shiftActivityDate(today, -(dayCount - 1)));
    setActivityEndDate(today);
  };
  const applySharedPreset = (preset: { startDate: string; endDate: string; timezone: string }) => {
    setActivityPreset("");
    setActivityStartDate(preset.startDate);
    setActivityEndDate(preset.endDate);
    setActivityTimezoneOverride(preset.timezone);
  };

  const downloadActivity = async (format: "json" | "csv") => {
    const result = await activityExport.refetch();
    const rows = result.data ?? [];
    const content = format === "json"
      ? JSON.stringify(rows, null, 2)
      : ["id,eventType,entityType,entityId,workflowId,actor,createdAt", ...rows.map((row) =>
        [row.id, row.eventType, row.entityType, row.entityId ?? "", row.workflowId ?? "", row.actorName || row.actorEmail || "System", new Date(row.createdAt).toISOString()]
          .map((value) => `"${String(value).replaceAll('"', '""')}"`).join(","))].join("\n");
    const url = URL.createObjectURL(new Blob([content], { type: format === "json" ? "application/json" : "text/csv" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    const dateSuffix = activityStartDate || activityEndDate ? `-${activityStartDate || "start"}-to-${activityEndDate || "now"}` : "";
    anchor.download = `trillionai-activity${parsedActivityWorkflowId > 0 ? `-workflow-${parsedActivityWorkflowId}` : ""}${dateSuffix}.${format}`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const isOwner = workspace.data?.access === "owner";
  const canEdit = isOwner || workspace.data?.access === "editor";

  useEffect(() => {
    if (!workspaceId) return;
    let fallback: number | undefined;
    let fallbackStarted = false;
    const heartbeat = () => sendPresenceHeartbeat({ workspaceId, currentPage: "collaboration" });
    const startFallback = () => {
      if (fallbackStarted) return;
      fallbackStarted = true;
      setPresenceTransport("polling");
      fallback = window.setInterval(heartbeat, 30_000);
    };
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const socket = new WebSocket(`${protocol}//${window.location.host}/ws/presence?workspaceId=${workspaceId}`);
    let socketHeartbeat: number | undefined;
    socket.onopen = () => {
      setPresenceTransport("websocket");
      socket.send(JSON.stringify({ type: "heartbeat", currentPage: "collaboration" }));
      socketHeartbeat = window.setInterval(() => socket.send(JSON.stringify({ type: "heartbeat", currentPage: "collaboration" })), 30_000);
    };
    socket.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data) as { type?: string; presence?: typeof livePresence };
        if (payload.type === "presence:update" && payload.presence) setLivePresence(payload.presence);
      } catch { /* ignore malformed frames */ }
    };
    socket.onerror = startFallback;
    return () => {
      socket.close();
      if (fallback) window.clearInterval(fallback);
      if (socketHeartbeat) window.clearInterval(socketHeartbeat);
    };
  }, [sendPresenceHeartbeat, workspaceId]);

  useEffect(() => {
    if (!workspaceId) return;
    const sendHeartbeat = () => sendPresenceHeartbeat({ workspaceId, currentPage: "collaboration" });
    sendHeartbeat();
    const interval = window.setInterval(sendHeartbeat, 30_000);
    return () => window.clearInterval(interval);
  }, [sendPresenceHeartbeat, workspaceId]);

  if (workspace.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-cyan-50/40 p-8">
        <div className="mx-auto max-w-6xl space-y-8">
          <Skeleton className="h-12 w-80" />
          <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
            <Skeleton className="h-72 rounded-2xl" />
            <Skeleton className="h-72 rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-cyan-50/40 p-6 md:p-8">
      <div className="mx-auto max-w-6xl">
        <header className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-200 bg-cyan-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-cyan-700">
              <Users className="h-3.5 w-3.5" /> Collaboration
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-slate-950">One workspace. Many operators.</h1>
            <p className="mt-2 max-w-2xl text-slate-600">
              Invite trusted teammates, assign least-privilege roles, and share only the workflows they need to operate.
            </p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white/80 px-4 py-3 text-right shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-400">Workspace</p>
            <p className="mt-1 font-semibold text-slate-900">{workspace.data?.name}</p>
            <p className="text-xs text-slate-500">Signed in as {user?.email || user?.name}</p>
          </div>
        </header>

        {(notice || error) && (
          <div
            role={error ? "alert" : "status"}
            className={`mb-6 flex items-start gap-3 rounded-xl border px-4 py-3 text-sm ${
              error ? "border-red-200 bg-red-50 text-red-800" : "border-emerald-200 bg-emerald-50 text-emerald-800"
            }`}
          >
            {error ? <X className="mt-0.5 h-4 w-4" /> : <Check className="mt-0.5 h-4 w-4" />}
            <span>{error || notice}</span>
          </div>
        )}

        <Card className="mb-6 border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-100 px-6 py-5">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-cyan-600">Reporting preferences</p>
            <h2 className="mt-1 text-xl font-semibold text-slate-950">Timezone settings</h2>
            <p className="mt-1 text-sm text-slate-500">Activity presets and exports use the effective timezone shown in the activity log.</p>
          </div>
          <div className="grid gap-5 p-6 lg:grid-cols-2">
            <form
              className="space-y-3 rounded-xl border border-indigo-100 bg-indigo-50/50 p-4"
              onSubmit={(event) => {
                event.preventDefault();
                if (workspaceId && isOwner) updateTimezonePolicy.mutate({ workspaceId, policy: timezonePolicyDraft, timezone: workspaceTimezoneDraft });
              }}
            >
              <div>
                <p className="text-sm font-semibold text-slate-900">Workspace policy</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-500">Owners can make one reporting timezone consistent for the entire team.</p>
              </div>
              <label className="block text-sm font-medium text-slate-700">
                Policy
                <select className="mt-2 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm" value={timezonePolicyDraft} onChange={(event) => setTimezonePolicyDraft(event.target.value as "member" | "workspace")} disabled={!isOwner}>
                  <option value="member">Personal timezone when available</option>
                  <option value="workspace">Enforce workspace timezone</option>
                </select>
              </label>
              <label className="block text-sm font-medium text-slate-700">
                Workspace IANA timezone
                <select className="mt-2 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm" value={workspaceTimezoneDraft} onChange={(event) => setWorkspaceTimezoneDraft(event.target.value)} disabled={!isOwner}>
                  {Object.entries(groupedTimezones).map(([region, timezones]) => <optgroup key={region} label={region}>{timezones.map((timezone) => <option key={timezone} value={timezone}>{timezone}</option>)}</optgroup>)}
                </select>
              </label>
              <Input aria-label="Search IANA timezones" className="bg-white text-xs" placeholder="Search regions or cities…" value={timezoneSearch} onChange={(event) => setTimezoneSearch(event.target.value)} />
              {isOwner && <Button type="submit" disabled={updateTimezonePolicy.isPending || !workspaceTimezoneDraft.trim()} className="bg-indigo-600 text-white hover:bg-indigo-700">{updateTimezonePolicy.isPending ? "Saving..." : "Save workspace policy"}</Button>}
            </form>

            <form
              className="space-y-3 rounded-xl border border-cyan-100 bg-cyan-50/50 p-4"
              onSubmit={(event) => {
                event.preventDefault();
                if (workspaceId) updateTimezoneOverride.mutate({ workspaceId, timezone: memberTimezoneDraft.trim() || null });
              }}
            >
              <div>
                <p className="text-sm font-semibold text-slate-900">Your timezone override</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-500">Leave blank to use this browser’s detected timezone: {browserTimezone}.</p>
              </div>
              <label className="block text-sm font-medium text-slate-700">
                Personal IANA timezone
                <select className="mt-2 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm" value={memberTimezoneDraft || browserTimezone} onChange={(event) => setMemberTimezoneDraft(event.target.value)}>
                  {Object.entries(groupedTimezones).map(([region, timezones]) => <optgroup key={region} label={region}>{timezones.map((timezone) => <option key={timezone} value={timezone}>{timezone}</option>)}</optgroup>)}
                </select>
              </label>
              <Button type="button" variant="ghost" size="sm" className="px-0 text-xs text-slate-500 hover:bg-transparent hover:text-slate-800" onClick={() => setMemberTimezoneDraft("")}>Use browser timezone ({browserTimezone})</Button>
              <Button type="submit" disabled={updateTimezoneOverride.isPending} variant="outline" className="bg-white">{updateTimezoneOverride.isPending ? "Saving..." : "Save my timezone"}</Button>
            </form>
          </div>
        </Card>

        <Card className="mb-6 border-slate-200 bg-white shadow-sm">
          <div className="flex flex-col justify-between gap-2 border-b border-slate-100 px-6 py-5 sm:flex-row sm:items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-violet-600">Policy audit</p>
              <h2 className="mt-1 text-xl font-semibold text-slate-950">Timezone change history</h2>
              <p className="mt-1 text-sm text-slate-500">Immutable owner changes show who changed the reporting policy and when.</p>
            </div>
            <Badge variant="outline">{timezoneHistory.data?.length ?? 0} changes</Badge>
          </div>
          <div className="space-y-2 p-6">
            {timezoneHistory.isLoading ? (
              Array.from({ length: 2 }, (_, index) => <Skeleton key={index} className="h-14 w-full rounded-xl" />)
            ) : timezoneHistory.data?.length ? (
              timezoneHistory.data.map((event) => {
                const metadata = event.metadata as Record<string, unknown> | null;
                return (
                  <div key={event.id} className="flex flex-col gap-2 rounded-xl border border-slate-100 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{metadata?.policy === "workspace" ? "Workspace timezone enforced" : "Member timezone policy restored"}</p>
                      <p className="text-xs text-slate-500">{event.actorName || event.actorEmail || "Workspace owner"} · {String(metadata?.timezone || "UTC")}</p>
                    </div>
                    <time className="text-xs text-slate-400" dateTime={new Date(event.createdAt).toISOString()}>{new Date(event.createdAt).toLocaleString()}</time>
                  </div>
                );
              })
            ) : (
              <div className="rounded-xl border border-dashed border-slate-200 px-4 py-7 text-center text-sm text-slate-500">No timezone policy changes recorded yet.</div>
            )}
          </div>
        </Card>

        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <Card className="overflow-hidden border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 bg-slate-950 px-6 py-5 text-white">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-cyan-300">Access control</p>
                  <h2 className="mt-1 text-xl font-semibold">Workspace members</h2>
                </div>
                <ShieldCheck className="h-8 w-8 text-cyan-300" />
              </div>
            </div>
            <div className="space-y-5 p-6">
              {isOwner && (
                <form
                  className="grid gap-3 rounded-xl border border-cyan-100 bg-cyan-50/60 p-4 md:grid-cols-[1fr_150px_auto] md:items-end"
                  onSubmit={(event) => {
                    event.preventDefault();
                    if (!workspaceId || !inviteEmail) return;
                    setError(null);
                    invite.mutate({ workspaceId, email: inviteEmail, role: inviteRole });
                  }}
                >
                  <label className="text-sm font-medium text-slate-700">
                    Invite by email
                    <Input
                      className="mt-2 bg-white"
                      type="email"
                      placeholder="operator@company.com"
                      value={inviteEmail}
                      onChange={(event) => setInviteEmail(event.target.value)}
                      required
                    />
                  </label>
                  <label className="text-sm font-medium text-slate-700">
                    Role
                    <select
                      className="mt-2 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                      value={inviteRole}
                      onChange={(event) => setInviteRole(event.target.value as "editor" | "viewer")}
                    >
                      <option value="editor">Editor</option>
                      <option value="viewer">Viewer</option>
                    </select>
                  </label>
                  <Button type="submit" disabled={invite.isPending} className="bg-slate-950 text-white hover:bg-slate-800">
                    <UserPlus className="mr-2 h-4 w-4" />
                    {invite.isPending ? "Preparing..." : "Invite"}
                  </Button>
                </form>
              )}

              {inviteLink && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border border-amber-200 bg-amber-50 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-amber-900">Secure invite link ready</p>
                      <p className="mt-1 text-xs text-amber-800">This one-time token is shown only after creation. Send it through a trusted channel.</p>
                    </div>
                    <Lock className="h-5 w-5 text-amber-700" />
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Input readOnly value={inviteLink} className="bg-white text-xs" />
                    <Button type="button" variant="outline" onClick={copyInvite} className="shrink-0 bg-white">
                      {copied ? <Check className="h-4 w-4" /> : <Clipboard className="h-4 w-4" />}
                    </Button>
                  </div>
                  {pendingMemberId && (
                    <div className="mt-3 flex flex-col gap-2 rounded-lg border border-amber-200/80 bg-white/70 p-3 sm:flex-row sm:items-center">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-amber-950">Send by email</p>
                        <p className="text-[11px] text-amber-800">Uses a connected email provider. No message is sent until you press the button.</p>
                      </div>
                      {emailIntegrations.data?.length ? (
                        <>
                          <select
                            aria-label="Email provider"
                            className="h-9 rounded-md border border-amber-200 bg-white px-2 text-xs"
                            value={emailIntegrationId || String(emailIntegrations.data[0].id)}
                            onChange={(event) => setEmailIntegrationId(event.target.value)}
                          >
                            {emailIntegrations.data.map((integration) => (
                              <option key={integration.id} value={integration.id}>{integration.name} · {integration.type}</option>
                            ))}
                          </select>
                          <Button
                            type="button"
                            size="sm"
                            disabled={sendInviteEmail.isPending}
                            onClick={() => workspaceId && sendInviteEmail.mutate({ workspaceId, memberId: pendingMemberId, integrationId: Number(emailIntegrationId || emailIntegrations.data?.[0]?.id) })}
                            className="bg-amber-700 text-white hover:bg-amber-800"
                          >
                            {sendInviteEmail.isPending ? "Sending..." : "Send email"}
                          </Button>
                        </>
                      ) : (
                        <span className="text-xs font-medium text-amber-800">Connect an email integration first.</span>
                      )}
                    </div>
                  )}
                </motion.div>
              )}

              <div className="space-y-2">
                {members.isLoading ? (
                  Array.from({ length: 3 }, (_, index) => <Skeleton key={index} className="h-16 w-full rounded-xl" />)
                ) : members.data?.length ? (
                  members.data.map((member) => (
                    <div key={member.id} className="flex items-center justify-between gap-4 rounded-xl border border-slate-100 px-4 py-3 transition-colors hover:bg-slate-50">
                      <div className="flex min-w-0 items-center gap-3">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-950 text-xs font-bold text-cyan-300">
                          {member.email.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-slate-900">{member.email}</p>
                          <p className="text-xs text-slate-500">
                            {roleDescription[member.role]}
                            {member.inviteSentAt ? ` · sent ${new Date(member.inviteSentAt).toLocaleDateString()}` : ""}
                            {member.status === "pending" && member.inviteExpiresAt ? ` · expires ${new Date(member.inviteExpiresAt).toLocaleDateString()}` : ""}
                          </p>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        <Badge variant="outline" className={statusStyles[member.status]}>{member.status}</Badge>
                        {isOwner && member.role !== "owner" && member.status !== "revoked" ? (
                          <select
                            aria-label={`Role for ${member.email}`}
                            className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs capitalize"
                            value={member.role}
                            disabled={updateMemberRole.isPending}
                            onChange={(event) => workspaceId && updateMemberRole.mutate({ workspaceId, memberId: member.id, role: event.target.value as "editor" | "viewer" })}
                          >
                            <option value="editor">editor</option>
                            <option value="viewer">viewer</option>
                          </select>
                        ) : (
                          <Badge variant="outline" className="capitalize">{member.role}</Badge>
                        )}
                        {isOwner && member.role !== "owner" && member.status !== "revoked" && (
                          <>
                            {member.status === "pending" && (
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                aria-label={`Resend invitation to ${member.email}`}
                                disabled={invite.isPending}
                                onClick={() => workspaceId && invite.mutate({ workspaceId, email: member.email, role: member.role as "editor" | "viewer" })}
                              >
                                <RefreshCw className="h-4 w-4 text-slate-400" />
                              </Button>
                            )}
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              aria-label={`Revoke ${member.email}`}
                              disabled={revokeMember.isPending}
                              onClick={() => workspaceId && revokeMember.mutate({ workspaceId, memberId: member.id })}
                            >
                              <X className="h-4 w-4 text-slate-400" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="rounded-xl border border-dashed border-slate-200 px-4 py-8 text-center text-sm text-slate-500">No workspace members yet.</div>
                )}
              </div>
            </div>
          </Card>

          <Card className="border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-6 py-5">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-cyan-50 p-2 text-cyan-700"><Link2 className="h-5 w-5" /></div>
                <div>
                  <h2 className="text-xl font-semibold text-slate-950">Join a workspace</h2>
                  <p className="text-sm text-slate-500">Accept a secure invitation token.</p>
                </div>
              </div>
            </div>
            <form
              className="space-y-4 p-6"
              onSubmit={(event) => {
                event.preventDefault();
                if (inviteToken) acceptInvite.mutate({ inviteToken });
              }}
            >
              <label className="text-sm font-medium text-slate-700">
                Invitation token
                <Input className="mt-2" placeholder="Paste your invitation token" value={inviteToken} onChange={(event) => setInviteToken(event.target.value)} />
              </label>
              <Button type="submit" disabled={!inviteToken || acceptInvite.isPending} className="w-full bg-cyan-500 text-slate-950 hover:bg-cyan-400">
                {acceptInvite.isPending ? "Joining..." : "Accept invitation"}
              </Button>
              <p className="text-xs leading-relaxed text-slate-500">Your authenticated email must match the email address selected by the workspace owner.</p>
            </form>
          </Card>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <Card className="border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-6 py-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-emerald-600">Live now</p>
                  <h2 className="mt-1 text-xl font-semibold text-slate-950">Collaborator presence</h2>
                </div>
                <Badge variant="outline" className={presenceTransport === "websocket" ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-700"}>{presenceTransport === "websocket" ? "WebSocket live" : "Polling fallback"}</Badge>
              </div>
            </div>
            <div className="space-y-2 p-6">
              {presence.isLoading ? (
                Array.from({ length: 2 }, (_, index) => <Skeleton key={index} className="h-14 w-full rounded-xl" />)
              ) : (livePresence.length || presence.data?.length) ? (
                (livePresence.length ? livePresence : presence.data ?? []).map((person) => (
                  <div key={person.userId} className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 px-3 py-2.5">
                    <div className="flex min-w-0 items-center gap-3">
                      <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-emerald-500" />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-slate-900">{person.name || person.email || `User #${person.userId}`}</p>
                        <p className="truncate text-xs text-slate-500">{person.currentPage || "Workspace"}{person.currentWorkflowId ? ` · Workflow #${person.currentWorkflowId}` : ""}</p>
                      </div>
                    </div>
                    <span className="shrink-0 text-[11px] text-slate-400">{new Date(person.lastSeenAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                  </div>
                ))
              ) : (
                <div className="rounded-xl border border-dashed border-slate-200 px-4 py-8 text-center text-sm text-slate-500">No collaborators active in the last 90 seconds.</div>
              )}
            </div>
          </Card>

          <Card className="border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-6 py-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-indigo-600">Immutable trail</p>
                <div className="mt-1 flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-semibold text-slate-950">Workspace activity</h2><Badge variant="outline">{activity.data?.length ?? 0} events</Badge></div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="flex h-8 items-center rounded-md bg-slate-50 px-2 text-[11px] text-slate-500" title="Date presets and filters use this timezone">TZ: {activityTimezone}</span>
                <Input className="h-8 w-32 bg-white text-xs" placeholder="Workflow ID" value={activityWorkflowId} onChange={(event) => setActivityWorkflowId(event.target.value.replace(/[^0-9]/g, ""))} />
                <select aria-label="Activity event type" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs" value={activityEventType} onChange={(event) => setActivityEventType(event.target.value)}><option value="">All event types</option><option value="workflow_comment.created">Comment added</option><option value="workflow_comment.mention_notified">Mention notified</option><option value="workflow_share.created">Workflow shared</option><option value="member.role_changed">Role changed</option></select>
                <div className="flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-slate-50 p-0.5" aria-label="Activity date presets">
                  <Button type="button" size="sm" variant={activityPreset === "today" ? "default" : "ghost"} className="h-7 px-2 text-[11px]" onClick={() => applyActivityPreset("today")}>Today</Button>
                  <Button type="button" size="sm" variant={activityPreset === "7d" ? "default" : "ghost"} className="h-7 px-2 text-[11px]" onClick={() => applyActivityPreset("7d")}>Last 7 Days</Button>
                  <Button type="button" size="sm" variant={activityPreset === "30d" ? "default" : "ghost"} className="h-7 px-2 text-[11px]" onClick={() => applyActivityPreset("30d")}>Last 30 Days</Button>
                  <Button type="button" size="sm" variant={activityPreset === "thisMonth" ? "default" : "ghost"} className="h-7 px-2 text-[11px]" onClick={() => applyActivityPreset("thisMonth")}>This Month</Button>
                  <Button type="button" size="sm" variant={activityPreset === "previousMonth" ? "default" : "ghost"} className="h-7 px-2 text-[11px]" onClick={() => applyActivityPreset("previousMonth")}>Previous Month</Button>
                </div>
                <label className="flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-2 text-[11px] text-slate-500">From<input aria-label="Activity start date" type="date" className="bg-transparent text-xs text-slate-700 outline-none" value={activityStartDate} onChange={(event) => { setActivityPreset(""); setActivityStartDate(event.target.value); }} /></label>
                <label className="flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-2 text-[11px] text-slate-500">To<input aria-label="Activity end date" type="date" className="bg-transparent text-xs text-slate-700 outline-none" value={activityEndDate} onChange={(event) => { setActivityPreset(""); setActivityEndDate(event.target.value); }} /></label>
                <Button type="button" variant="outline" size="sm" disabled={activityExport.isFetching} onClick={() => void downloadActivity("json")}>JSON</Button><Button type="button" variant="outline" size="sm" disabled={activityExport.isFetching} onClick={() => void downloadActivity("csv")}>CSV</Button>
              </div>
              <div className="mt-3 rounded-xl border border-cyan-100 bg-cyan-50/50 p-3">
                <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.14em] text-cyan-700">Shared team presets</p>
                    <p className="mt-1 text-[11px] text-slate-500">Save this date range for teammates in {activityTimezone}.</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Input className="h-8 w-44 bg-white text-xs" placeholder="Preset name" value={presetName} onChange={(event) => setPresetName(event.target.value)} />
                    <Button type="button" size="sm" className="h-8 bg-cyan-600 px-3 text-xs text-white hover:bg-cyan-700" disabled={!presetName.trim() || !activityStartDate || !activityEndDate || activityStartDate > activityEndDate || createReportingPreset.isPending} onClick={() => workspaceId && createReportingPreset.mutate({ workspaceId, name: presetName, startDate: activityStartDate, endDate: activityEndDate, timezone: activityTimezone })}>{createReportingPreset.isPending ? "Saving..." : "Save shared"}</Button>
                  </div>
                </div>
                {reportingPresets.data?.length ? (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {reportingPresets.data.map((preset) => (
                      <div key={preset.id} className="flex items-center gap-1 rounded-lg border border-cyan-200 bg-white px-2 py-1">
                        <Button type="button" variant="ghost" size="sm" className="h-7 px-1.5 text-xs text-slate-700 hover:bg-cyan-50" onClick={() => applySharedPreset(preset)}>{preset.name} <span className="ml-1 text-[10px] text-slate-400">{preset.startDate} → {preset.endDate}</span></Button>
                        {(isOwner || preset.createdBy === user?.id) && <Button type="button" variant="ghost" size="sm" className="h-7 px-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label={`Delete ${preset.name}`} disabled={deleteReportingPreset.isPending} onClick={() => workspaceId && deleteReportingPreset.mutate({ workspaceId, presetId: preset.id })}>×</Button>}
                      </div>
                    ))}
                  </div>
                ) : <p className="mt-3 text-xs text-slate-500">No shared presets yet. Create one from the current date range.</p>}
              </div>
              {activityStartDate && activityEndDate && activityStartDate > activityEndDate && <p className="mt-2 text-xs text-rose-600">Start date must be on or before the end date.</p>}
            </div>
            <div className="max-h-72 space-y-2 overflow-auto p-6">
              {activity.isLoading ? (
                Array.from({ length: 3 }, (_, index) => <Skeleton key={index} className="h-12 w-full rounded-xl" />)
              ) : activity.data?.length ? (
                activity.data.slice(0, 8).map((event) => (
                  <div key={event.id} className="flex items-start justify-between gap-4 rounded-xl border border-slate-100 px-3 py-2.5">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-800">{event.eventType.replaceAll(".", " · ")}</p>
                      <p className="truncate text-xs text-slate-500">{event.actorName || event.actorEmail || "System"}{event.entityId ? ` · #${event.entityId}` : ""}{event.workflowId ? ` · Workflow #${event.workflowId}` : ""}</p>
                    </div>
                    <span className="shrink-0 text-[11px] text-slate-400">{new Date(event.createdAt).toLocaleDateString()}</span>
                  </div>
                ))
              ) : (
                <div className="rounded-xl border border-dashed border-slate-200 px-4 py-8 text-center text-sm text-slate-500">Workspace events will appear here.</div>
              )}
            </div>
          </Card>
        </div>

        <Card className="mt-6 border-slate-200 bg-white shadow-sm">
          <div className="flex flex-col justify-between gap-4 border-b border-slate-100 px-6 py-5 md:flex-row md:items-center">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-indigo-50 p-2 text-indigo-700"><Workflow className="h-5 w-5" /></div>
              <div>
                <h2 className="text-xl font-semibold text-slate-950">Shared workflows</h2>
                <p className="text-sm text-slate-500">Grant the workspace narrowly scoped access to workflow definitions.</p>
              </div>
            </div>
            <Badge variant="outline" className="w-fit">{shares.data?.length ?? 0} shared</Badge>
          </div>
          <div className="grid gap-5 p-6 lg:grid-cols-[1fr_1.3fr]">
            {canEdit && (
              <form
                className="rounded-xl border border-indigo-100 bg-indigo-50/50 p-4"
                onSubmit={(event) => {
                  event.preventDefault();
                  const parsedWorkflowId = Number(workflowId);
                  if (!workspaceId || !Number.isInteger(parsedWorkflowId) || parsedWorkflowId < 1) return;
                  shareWorkflow.mutate({ workspaceId, workflowId: parsedWorkflowId, permission: workflowPermission });
                }}
              >
                <p className="text-sm font-semibold text-indigo-950">Share a workflow</p>
                <p className="mt-1 text-xs text-indigo-800">Use the workflow ID from its builder or execution detail.</p>
                <Input className="mt-4 bg-white" inputMode="numeric" placeholder="Workflow ID" value={workflowId} onChange={(event) => setWorkflowId(event.target.value.replace(/[^0-9]/g, ""))} />
                <div className="mt-3 flex gap-2">
                  <select className="h-10 flex-1 rounded-md border border-slate-200 bg-white px-3 text-sm" value={workflowPermission} onChange={(event) => setWorkflowPermission(event.target.value as "viewer" | "editor")}>
                    <option value="viewer">Viewer access</option>
                    <option value="editor">Editor access</option>
                  </select>
                  <Button type="submit" disabled={shareWorkflow.isPending} className="bg-indigo-700 text-white hover:bg-indigo-600">{shareWorkflow.isPending ? "Sharing..." : "Share"}</Button>
                </div>
              </form>
            )}
            <div className="space-y-2">
              {shares.isLoading ? (
                Array.from({ length: 2 }, (_, index) => <Skeleton key={index} className="h-16 w-full rounded-xl" />)
              ) : shares.data?.length ? (
                shares.data.map((share) => (
                  <div key={share.id} className="flex items-center justify-between gap-4 rounded-xl border border-slate-100 px-4 py-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <Workflow className="h-5 w-5 shrink-0 text-indigo-600" />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-slate-900">{share.workflowName}</p>
                        <p className="text-xs text-slate-500">Workflow #{share.workflowId}</p>
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <Badge variant="outline" className="capitalize">{share.permission}</Badge>
                      {isOwner && <Button type="button" variant="ghost" size="sm" aria-label={`Remove share for ${share.workflowName}`} onClick={() => workspaceId && unshareWorkflow.mutate({ workspaceId, shareId: share.id })}><X className="h-4 w-4 text-slate-400" /></Button>}
                    </div>
                  </div>
                ))
              ) : (
                <div className="rounded-xl border border-dashed border-slate-200 px-4 py-8 text-center text-sm text-slate-500">No workflows shared with this workspace.</div>
              )}
            </div>
          </div>
        </Card>

        <Card className="mt-6 border-slate-200 bg-white shadow-sm">
          <div className="flex flex-col justify-between gap-3 border-b border-slate-100 px-6 py-5 md:flex-row md:items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.16em] text-cyan-700">Workflow context</p>
              <h2 className="mt-1 text-xl font-semibold text-slate-950">Comments</h2>
              <p className="mt-1 text-sm text-slate-500">Coordinate decisions without leaving the workflow workspace.</p>
            </div>
            <Badge variant="outline">{comments.data?.length ?? 0} comments</Badge>
          </div>
          <div className="grid gap-5 p-6 lg:grid-cols-[0.75fr_1.25fr]">
            <form
              className="space-y-3 rounded-xl border border-cyan-100 bg-cyan-50/50 p-4"
              onSubmit={(event) => {
                event.preventDefault();
                if (!workspaceId || parsedCommentWorkflowId < 1 || !commentBody.trim()) return;
                addComment.mutate({ workspaceId, workflowId: parsedCommentWorkflowId, body: commentBody });
              }}
            >
              <label className="text-sm font-medium text-slate-700">
                Workflow ID
                <Input className="mt-2 bg-white" inputMode="numeric" placeholder="Workflow ID" value={commentWorkflowId} onChange={(event) => setCommentWorkflowId(event.target.value.replace(/[^0-9]/g, ""))} />
              </label>
              <label className="text-sm font-medium text-slate-700">
                Add a comment
                <textarea className="mt-2 min-h-28 w-full resize-y rounded-md border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-offset-white focus-visible:ring-2 focus-visible:ring-cyan-400" maxLength={2000} placeholder="Document a decision, question, or handoff..." value={commentBody} onChange={(event) => setCommentBody(event.target.value)} />
                <span className="mt-1 block text-[11px] font-normal text-slate-500">Mention teammates with their exact email, for example @operator@company.com.</span>
              </label>
              <Button type="submit" disabled={addComment.isPending || parsedCommentWorkflowId < 1 || !commentBody.trim()} className="w-full bg-slate-950 text-white hover:bg-slate-800">{addComment.isPending ? "Adding..." : "Add comment"}</Button>
            </form>
            <div className="space-y-2">
              {!commentWorkflowId ? (
                <div className="rounded-xl border border-dashed border-slate-200 px-4 py-10 text-center text-sm text-slate-500">Enter a shared workflow ID to load its discussion.</div>
              ) : comments.isLoading ? (
                Array.from({ length: 2 }, (_, index) => <Skeleton key={index} className="h-20 w-full rounded-xl" />)
              ) : comments.data?.length ? (
                comments.data.map((comment) => (
                  <div key={comment.id} className={`rounded-xl border px-4 py-3 ${comment.resolved ? "border-emerald-100 bg-emerald-50/50" : "border-slate-100"}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-800">{comment.authorName || comment.authorEmail || `User #${comment.authorUserId}`}</p>
                        <p className={`mt-1 whitespace-pre-wrap text-sm ${comment.resolved ? "text-slate-500 line-through" : "text-slate-700"}`}>{comment.body}</p>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        {comment.resolved && <Badge variant="outline" className="border-emerald-200 bg-emerald-50 text-emerald-700">resolved</Badge>}
                        {canEdit && <Button type="button" variant="ghost" size="sm" onClick={() => workspaceId && resolveComment.mutate({ workspaceId, commentId: comment.id, resolved: !comment.resolved })}>{comment.resolved ? "Reopen" : "Resolve"}</Button>}
                      </div>
                    </div>
                    <p className="mt-2 text-[11px] text-slate-400">{new Date(comment.createdAt).toLocaleString()}</p>
                  </div>
                ))
              ) : (
                <div className="rounded-xl border border-dashed border-slate-200 px-4 py-10 text-center text-sm text-slate-500">No comments yet. Start the workflow discussion.</div>
              )}
            </div>
          </div>
        </Card>

        <div className="mt-6 flex items-center gap-2 text-xs text-slate-500">
          <RefreshCw className="h-3.5 w-3.5" /> Changes are protected by workspace membership and role checks on every request.
        </div>
      </div>
    </div>
  );
}
