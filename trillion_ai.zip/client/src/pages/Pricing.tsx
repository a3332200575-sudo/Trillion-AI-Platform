import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, X, Zap } from "lucide-react";
import { motion } from "framer-motion";

interface PricingTier {
  id: string;
  name: string;
  price: number;
  description: string;
  features: Array<{ name: string; included: boolean }>;
  cta: string;
  highlighted?: boolean;
}

const pricingTiers: PricingTier[] = [
  {
    id: "starter",
    name: "Starter",
    price: 29,
    description: "Perfect for getting started with automation",
    features: [
      { name: "Up to 5 workflows", included: true },
      { name: "100 executions/month", included: true },
      { name: "Basic triggers (manual, schedule)", included: true },
      { name: "Email & API actions", included: true },
      { name: "Community support", included: true },
      { name: "Workflow versioning", included: false },
      { name: "Team collaboration", included: false },
      { name: "Advanced analytics", included: false },
      { name: "Priority support", included: false },
      { name: "Custom integrations", included: false },
    ],
    cta: "Start Free Trial",
  },
  {
    id: "professional",
    name: "Professional",
    price: 99,
    description: "For growing teams and complex workflows",
    features: [
      { name: "Unlimited workflows", included: true },
      { name: "10,000 executions/month", included: true },
      { name: "All trigger types", included: true },
      { name: "All action types", included: true },
      { name: "Workflow versioning", included: true },
      { name: "Team collaboration (up to 5 users)", included: true },
      { name: "Advanced analytics", included: true },
      { name: "Email support", included: true },
      { name: "Custom integrations", included: false },
      { name: "Priority support", included: false },
    ],
    cta: "Start Free Trial",
    highlighted: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 299,
    description: "For large-scale automation and integrations",
    features: [
      { name: "Unlimited workflows", included: true },
      { name: "Unlimited executions", included: true },
      { name: "All trigger types", included: true },
      { name: "All action types", included: true },
      { name: "Workflow versioning", included: true },
      { name: "Unlimited team collaboration", included: true },
      { name: "Advanced analytics & reporting", included: true },
      { name: "Priority support (24/7)", included: true },
      { name: "Custom integrations", included: true },
      { name: "Dedicated account manager", included: true },
    ],
    cta: "Contact Sales",
  },
];

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">(
    "monthly"
  );

  const getPrice = (basePrice: number) => {
    if (billingCycle === "annual") {
      return Math.round(basePrice * 12 * 0.8); // 20% discount for annual
    }
    return basePrice;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="pt-16 pb-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-slate-600 mb-8">
            Choose the perfect plan for your automation needs
          </p>

          {/* Billing Toggle */}
          <div className="flex justify-center items-center gap-4 mb-12">
            <span
              className={`text-sm font-medium ${
                billingCycle === "monthly"
                  ? "text-slate-900"
                  : "text-slate-500"
              }`}
            >
              Monthly
            </span>
            <button
              onClick={() =>
                setBillingCycle(billingCycle === "monthly" ? "annual" : "monthly")
              }
              className="relative inline-flex h-8 w-14 items-center rounded-full bg-slate-300"
            >
              <span
                className={`inline-block h-6 w-6 transform rounded-full bg-white transition ${
                  billingCycle === "annual" ? "translate-x-7" : "translate-x-1"
                }`}
              />
            </button>
            <span
              className={`text-sm font-medium ${
                billingCycle === "annual"
                  ? "text-slate-900"
                  : "text-slate-500"
              }`}
            >
              Annual
              {billingCycle === "annual" && (
                <Badge className="ml-2 bg-green-100 text-green-800">
                  Save 20%
                </Badge>
              )}
            </span>
          </div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <div className="grid md:grid-cols-3 gap-8">
          {pricingTiers.map((tier, index) => (
            <motion.div
              key={tier.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative ${tier.highlighted ? "md:scale-105" : ""}`}
            >
              {tier.highlighted && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-600 text-white">
                    <Zap className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}

              <Card
                className={`p-8 h-full flex flex-col ${
                  tier.highlighted
                    ? "bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-500 shadow-xl"
                    : "bg-white border-slate-200"
                }`}
              >
                {/* Tier Info */}
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">
                    {tier.name}
                  </h3>
                  <p className="text-slate-600 text-sm mb-4">
                    {tier.description}
                  </p>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-slate-900">
                      ${getPrice(tier.price)}
                    </span>
                    <span className="text-slate-600">/month</span>
                  </div>
                  {billingCycle === "annual" && (
                    <p className="text-sm text-slate-500 mt-2">
                      Billed annually
                    </p>
                  )}
                </div>

                {/* CTA Button */}
                <Button
                  className={`w-full mb-8 ${
                    tier.highlighted
                      ? "bg-blue-600 hover:bg-blue-700 text-white"
                      : "bg-slate-100 hover:bg-slate-200 text-slate-900"
                  }`}
                >
                  {tier.cta}
                </Button>

                {/* Features List */}
                <div className="space-y-4 flex-1">
                  {tier.features.map((feature, featureIndex) => (
                    <div
                      key={featureIndex}
                      className="flex items-start gap-3"
                    >
                      {feature.included ? (
                        <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      ) : (
                        <X className="w-5 h-5 text-slate-300 flex-shrink-0 mt-0.5" />
                      )}
                      <span
                        className={`text-sm ${
                          feature.included
                            ? "text-slate-900"
                            : "text-slate-400"
                        }`}
                      >
                        {feature.name}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="bg-white border-t border-slate-200 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-slate-900 mb-12 text-center">
            Frequently Asked Questions
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                q: "Can I change plans anytime?",
                a: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect at the start of your next billing cycle.",
              },
              {
                q: "Do you offer a free trial?",
                a: "Yes! All plans include a 14-day free trial with full access to all features. No credit card required.",
              },
              {
                q: "What happens if I exceed my execution limit?",
                a: "We'll notify you when you're approaching your limit. You can upgrade anytime or purchase additional executions.",
              },
              {
                q: "Is there a contract?",
                a: "No contracts required. You can cancel your subscription at any time with no penalties.",
              },
              {
                q: "Do you offer discounts for annual billing?",
                a: "Yes! Annual plans include a 20% discount compared to monthly billing.",
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept all major credit cards, PayPal, and wire transfers for Enterprise customers.",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <h3 className="font-semibold text-slate-900 mb-2">
                  {item.q}
                </h3>
                <p className="text-slate-600 text-sm">{item.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to automate your workflows?
          </h2>
          <p className="text-blue-100 mb-8">
            Start your free 14-day trial today. No credit card required.
          </p>
          <Button className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-3 text-lg font-semibold">
            Start Free Trial
          </Button>
        </div>
      </div>
    </div>
  );
}
