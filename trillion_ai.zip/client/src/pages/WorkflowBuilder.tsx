import { useState, useCallback } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, Plus, Trash2, Save, Play, History } from "lucide-react";
import WorkflowCanvas from "@/components/workflow/WorkflowCanvas";
import TriggerPanel from "@/components/workflow/TriggerPanel";
import ActionPanel from "@/components/workflow/ActionPanel";

interface WorkflowState {
  name: string;
  description: string;
  agentId: number;
  trigger: {
    type: string;
    config: Record<string, unknown>;
  };
  actions: Array<{
    id: string;
    type: string;
    integrationId: number;
    config: Record<string, unknown>;
  }>;
}

export default function WorkflowBuilder() {
  const { user } = useAuth();
  const [agentId, setAgentId] = useState<number>(1); // Default agent ID
  const [workflowState, setWorkflowState] = useState<WorkflowState>({
    name: "New Workflow",
    description: "",
    agentId,
    trigger: { type: "manual", config: {} },
    actions: [],
  });
  const [workflowId, setWorkflowId] = useState<number | null>(null);

  const [selectedActionId, setSelectedActionId] = useState<string | null>(null);
  const [showTriggerPanel, setShowTriggerPanel] = useState(false);
  const [showActionPanel, setShowActionPanel] = useState(false);

  // Fetch available action and trigger types
  const { data: actionTypes } = trpc.workflow.getActionTypes.useQuery();
  const { data: triggerTypes } = trpc.workflow.getTriggerTypes.useQuery();
  const { data: integrations } = trpc.workflow.getIntegrations.useQuery({ agentId });

  // Create workflow mutation
  const createWorkflow = trpc.workflow.create.useMutation();
  const updateWorkflow = trpc.workflow.update.useMutation();
  const restoreVersion = trpc.workflow.restoreVersion.useMutation();
  const utils = trpc.useUtils();
  const {
    data: versions,
    isLoading: versionsLoading,
    isError: versionsHasError,
  } = trpc.workflow.versions.useQuery(
    { workflowId: workflowId ?? 0 },
    { enabled: workflowId !== null }
  );

  const handleAddAction = useCallback(
    (actionType: string) => {
      const newAction = {
        id: `action-${Date.now()}`,
        type: actionType,
        integrationId: integrations?.[0]?.id || 0,
        config: {},
      };
      setWorkflowState((prev) => ({
        ...prev,
        actions: [...prev.actions, newAction],
      }));
      setSelectedActionId(newAction.id);
      setShowActionPanel(true);
    },
    [integrations]
  );

  const handleRemoveAction = useCallback((actionId: string) => {
    setWorkflowState((prev) => ({
      ...prev,
      actions: prev.actions.filter((a) => a.id !== actionId),
    }));
    setSelectedActionId(null);
  }, []);

  const handleUpdateAction = useCallback(
    (actionId: string, config: Record<string, unknown>) => {
      setWorkflowState((prev) => ({
        ...prev,
        actions: prev.actions.map((a) =>
          a.id === actionId ? { ...a, config } : a
        ),
      }));
    },
    []
  );

  const handleUpdateTrigger = useCallback(
    (triggerType: string, config: Record<string, unknown>) => {
      setWorkflowState((prev) => ({
        ...prev,
        trigger: { type: triggerType, config },
      }));
    },
    []
  );

  const handleSaveWorkflow = async () => {
    try {
      const snapshot = {
        name: workflowState.name,
        description: workflowState.description,
        trigger: workflowState.trigger.type as any,
        triggerConfig: workflowState.trigger.config,
        actions: workflowState.actions.map((a) => ({
          type: a.type,
          integrationId: a.integrationId,
          config: a.config,
        })),
      };

      if (workflowId) {
        await updateWorkflow.mutateAsync({
          id: workflowId,
          data: {
            ...snapshot,
            changeSummary: `Saved ${workflowState.actions.length} action${workflowState.actions.length === 1 ? "" : "s"}`,
          },
        });
      } else {
        const result = await createWorkflow.mutateAsync({
          ...snapshot,
          agentId: workflowState.agentId,
        });
        if (result.workflowId) setWorkflowId(result.workflowId);
      }

      await utils.workflow.versions.invalidate(
        workflowId ? { workflowId } : undefined
      );
      alert(workflowId ? "New workflow version saved!" : "Workflow saved successfully!");
    } catch (error) {
      alert("Failed to save workflow: " + (error as Error).message);
    }
  };

  const handleRestoreVersion = async (version: NonNullable<typeof versions>[number]) => {
    if (!workflowId) return;

    const restoredState: WorkflowState = {
      ...workflowState,
      name: version.name,
      description: version.description || "",
      trigger: {
        type: version.trigger,
        config: (version.triggerConfig || {}) as Record<string, unknown>,
      },
      actions: ((version.actions || []) as WorkflowState["actions"]).map(
        (action, index) => ({ ...action, id: `restored-action-${index + 1}` })
      ),
    };

    try {
      await restoreVersion.mutateAsync({
        workflowId,
        versionId: version.id,
      });
      setWorkflowState(restoredState);
      await utils.workflow.versions.invalidate({ workflowId });
      alert(`Restored version ${version.version}. A new revision was recorded.`);
    } catch (error) {
      alert("Failed to restore version: " + (error as Error).message);
    }
  };

  const selectedAction = workflowState.actions.find(
    (a) => a.id === selectedActionId
  );
  const selectedActionType = actionTypes?.find(
    (t) => t.id === selectedAction?.type
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-border sticky top-0 z-40">
        <div className="container py-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-display font-bold text-primary">
                Workflow Builder
              </h1>
              <p className="text-muted-foreground mt-1">
                Design autonomous workflows with drag-and-drop actions
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline">Cancel</Button>
              <Button
                className="bg-accent hover:bg-accent/90 text-primary font-semibold"
                onClick={handleSaveWorkflow}
                disabled={createWorkflow.isPending || updateWorkflow.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                {createWorkflow.isPending || updateWorkflow.isPending
                  ? "Saving..."
                  : workflowId
                    ? "Save New Version"
                    : "Save Workflow"}
              </Button>
            </div>
          </div>

          {/* Workflow Name & Description */}
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Workflow Name
              </label>
              <Input
                value={workflowState.name}
                onChange={(e) =>
                  setWorkflowState((prev) => ({
                    ...prev,
                    name: e.target.value,
                  }))
                }
                placeholder="e.g., Daily Report Generation"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Description
              </label>
              <Input
                value={workflowState.description}
                onChange={(e) =>
                  setWorkflowState((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                placeholder="Describe what this workflow does"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Canvas - Main Area */}
          <div className="lg:col-span-3">
            <WorkflowCanvas
              trigger={workflowState.trigger}
              actions={workflowState.actions}
              onTriggerClick={() => setShowTriggerPanel(true)}
              onActionClick={(actionId) => {
                setSelectedActionId(actionId);
                setShowActionPanel(true);
              }}
              onActionRemove={handleRemoveAction}
              actionTypes={actionTypes || []}
            />
          </div>

          {/* Sidebar - Panels */}
          <div className="lg:col-span-1 space-y-4">
            {/* Trigger Configuration */}
            {showTriggerPanel ? (
              <TriggerPanel
                trigger={workflowState.trigger}
                triggerTypes={triggerTypes || []}
                onUpdate={handleUpdateTrigger}
                onClose={() => setShowTriggerPanel(false)}
              />
            ) : (
              <Card className="p-4 border-2 border-dashed border-accent/30 hover:border-accent/60 cursor-pointer transition-colors"
                onClick={() => setShowTriggerPanel(true)}
              >
                <div className="text-center">
                  <div className="text-2xl mb-2">⚙️</div>
                  <p className="text-sm font-medium text-foreground">
                    Configure Trigger
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {workflowState.trigger.type}
                  </p>
                </div>
              </Card>
            )}

            {/* Action Library */}
            {!showActionPanel && (
              <Card className="p-4">
                <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add Actions
                </h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {actionTypes?.map((action) => (
                    <button
                      key={action.id}
                      onClick={() => handleAddAction(action.id)}
                      className="w-full text-left p-2 rounded-lg hover:bg-accent/10 border border-border hover:border-accent transition-all text-sm"
                    >
                      <div className="font-medium text-foreground">
                        {action.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {action.description}
                      </div>
                    </button>
                  ))}
                </div>
              </Card>
            )}

            {/* Action Configuration */}
            {showActionPanel && selectedAction && selectedActionType && (
              <ActionPanel
                action={selectedAction}
                actionType={selectedActionType}
                integrations={integrations || []}
                onUpdate={(config: Record<string, unknown>) =>
                  handleUpdateAction(selectedAction.id, config)
                }
                onRemove={() => handleRemoveAction(selectedAction.id)}
                onClose={() => setShowActionPanel(false)}
              />
            )}

            {/* Workflow Stats */}
            <Card className="p-4 bg-gradient-to-br from-accent/5 to-primary/5 border-accent/20">
              <h3 className="font-semibold text-foreground mb-3">Workflow Stats</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Trigger:</span>
                  <span className="font-medium text-foreground">
                    {workflowState.trigger.type}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Actions:</span>
                  <span className="font-medium text-foreground">
                    {workflowState.actions.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="font-medium text-accent">Ready</span>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <History className="w-4 h-4" />
                Version History
              </h3>
              {!workflowId ? (
                <p className="text-sm text-muted-foreground">
                  Save this workflow to start building its revision history.
                </p>
              ) : versionsLoading ? (
                <p className="text-sm text-muted-foreground">Loading version history...</p>
              ) : versionsHasError ? (
                <p className="text-sm text-destructive">
                  Unable to load version history. Refresh and try again.
                </p>
              ) : versions && versions.length > 0 ? (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {versions.map((version, index) => (
                    <div key={version.id} className="rounded-lg border border-border p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            Version {version.version}
                            {index === 0 && (
                              <span className="ml-2 text-xs text-accent">Current</span>
                            )}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {version.changeSummary || "Workflow snapshot"}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRestoreVersion(version)}
                          disabled={restoreVersion.isPending || index === 0}
                        >
                          Restore
                        </Button>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-2">
                        {new Date(version.createdAt).toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No revisions have been recorded yet.
                </p>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
