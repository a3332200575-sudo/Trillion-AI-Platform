import { useState, useCallback } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Plus,
  Save,
  Share2,
  Settings,
  Library,
  Play,
  Code,
  History,
} from "lucide-react";
import { motion } from "framer-motion";
import AdvancedCanvas from "@/components/workflow/AdvancedCanvas";
import TemplateLibrary, { WorkflowTemplate } from "@/components/workflow/TemplateLibrary";
import ExecutionPreview from "@/components/workflow/ExecutionPreview";
import TriggerPanel from "@/components/workflow/TriggerPanel";
import ActionPanel from "@/components/workflow/ActionPanel";
import AIPromptInput from "@/components/workflow/AIPromptInput";

interface CanvasNode {
  id: string;
  type: "trigger" | "action" | "end";
  label: string;
  icon: string;
  x: number;
  y: number;
  width: number;
  height: number;
  config?: Record<string, unknown>;
  actionType?: string;
  integrationId?: number;
}

interface CanvasConnection {
  from: string;
  to: string;
}

const WORKFLOW_TEMPLATES: WorkflowTemplate[] = [
  {
    id: "email-daily-report",
    name: "Daily Email Report",
    description: "Send automated daily reports via email",
    category: "notifications",
    difficulty: "beginner",
    icon: "📧",
    tags: ["email", "schedule", "reporting"],
    uses: 1240,
    rating: 4.8,
    trigger: { type: "schedule", config: { cron: "0 9 * * *" } },
    actions: [
      { type: "transform_data", config: { operation: "identity" } },
      {
        type: "transform_data",
        config: { operation: "pick", fields: ["summary"] },
      },
      {
        type: "api_call",
        config: {
          method: "POST",
          url: "https://api.example.com/notifications",
          body: { type: "daily_report" },
        },
      },
    ],
  },
  {
    id: "webhook-to-db",
    name: "Webhook to Database",
    description: "Save webhook data directly to database",
    category: "integrations",
    difficulty: "intermediate",
    icon: "🔗",
    tags: ["webhook", "database", "integration"],
    uses: 856,
    rating: 4.6,
    trigger: { type: "webhook", config: { path: "/webhook/data" } },
    actions: [
      {
        type: "transform_data",
        config: { operation: "set", field: "eventType", value: "webhook.received" },
      },
      {
        type: "api_call",
        config: { method: "POST", url: "https://api.example.com/notify" },
      },
    ],
  },
  {
    id: "multi-step-workflow",
    name: "Multi-Step Workflow",
    description: "Complex workflow with conditional logic",
    category: "advanced",
    difficulty: "advanced",
    icon: "🔄",
    tags: ["conditional", "multi-step", "complex"],
    uses: 432,
    rating: 4.9,
    trigger: { type: "event", config: { event: "user.signup" } },
    actions: [
      { type: "api_call", config: { method: "GET", url: "https://api.example.com/user" } },
      { type: "conditional", config: { condition: "data.premium" } },
      { type: "api_call", config: { method: "POST", url: "https://api.example.com/notifications", body: { type: "premium_user" } } },
    ],
  },
  {
    id: "data-sync",
    name: "Data Sync Pipeline",
    description: "Synchronize data between systems",
    category: "integrations",
    difficulty: "intermediate",
    icon: "🔄",
    tags: ["sync", "database", "api"],
    uses: 678,
    rating: 4.7,
    trigger: { type: "schedule", config: { cron: "0 */6 * * *" } },
    actions: [
      { type: "api_call", config: { method: "GET", url: "https://api.source.com/data" } },
      { type: "transform_data", config: { operation: "identity" } },
      { type: "api_call", config: { method: "POST", url: "https://api.example.com/data-sync" } },
    ],
  },
];

export default function EnhancedWorkflowBuilder() {
  const { user } = useAuth();
  const [workflowName, setWorkflowName] = useState("New Workflow");
  const [workflowDescription, setWorkflowDescription] = useState("");
  const [retryPolicy, setRetryPolicy] = useState({
    maxAttempts: 3,
    backoffMs: 250,
    maxBackoffMs: 5000,
  });
  const [workflowId, setWorkflowId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState("canvas");

  // Canvas state
  const [nodes, setNodes] = useState<CanvasNode[]>([
    {
      id: "trigger-1",
      type: "trigger",
      label: "Manual",
      icon: "▶️",
      x: 100,
      y: 50,
      width: 140,
      height: 80,
      config: {},
    },
  ]);

  const [connections, setConnections] = useState<CanvasConnection[]>([]);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [showTriggerPanel, setShowTriggerPanel] = useState(false);
  const [showActionPanel, setShowActionPanel] = useState(false);

  // Execution state
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionSteps, setExecutionSteps] = useState<any[]>([]);
  const [totalDuration, setTotalDuration] = useState(0);

  // Template state
  const [showTemplates, setShowTemplates] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);

  const createWorkflow = trpc.workflow.create.useMutation();
  const updateWorkflow = trpc.workflow.update.useMutation();
  const restoreVersion = trpc.workflow.restoreVersion.useMutation();
  const utils = trpc.useUtils();
  const {
    data: versions,
    isLoading: versionsLoading,
    isError: versionsHasError,
  } = trpc.workflow.versions.useQuery(
    { workflowId: workflowId ?? 0 },
    { enabled: workflowId !== null }
  );

  const buildWorkflowSnapshot = useCallback(() => {
    const triggerNode = nodes.find((node) => node.type === "trigger");
    return {
      name: workflowName,
      description: workflowDescription,
      trigger: ((triggerNode?.config?.type as string) || "manual") as
        | "schedule"
        | "webhook"
        | "event"
        | "manual",
      triggerConfig: triggerNode?.config || {},
      actions: nodes
        .filter((node) => node.type === "action")
        .map((node) => ({
          type: node.actionType || "api_call",
          integrationId: node.integrationId || 0,
          config: node.config || {},
        })),
      retryPolicy,
    };
  }, [nodes, workflowName, workflowDescription, retryPolicy]);

  const handleSaveWorkflow = useCallback(async () => {
    setSaveError(null);
    setSaveNotice(null);
    try {
      const snapshot = buildWorkflowSnapshot();
      if (workflowId) {
        await updateWorkflow.mutateAsync({
          id: workflowId,
          data: {
            ...snapshot,
            changeSummary: `Saved ${snapshot.actions.length} action${snapshot.actions.length === 1 ? "" : "s"} from advanced builder`,
          },
        });
        await utils.workflow.versions.invalidate({ workflowId });
        setSaveNotice("New workflow version saved.");
      } else {
        const result = await createWorkflow.mutateAsync({
          ...snapshot,
          agentId: 1,
        });
        if (result.workflowId) {
          setWorkflowId(result.workflowId);
          setSaveNotice("Workflow saved with version 1.");
        }
      }
    } catch (error) {
      setSaveError(`Unable to save workflow: ${(error as Error).message}`);
      console.error("Failed to save workflow revision:", error);
    }
  }, [
    buildWorkflowSnapshot,
    createWorkflow,
    updateWorkflow,
    utils.workflow.versions,
    workflowId,
  ]);

  const handleRestoreVersion = useCallback(
    async (version: NonNullable<typeof versions>[number]) => {
      if (!workflowId) return;

      const restoredActions = ((version.actions || []) as Array<{
        type: string;
        integrationId: number;
        config: Record<string, unknown>;
      }>).map((action, index) => ({
        id: `restored-action-${index + 1}`,
        type: "action" as const,
        label: action.type,
        icon: "⚡",
        x: 100,
        y: 200 + index * 100,
        width: 140,
        height: 80,
        actionType: action.type,
        integrationId: action.integrationId,
        config: action.config,
      }));

      const restoredSequence = [
        "trigger-1",
        ...restoredActions.map((action) => action.id),
      ];

      try {
        await restoreVersion.mutateAsync({ workflowId, versionId: version.id });
        setWorkflowName(version.name);
        setWorkflowDescription(version.description || "");
        setNodes([
          {
            id: "trigger-1",
            type: "trigger",
            label: version.trigger,
            icon: "▶️",
            x: 100,
            y: 50,
            width: 140,
            height: 80,
            config: { type: version.trigger, ...(version.triggerConfig || {}) },
          },
          ...restoredActions,
        ]);
        setConnections(
          restoredSequence.slice(0, -1).map((from, index) => ({
            from,
            to: restoredSequence[index + 1],
          }))
        );
        await utils.workflow.versions.invalidate({ workflowId });
        setSaveError(null);
        setSaveNotice(`Restored version ${version.version} as a new revision.`);
      } catch (error) {
        setSaveError(`Unable to restore version: ${(error as Error).message}`);
        console.error("Failed to restore workflow revision:", error);
      }
    },
    [restoreVersion, utils.workflow.versions, versions, workflowId]
  );

  const handleNodeDrag = useCallback((nodeId: string, x: number, y: number) => {
    setNodes((prev) =>
      prev.map((n) => (n.id === nodeId ? { ...n, x, y } : n))
    );
  }, []);

  const handleNodeRemove = useCallback((nodeId: string) => {
    setNodes((prev) => prev.filter((n) => n.id !== nodeId));
    setConnections((prev) =>
      prev.filter((c) => c.from !== nodeId && c.to !== nodeId)
    );
  }, []);

  const handleNodeDuplicate = useCallback((nodeId: string) => {
    const node = nodes.find((n) => n.id === nodeId);
    if (!node) return;

    const newNode = {
      ...node,
      id: `${node.type}-${Date.now()}`,
      x: node.x + 160,
      y: node.y,
    };
    setNodes((prev) => [...prev, newNode]);
  }, [nodes]);

  const handleConnectionCreate = useCallback(
    (from: string, to: string) => {
      if (!connections.find((c) => c.from === from && c.to === to)) {
        setConnections((prev) => [...prev, { from, to }]);
      }
    },
    [connections]
  );

  const handleAddAction = useCallback(() => {
    const newNode: CanvasNode = {
      id: `action-${Date.now()}`,
      type: "action",
      label: "New Action",
      icon: "⚡",
      x: 100,
      y: 200 + nodes.length * 100,
      width: 140,
      height: 80,
      actionType: "api_call",
      integrationId: 1,
    };
    setNodes((prev) => [...prev, newNode]);
    setSelectedNode(newNode.id);
  }, [nodes]);

  const handleUseTemplate = useCallback((template: WorkflowTemplate) => {
    setWorkflowName(template.name);
    setWorkflowDescription(template.description);

    const newNodes: CanvasNode[] = [
      {
        id: "trigger-1",
        type: "trigger",
        label: template.trigger.type,
        icon: "▶️",
        x: 100,
        y: 50,
        width: 140,
        height: 80,
        config: template.trigger.config,
      },
    ];

    let yOffset = 200;
    const newConnections: CanvasConnection[] = [
      { from: "trigger-1", to: `action-1` },
    ];

    template.actions.forEach((action, index) => {
      const nodeId = `action-${index + 1}`;
      newNodes.push({
        id: nodeId,
        type: "action",
        label: action.type,
        icon: "⚡",
        x: 100,
        y: yOffset,
        width: 140,
        height: 80,
        actionType: action.type,
        config: action.config,
      });

      if (index > 0) {
        newConnections.push({
          from: `action-${index}`,
          to: nodeId,
        });
      }

      yOffset += 100;
    });

    setNodes(newNodes);
    setConnections(newConnections);
    setShowTemplates(false);
  }, []);

  const handleRunPreview = useCallback(() => {
    setIsExecuting(true);
    setExecutionSteps([]);
    setTotalDuration(0);

    let duration = 0;
    const steps = nodes.map((node, index) => {
      const stepDuration = Math.random() * 500 + 100;
      duration += stepDuration;

      return {
        id: node.id,
        name: node.label,
        status: Math.random() > 0.1 ? "success" : "failed",
        duration: Math.round(stepDuration),
        output: { result: `Step ${index + 1} executed` },
      };
    });

    setTimeout(() => {
      setExecutionSteps(steps);
      setTotalDuration(Math.round(duration));
      setIsExecuting(false);
    }, duration);
  }, [nodes]);

  const selectedNodeData = nodes.find((n) => n.id === selectedNode);

  return (
    <div className="min-h-screen bg-slate-900">
      <AIPromptInput
        onGenerate={(prompt, workflow) => {
          const actionIcons: Record<string, string> = {
            api_call: "🌐",
            database_query: "🗄️",
            send_email: "📧",
            transform_data: "🔄",
            conditional: "❓",
            delay: "⏳",
          };
          const generatedActions = (workflow.actions || workflow.nodes?.filter((node: any) => node.type === "action") || [])
            .map((action: any, index: number) => ({
              id: `action-${index + 1}`,
              type: "action" as const,
              label: action.label || action.type,
              icon: action.icon || actionIcons[action.type] || "⚡",
              x: 100,
              y: 180 + index * 110,
              width: 140,
              height: 80,
              actionType: action.actionType || action.type,
              integrationId: action.integrationId || 0,
              config: action.config || {},
            }));
          const trigger = workflow.trigger || workflow.nodes?.find((node: any) => node.type === "trigger");
          const triggerType = trigger?.type || trigger?.config?.type || "manual";
          const sequence = ["trigger-1", ...generatedActions.map((action: any) => action.id), "end-1"];

          setWorkflowName(workflow.name || "AI Generated Workflow");
          setWorkflowDescription(workflow.description || `Generated from: ${prompt}`);
          setNodes([
            {
              id: "trigger-1",
              type: "trigger",
              label: String(triggerType).charAt(0).toUpperCase() + String(triggerType).slice(1),
              icon: trigger?.icon || "▶️",
              x: 100,
              y: 50,
              width: 140,
              height: 80,
              config: { type: triggerType, ...(trigger?.config || {}) },
            },
            ...generatedActions,
            {
              id: "end-1",
              type: "end",
              label: "Complete",
              icon: "✓",
              x: 100,
              y: 180 + generatedActions.length * 110,
              width: 140,
              height: 80,
            },
          ]);
          setConnections(sequence.slice(0, -1).map((from, index) => ({ from, to: sequence[index + 1] })));
          setSelectedNode(null);
          setActiveTab("canvas");
        }}
      />
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 sticky top-0 z-30">
        <div className="container py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-display font-bold text-white">
                Advanced Workflow Builder
              </h1>
              <p className="text-slate-400 text-sm mt-1">
                Design powerful autonomous workflows with visual canvas
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="border-slate-600 text-white hover:bg-slate-700"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button
                className="bg-accent hover:bg-accent/90 text-primary font-semibold"
                onClick={handleSaveWorkflow}
                disabled={createWorkflow.isPending || updateWorkflow.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                {createWorkflow.isPending || updateWorkflow.isPending
                  ? "Saving..."
                  : workflowId
                    ? "Save New Version"
                    : "Save Workflow"}
              </Button>
            </div>
          </div>

          {/* Workflow Info */}
          <div className="grid md:grid-cols-2 gap-4">
            <Input
              value={workflowName}
              onChange={(e) => setWorkflowName(e.target.value)}
              placeholder="Workflow name"
              className="bg-slate-700 border-slate-600 text-white"
            />
            <Textarea
              value={workflowDescription}
              onChange={(e) => setWorkflowDescription(e.target.value)}
              placeholder="Workflow description"
              className="bg-slate-700 border-slate-600 text-white"
              rows={1}
            />
          </div>
          {(saveError || saveNotice) && (
            <p className={`mt-3 text-sm ${saveError ? "text-red-300" : "text-emerald-300"}`}>
              {saveError || saveNotice}
            </p>
          )}
        </div>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="bg-slate-800 border-b border-slate-700 sticky top-16 z-20">
          <div className="container">
            <TabsList className="bg-transparent border-b border-slate-700 rounded-none w-full justify-start">
              <TabsTrigger
                value="canvas"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
              >
                <span className="w-4 h-4 mr-2">🎨</span>
                Canvas
              </TabsTrigger>
              <TabsTrigger
                value="templates"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
              >
                <Library className="w-4 h-4 mr-2" />
                Templates
              </TabsTrigger>
              <TabsTrigger
                value="preview"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
              >
                <Play className="w-4 h-4 mr-2" />
                Preview
              </TabsTrigger>
              <TabsTrigger
                value="settings"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
              <TabsTrigger
                value="history"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
              >
                <History className="w-4 h-4 mr-2" />
                History
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        {/* Canvas Tab */}
        <TabsContent value="canvas" className="m-0 p-0">
          <div className="flex h-[calc(100vh-200px)]">
            {/* Canvas Area */}
            <div className="flex-1">
              <AdvancedCanvas
                nodes={nodes}
                connections={connections}
                onNodeClick={(nodeId) => setSelectedNode(nodeId)}
                onNodeDrag={handleNodeDrag}
                onNodeRemove={handleNodeRemove}
                onNodeDuplicate={handleNodeDuplicate}
                onConnectionCreate={handleConnectionCreate}
                onConnectionRemove={() => {}}
              />
            </div>

            {/* Sidebar */}
            <div className="w-80 bg-slate-800 border-l border-slate-700 overflow-y-auto p-4 space-y-4">
              {/* Add Action Button */}
              <Button
                className="w-full bg-accent hover:bg-accent/90 text-primary font-semibold"
                onClick={handleAddAction}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Action
              </Button>

              {/* Selected Node Config */}
              {selectedNodeData && selectedNodeData.type === "trigger" && (
                <TriggerPanel
                  trigger={{
                    type: selectedNodeData.config?.type as string || "manual",
                    config: selectedNodeData.config || {},
                  }}
                  triggerTypes={[
                    {
                      id: "manual",
                      name: "Manual",
                      description: "Trigger manually",
                      inputs: [],
                    },
                    {
                      id: "schedule",
                      name: "Schedule",
                      description: "Trigger on schedule",
                      inputs: [
                        {
                          key: "cron",
                          label: "Cron Expression",
                          type: "text",
                          placeholder: "0 9 * * *",
                        },
                      ],
                    },
                  ]}
                  onUpdate={() => {}}
                  onClose={() => setSelectedNode(null)}
                />
              )}

              {/* Node Info */}
              {selectedNodeData && (
                <Card className="p-4 bg-slate-700 border-slate-600">
                  <h4 className="font-semibold text-white mb-2">Node Info</h4>
                  <div className="space-y-2 text-sm text-slate-300">
                    <p>
                      <span className="text-slate-400">Type:</span> {selectedNodeData.type}
                    </p>
                    <p>
                      <span className="text-slate-400">Position:</span> ({selectedNodeData.x},
                      {selectedNodeData.y})
                    </p>
                    <p>
                      <span className="text-slate-400">Connections:</span>{" "}
                      {connections.filter(
                        (c) => c.from === selectedNodeData.id || c.to === selectedNodeData.id
                      ).length}
                    </p>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="m-0 p-8">
          <TemplateLibrary
            templates={WORKFLOW_TEMPLATES}
            onUseTemplate={handleUseTemplate}
          />
        </TabsContent>

        {/* Preview Tab */}
        <TabsContent value="preview" className="m-0 p-8">
          <div className="max-w-2xl">
            <ExecutionPreview
              workflowName={workflowName}
              steps={executionSteps}
              isRunning={isExecuting}
              totalDuration={totalDuration}
              onRun={handleRunPreview}
              onPause={() => setIsExecuting(false)}
              onReset={() => {
                setExecutionSteps([]);
                setTotalDuration(0);
              }}
            />
          </div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="m-0 p-8">
          <div className="max-w-2xl space-y-6">
            <Card className="p-6 bg-slate-800 border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-4">
                Workflow Settings
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-300 block mb-2">
                    Timeout (seconds)
                  </label>
                  <Input
                    type="number"
                    defaultValue="300"
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-300 block mb-2">
                    Max Retries
                  </label>
                  <Input
                    type="number"
                    value={retryPolicy.maxAttempts}
                    min={1}
                    max={5}
                    onChange={(event) => setRetryPolicy((current) => ({
                      ...current,
                      maxAttempts: Math.max(1, Math.min(5, Number(event.target.value) || 1)),
                    }))}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-300 block mb-2">
                    Initial backoff (milliseconds)
                  </label>
                  <Input
                    type="number"
                    value={retryPolicy.backoffMs}
                    min={0}
                    max={10000}
                    onChange={(event) => setRetryPolicy((current) => ({
                      ...current,
                      backoffMs: Math.max(0, Math.min(10000, Number(event.target.value) || 0)),
                    }))}
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="m-0 p-8">
          <div className="max-w-3xl">
            <Card className="p-6 bg-slate-800 border-slate-700">
              <div className="flex items-start justify-between gap-4 mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-white">Version History</h3>
                  <p className="text-sm text-slate-400 mt-1">
                    Every save creates an immutable workflow snapshot you can restore.
                  </p>
                </div>
                <History className="w-5 h-5 text-accent" />
              </div>
              {!workflowId ? (
                <div className="rounded-lg border border-dashed border-slate-700 p-8 text-center">
                  <p className="text-sm text-slate-400">
                    Save this workflow to start building its revision history.
                  </p>
                </div>
              ) : versionsLoading ? (
                <p className="text-sm text-slate-400">Loading version history...</p>
              ) : versionsHasError ? (
                <p className="text-sm text-red-300">
                  Unable to load version history. Refresh and try again.
                </p>
              ) : versions && versions.length > 0 ? (
                <div className="space-y-3">
                  {versions.map((version, index) => (
                    <div
                      key={version.id}
                      className="rounded-lg border border-slate-700 bg-slate-900/50 p-4"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-medium text-white">
                            Version {version.version}
                            {index === 0 && (
                              <span className="ml-2 text-xs text-accent">Current</span>
                            )}
                          </p>
                          <p className="text-sm text-slate-400 mt-1">
                            {version.changeSummary || "Workflow snapshot"}
                          </p>
                          <p className="text-xs text-slate-500 mt-2">
                            {new Date(version.createdAt).toLocaleString()}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRestoreVersion(version)}
                          disabled={restoreVersion.isPending || index === 0}
                        >
                          Restore
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-slate-700 p-8 text-center">
                  <p className="text-sm text-slate-400">
                    No revisions have been recorded yet.
                  </p>
                </div>
              )}
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
