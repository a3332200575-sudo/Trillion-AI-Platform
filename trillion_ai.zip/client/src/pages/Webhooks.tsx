import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Copy,
  KeyRound,
  Plus,
  RefreshCw,
  ShieldCheck,
  Webhook as WebhookIcon,
  XCircle,
} from "lucide-react";

const formatDate = (value: Date | string | null) =>
  value ? new Date(value).toLocaleString() : "Never";

export default function Webhooks() {
  const [name, setName] = useState("");
  const [workflowId, setWorkflowId] = useState("");
  const [selectedWebhookId, setSelectedWebhookId] = useState<number | null>(null);
  const [newSecret, setNewSecret] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const utils = trpc.useUtils();
  const webhooksQuery = trpc.webhook.list.useQuery();
  const deliveriesQuery = trpc.webhook.deliveries.useQuery(
    { webhookId: selectedWebhookId ?? 0 },
    { enabled: selectedWebhookId !== null }
  );
  const createWebhook = trpc.webhook.create.useMutation({
    onSuccess: (created) => {
      setName("");
      setWorkflowId("");
      setNewSecret(created.signingSecret);
      setSelectedWebhookId(created.id);
      void utils.webhook.list.invalidate();
    },
    onError: (error) => setFormError(error.message),
  });
  const rotateSecret = trpc.webhook.rotateSecret.useMutation({
    onSuccess: (result) => setNewSecret(result.signingSecret),
    onError: (error) => setFormError(error.message),
  });
  const setStatus = trpc.webhook.setStatus.useMutation({
    onSuccess: () => void utils.webhook.list.invalidate(),
    onError: (error) => setFormError(error.message),
  });

  const selectedWebhook = useMemo(
    () => webhooksQuery.data?.find((webhook) => webhook.id === selectedWebhookId) || null,
    [selectedWebhookId, webhooksQuery.data]
  );

  const endpointFor = (token: string) =>
    `${window.location.origin}/api/webhooks/${token}`;

  const copyText = async (key: string, value: string) => {
    await navigator.clipboard.writeText(value);
    setCopied(key);
    window.setTimeout(() => setCopied(null), 1600);
  };

  const handleCreate = (event: React.FormEvent) => {
    event.preventDefault();
    setFormError(null);
    const parsedWorkflowId = Number(workflowId);
    if (!Number.isInteger(parsedWorkflowId) || parsedWorkflowId < 1) {
      setFormError("Enter a valid workflow ID.");
      return;
    }
    createWebhook.mutate({ name, workflowId: parsedWorkflowId });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-11 h-11 rounded-2xl bg-primary text-accent flex items-center justify-center">
                <WebhookIcon className="w-6 h-6" />
              </div>
              <Badge className="bg-accent/15 text-accent border-accent/30">FEATURE 6</Badge>
            </div>
            <h1 className="text-4xl font-bold text-slate-900">Webhook Management</h1>
            <p className="text-slate-600 mt-2 max-w-2xl">
              Create signed inbound endpoints for your workflows and monitor every delivery without exposing secrets.
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            HMAC-SHA256 protected
          </div>
        </header>

        <div className="grid lg:grid-cols-[360px_1fr] gap-6 items-start">
          <Card className="p-6 bg-white border-slate-200">
            <div className="flex items-center gap-2 mb-5">
              <Plus className="w-5 h-5 text-accent" />
              <h2 className="text-lg font-semibold text-slate-900">Create endpoint</h2>
            </div>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-700">Endpoint name</label>
                <Input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Lead intake webhook"
                  className="mt-2"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700">Workflow ID</label>
                <Input
                  value={workflowId}
                  onChange={(event) => setWorkflowId(event.target.value)}
                  placeholder="e.g. 42"
                  inputMode="numeric"
                  className="mt-2"
                  required
                />
                <p className="text-xs text-slate-500 mt-2">Use the numeric ID of the workflow this endpoint should receive.</p>
              </div>
              {formError && (
                <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700 flex gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  {formError}
                </div>
              )}
              <Button
                type="submit"
                className="w-full bg-accent hover:bg-accent/90 text-primary font-semibold"
                disabled={createWebhook.isPending}
              >
                <Plus className="w-4 h-4 mr-2" />
                {createWebhook.isPending ? "Creating..." : "Create signed endpoint"}
              </Button>
            </form>
            <div className="mt-6 rounded-xl bg-slate-50 border border-slate-200 p-4 text-xs text-slate-600 space-y-2">
              <p className="font-semibold text-slate-800">Security model</p>
              <p>Send the signature header as <code className="font-mono">sha256=HMAC_HEX</code> using the signing secret shown once after creation or rotation.</p>
            </div>
          </Card>

          <div className="space-y-6">
            {newSecret && (
              <Card className="p-5 bg-emerald-50 border-emerald-200">
                <div className="flex items-start gap-3">
                  <KeyRound className="w-5 h-5 text-emerald-700 mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-emerald-900">Copy this signing secret now</p>
                    <p className="text-sm text-emerald-800 mt-1">For security, it will not be shown again after you leave this page or rotate it.</p>
                    <div className="flex gap-2 mt-3">
                      <code className="flex-1 min-w-0 rounded-lg bg-white border border-emerald-200 px-3 py-2 text-xs break-all text-emerald-950">{newSecret}</code>
                      <Button variant="outline" size="sm" onClick={() => copyText("secret", newSecret)}>
                        {copied === "secret" ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setNewSecret(null)} aria-label="Dismiss secret">
                    <XCircle className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            )}

            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">Your endpoints</h2>
                  <p className="text-sm text-slate-500 mt-1">Select an endpoint to view delivery activity.</p>
                </div>
                <Button variant="outline" size="sm" onClick={() => void webhooksQuery.refetch()} disabled={webhooksQuery.isFetching}>
                  <RefreshCw className={`w-4 h-4 mr-2 ${webhooksQuery.isFetching ? "animate-spin" : ""}`} /> Refresh
                </Button>
              </div>
              {webhooksQuery.isLoading ? (
                <p className="text-sm text-slate-500 py-8 text-center">Loading endpoints...</p>
              ) : webhooksQuery.isError ? (
                <p className="text-sm text-red-700 py-8 text-center">Unable to load webhook endpoints.</p>
              ) : webhooksQuery.data?.length ? (
                <div className="space-y-3">
                  {webhooksQuery.data.map((webhook) => {
                    const endpoint = endpointFor(webhook.endpointToken);
                    const isSelected = selectedWebhookId === webhook.id;
                    return (
                      <button
                        key={webhook.id}
                        className={`w-full text-left rounded-xl border p-4 transition-colors ${isSelected ? "border-accent bg-accent/5" : "border-slate-200 hover:border-accent/50"}`}
                        onClick={() => {
                          setSelectedWebhookId(webhook.id);
                          setFormError(null);
                        }}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-slate-900 truncate">{webhook.name}</p>
                              <Badge className={webhook.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-600"}>{webhook.status}</Badge>
                            </div>
                            <p className="text-xs text-slate-500 mt-2">Workflow #{webhook.workflowId} · Last received {formatDate(webhook.lastTriggeredAt)}</p>
                            <code className="block text-xs text-slate-500 mt-2 truncate">{endpoint}</code>
                          </div>
                          <Activity className="w-5 h-5 text-accent shrink-0" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="py-10 text-center">
                  <WebhookIcon className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                  <p className="font-medium text-slate-700">No webhook endpoints yet</p>
                  <p className="text-sm text-slate-500 mt-1">Create one to connect external events to a workflow.</p>
                </div>
              )}
            </Card>
          </div>
        </div>

        {selectedWebhook && (
          <div className="grid lg:grid-cols-[1fr_320px] gap-6 items-start">
            <Card className="p-6 bg-white border-slate-200">
              <div className="flex items-center justify-between gap-4 mb-5">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">Delivery activity</h2>
                  <p className="text-sm text-slate-500 mt-1">The latest 50 requests are retained for this endpoint.</p>
                </div>
                <Button variant="outline" size="sm" onClick={() => void deliveriesQuery.refetch()} disabled={deliveriesQuery.isFetching}>
                  <RefreshCw className={`w-4 h-4 mr-2 ${deliveriesQuery.isFetching ? "animate-spin" : ""}`} /> Refresh
                </Button>
              </div>
              {deliveriesQuery.isLoading ? (
                <p className="text-sm text-slate-500 py-8 text-center">Loading deliveries...</p>
              ) : deliveriesQuery.isError ? (
                <p className="text-sm text-red-700 py-8 text-center">Unable to load deliveries.</p>
              ) : deliveriesQuery.data?.length ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="text-left text-xs uppercase tracking-wide text-slate-500 border-b border-slate-200"><th className="py-3 pr-4">Status</th><th className="py-3 pr-4">Response</th><th className="py-3 pr-4">Execution</th><th className="py-3 pr-4">Duration</th><th className="py-3">Received</th></tr></thead>
                    <tbody>
                      {deliveriesQuery.data.map((delivery) => (
                        <tr key={delivery.id} className="border-b border-slate-100 last:border-0">
                          <td className="py-3 pr-4"><span className={`inline-flex items-center gap-1.5 ${delivery.status === "accepted" ? "text-emerald-700" : "text-red-700"}`}>{delivery.status === "accepted" ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}{delivery.status}</span></td>
                          <td className="py-3 pr-4 text-slate-600">{delivery.responseStatus ?? "—"}{delivery.error ? <span className="block text-xs text-red-600">{delivery.error}</span> : null}</td>
                          <td className="py-3 pr-4 text-slate-600">{delivery.executionLogId ? `#${delivery.executionLogId}` : "—"}</td>
                          <td className="py-3 pr-4 text-slate-600">{delivery.durationMs ?? 0} ms</td>
                          <td className="py-3 text-slate-500">{formatDate(delivery.createdAt)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="py-10 text-center"><p className="text-sm text-slate-500">No deliveries recorded yet.</p></div>
              )}
            </Card>

            <Card className="p-6 bg-white border-slate-200 space-y-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Endpoint controls</p>
                <p className="font-semibold text-slate-900 mt-1">{selectedWebhook.name}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 mb-2">Public endpoint</p>
                <div className="flex gap-2"><code className="min-w-0 flex-1 text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 truncate">{endpointFor(selectedWebhook.endpointToken)}</code><Button variant="outline" size="sm" onClick={() => copyText("endpoint", endpointFor(selectedWebhook.endpointToken))}>{copied === "endpoint" ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}</Button></div>
              </div>
              <Button variant="outline" className="w-full" onClick={() => rotateSecret.mutate({ webhookId: selectedWebhook.id })} disabled={rotateSecret.isPending}>
                <KeyRound className="w-4 h-4 mr-2" /> {rotateSecret.isPending ? "Rotating..." : "Rotate signing secret"}
              </Button>
              <Button variant={selectedWebhook.status === "active" ? "destructive" : "default"} className="w-full" onClick={() => setStatus.mutate({ webhookId: selectedWebhook.id, status: selectedWebhook.status === "active" ? "disabled" : "active" })} disabled={setStatus.isPending}>
                {selectedWebhook.status === "active" ? <XCircle className="w-4 h-4 mr-2" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                {selectedWebhook.status === "active" ? "Disable endpoint" : "Enable endpoint"}
              </Button>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
