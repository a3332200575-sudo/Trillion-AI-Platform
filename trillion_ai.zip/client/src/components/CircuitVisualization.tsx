import { useEffect, useRef } from 'react';

/**
 * CircuitVisualization - Animated circuit network for hero section
 * Shows interconnected nodes and flowing paths representing autonomous AI agents
 */
export function CircuitVisualization() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth * window.devicePixelRatio;
    canvas.height = canvas.offsetHeight * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;

    // Define nodes (agent points)
    const nodes = [
      { x: width * 0.2, y: height * 0.3, active: true },
      { x: width * 0.5, y: height * 0.1, active: false },
      { x: width * 0.8, y: height * 0.25, active: true },
      { x: width * 0.7, y: height * 0.65, active: true },
      { x: width * 0.3, y: height * 0.75, active: false },
      { x: width * 0.5, y: height * 0.5, active: true }, // Center hub
    ];

    // Define connections
    const connections = [
      [0, 5], [1, 5], [2, 5], [3, 5], [4, 5],
      [0, 2], [2, 3], [3, 4], [4, 0]
    ];

    let animationTime = 0;

    const animate = () => {
      animationTime += 0.01;

      // Clear canvas
      ctx.fillStyle = 'rgba(255, 255, 255, 1)';
      ctx.fillRect(0, 0, width, height);

      // Draw connections with animated flow
      connections.forEach(([from, to]) => {
        const fromNode = nodes[from];
        const toNode = nodes[to];

        // Draw connection line
        ctx.strokeStyle = 'rgba(0, 217, 255, 0.15)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);
        ctx.stroke();

        // Draw animated flow particles
        const distance = Math.hypot(toNode.x - fromNode.x, toNode.y - fromNode.y);
        const flow = (animationTime * 100) % distance;

        const t = flow / distance;
        const px = fromNode.x + (toNode.x - fromNode.x) * t;
        const py = fromNode.y + (toNode.y - fromNode.y) * t;

        ctx.fillStyle = 'rgba(0, 217, 255, 0.6)';
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw nodes
      nodes.forEach((node, index) => {
        const pulse = Math.sin(animationTime * 2 + index) * 0.5 + 1;

        if (node.active) {
          // Outer glow
          ctx.fillStyle = `rgba(0, 217, 255, ${0.2 * pulse})`;
          ctx.beginPath();
          ctx.arc(node.x, node.y, 12 * pulse, 0, Math.PI * 2);
          ctx.fill();

          // Inner circle
          ctx.fillStyle = 'rgba(0, 217, 255, 0.9)';
          ctx.beginPath();
          ctx.arc(node.x, node.y, 6, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // Inactive node
          ctx.fillStyle = 'rgba(26, 31, 58, 0.3)';
          ctx.beginPath();
          ctx.arc(node.x, node.y, 4, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      requestAnimationFrame(animate);
    };

    animate();
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: 'block' }}
    />
  );
}
