/**
 * GeometricDivider - Precision engineering aesthetic divider
 * Uses geometric patterns to separate sections with a tech-forward feel
 */
export function GeometricDivider({ variant = "wave" }: { variant?: "wave" | "diagonal" | "dots" }) {
  if (variant === "diagonal") {
    return (
      <svg
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
        className="w-full h-24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="diagonalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d9ff" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#00d9ff" stopOpacity="0" />
          </linearGradient>
        </defs>
        <polygon points="0,0 1200,40 1200,120 0,120" fill="url(#diagonalGrad)" />
        <line x1="0" y1="40" x2="1200" y2="40" stroke="#00d9ff" strokeWidth="1" opacity="0.3" />
      </svg>
    );
  }

  if (variant === "dots") {
    return (
      <div className="w-full py-12 flex items-center justify-center gap-3">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="w-2 h-2 rounded-full bg-accent"
            style={{
              opacity: i === 2 ? 1 : 0.4,
              animation: `pulse 2s ease-in-out ${i * 0.2}s infinite`,
            }}
          />
        ))}
      </div>
    );
  }

  // Default wave
  return (
    <svg
      viewBox="0 0 1200 100"
      preserveAspectRatio="none"
      className="w-full h-20"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="waveGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#00d9ff" stopOpacity="0.2" />
          <stop offset="50%" stopColor="#00d9ff" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#00d9ff" stopOpacity="0.2" />
        </linearGradient>
      </defs>
      <path
        d="M0,50 Q300,0 600,50 T1200,50 L1200,100 L0,100 Z"
        fill="url(#waveGrad)"
      />
      <path
        d="M0,50 Q300,0 600,50 T1200,50"
        stroke="#00d9ff"
        strokeWidth="2"
        fill="none"
        opacity="0.5"
      />
    </svg>
  );
}
