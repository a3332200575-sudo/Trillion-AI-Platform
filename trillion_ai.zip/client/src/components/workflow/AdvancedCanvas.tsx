import { useRef, useState, useCallback, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Copy, ZoomIn, ZoomOut, Grid3x3 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Node {
  id: string;
  type: "trigger" | "action" | "end";
  label: string;
  icon: string;
  x: number;
  y: number;
  width: number;
  height: number;
  config?: Record<string, unknown>;
}

interface Connection {
  from: string;
  to: string;
}

interface AdvancedCanvasProps {
  nodes: Node[];
  connections: Connection[];
  onNodeClick: (nodeId: string) => void;
  onNodeDrag: (nodeId: string, x: number, y: number) => void;
  onNodeRemove: (nodeId: string) => void;
  onNodeDuplicate: (nodeId: string) => void;
  onConnectionCreate: (from: string, to: string) => void;
  onConnectionRemove: (from: string, to: string) => void;
}

const GRID_SIZE = 20;
const NODE_WIDTH = 140;
const NODE_HEIGHT = 80;

export default function AdvancedCanvas({
  nodes,
  connections,
  onNodeClick,
  onNodeDrag,
  onNodeRemove,
  onNodeDuplicate,
  onConnectionCreate,
  onConnectionRemove,
}: AdvancedCanvasProps) {
  const canvasRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [draggingNode, setDraggingNode] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [connectionMode, setConnectionMode] = useState<string | null>(null);

  // Handle canvas pan and zoom
  const handleWheel = useCallback((e: WheelEvent) => {
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();

    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom((prev) => Math.max(0.5, Math.min(3, prev * delta)));
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.addEventListener("wheel", handleWheel, { passive: false });
    return () => container.removeEventListener("wheel", handleWheel);
  }, [handleWheel]);

  // Handle node dragging
  const handleNodeMouseDown = (
    e: React.MouseEvent,
    nodeId: string,
    node: Node
  ) => {
    e.preventDefault();
    setDraggingNode(nodeId);
    setSelectedNode(nodeId);

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    setDragOffset({
      x: e.clientX - rect.left - node.x * zoom - pan.x,
      y: e.clientY - rect.top - node.y * zoom - pan.y,
    });
  };

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!draggingNode || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = Math.round((e.clientX - rect.left - pan.x) / zoom / GRID_SIZE) * GRID_SIZE;
    const y = Math.round((e.clientY - rect.top - pan.y) / zoom / GRID_SIZE) * GRID_SIZE;

    onNodeDrag(draggingNode, x, y);
  }, [draggingNode, zoom, pan, onNodeDrag]);

  const handleMouseUp = () => {
    setDraggingNode(null);
  };

  // Draw connection lines
  const getConnectionPath = (from: Node, to: Node) => {
    const fromX = from.x + from.width / 2;
    const fromY = from.y + from.height;
    const toX = to.x + to.width / 2;
    const toY = to.y;

    const midY = (fromY + toY) / 2;

    return `M ${fromX} ${fromY} C ${fromX} ${midY}, ${toX} ${midY}, ${toX} ${toY}`;
  };

  const getNodeById = (id: string) => nodes.find((n) => n.id === id);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-screen bg-gradient-to-br from-slate-900 to-slate-800 overflow-hidden"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Toolbar */}
      <div className="absolute top-4 left-4 z-20 flex gap-2">
        <Button
          size="sm"
          variant="outline"
          className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
          onClick={() => setZoom((z) => Math.min(3, z + 0.2))}
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
          onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))}
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
          onClick={() => {
            setZoom(1);
            setPan({ x: 0, y: 0 });
          }}
        >
          <Grid3x3 className="w-4 h-4" />
        </Button>
      </div>

      {/* Canvas */}
      <svg
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ cursor: draggingNode ? "grabbing" : "grab" }}
      >
        {/* Grid Background */}
        <defs>
          <pattern
            id="grid"
            width={GRID_SIZE * zoom}
            height={GRID_SIZE * zoom}
            patternUnits="userSpaceOnUse"
            x={pan.x}
            y={pan.y}
          >
            <path
              d={`M ${GRID_SIZE * zoom} 0 L 0 0 0 ${GRID_SIZE * zoom}`}
              fill="none"
              stroke="rgba(255,255,255,0.05)"
              strokeWidth="1"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />

        {/* Connection Lines */}
        <g>
          {connections.map((conn) => {
            const fromNode = getNodeById(conn.from);
            const toNode = getNodeById(conn.to);
            if (!fromNode || !toNode) return null;

            return (
              <motion.path
                key={`${conn.from}-${conn.to}`}
                d={getConnectionPath(fromNode, toNode)}
                stroke="#00d9ff"
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
                style={{
                  transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                  transformOrigin: "0 0",
                }}
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.5 }}
              />
            );
          })}
        </g>

        {/* Nodes */}
        <g style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}>
          <AnimatePresence>
            {nodes.map((node) => (
              <motion.g
                key={node.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                onMouseDown={(e) => handleNodeMouseDown(e as any, node.id, node)}
              >
                {/* Node Background */}
                <rect
                  x={node.x}
                  y={node.y}
                  width={node.width}
                  height={node.height}
                  rx="8"
                  fill={
                    selectedNode === node.id
                      ? "rgba(0, 217, 255, 0.2)"
                      : "rgba(30, 41, 59, 0.8)"
                  }
                  stroke={
                    selectedNode === node.id ? "#00d9ff" : "rgba(100, 116, 139, 0.5)"
                  }
                  strokeWidth="2"
                  className="transition-all cursor-grab active:cursor-grabbing"
                />

                {/* Node Icon */}
                <text
                  x={node.x + node.width / 2}
                  y={node.y + 25}
                  textAnchor="middle"
                  fontSize="24"
                  fill="white"
                >
                  {node.icon}
                </text>

                {/* Node Label */}
                <text
                  x={node.x + node.width / 2}
                  y={node.y + 55}
                  textAnchor="middle"
                  fontSize="12"
                  fill="rgba(255, 255, 255, 0.8)"
                  className="pointer-events-none"
                >
                  {node.label}
                </text>

                {/* Connection Points */}
                {node.type !== "end" && (
                  <circle
                    cx={node.x + node.width / 2}
                    cy={node.y + node.height}
                    r="6"
                    fill="#00d9ff"
                    opacity="0.5"
                    className="hover:opacity-100 cursor-pointer transition-opacity"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setConnectionMode(node.id);
                    }}
                  />
                )}

                {node.type !== "trigger" && (
                  <circle
                    cx={node.x + node.width / 2}
                    cy={node.y}
                    r="6"
                    fill="#00d9ff"
                    opacity="0.5"
                    className="hover:opacity-100 cursor-pointer transition-opacity"
                    onMouseUp={(e) => {
                      if (connectionMode && connectionMode !== node.id) {
                        onConnectionCreate(connectionMode, node.id);
                        setConnectionMode(null);
                      }
                    }}
                  />
                )}
              </motion.g>
            ))}
          </AnimatePresence>
        </g>
      </svg>

      {/* Node Context Menu */}
      {selectedNode && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute bottom-4 right-4 z-30 flex gap-2 bg-slate-700 p-3 rounded-lg border border-slate-600"
        >
          <Button
            size="sm"
            variant="ghost"
            className="text-white hover:bg-slate-600"
            onClick={() => onNodeDuplicate(selectedNode)}
          >
            <Copy className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="text-red-400 hover:bg-red-900/20"
            onClick={() => {
              onNodeRemove(selectedNode);
              setSelectedNode(null);
            }}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </motion.div>
      )}

      {/* Empty State */}
      {nodes.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="text-center">
            <div className="text-5xl mb-4">🎨</div>
            <p className="text-slate-400 text-lg">
              Start building your workflow
            </p>
            <p className="text-slate-500 text-sm mt-2">
              Add actions from the sidebar to begin
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
