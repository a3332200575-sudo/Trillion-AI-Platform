import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X, Trash2 } from "lucide-react";
import { useState } from "react";

interface ActionPanelProps {
  action: {
    id: string;
    type: string;
    integrationId: number;
    config: Record<string, unknown>;
  };
  actionType: {
    id: string;
    name: string;
    description: string;
    inputs: Array<{
      key: string;
      label: string;
      type: string;
      placeholder?: string;
      options?: string[];
      required?: boolean;
    }>;
  };
  integrations: Array<{ id: number; name: string; type: string }>;
  onUpdate: (config: Record<string, unknown>) => void;
  onRemove: () => void;
  onClose: () => void;
}

export default function ActionPanel({
  action,
  actionType,
  integrations,
  onUpdate,
  onRemove,
  onClose,
}: ActionPanelProps) {
  const [config, setConfig] = useState<Record<string, unknown>>(action.config);
  const [integrationId, setIntegrationId] = useState(
    action.integrationId.toString()
  );

  const handleConfigChange = (key: string, value: unknown) => {
    setConfig((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    onUpdate(config);
    onClose();
  };

  return (
    <Card className="p-4 border-2 border-primary bg-gradient-to-br from-primary/5 to-transparent">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">{actionType.name}</h3>
        <button
          onClick={onClose}
          className="p-1 hover:bg-muted rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <p className="text-xs text-muted-foreground mb-4">
        {actionType.description}
      </p>

      {/* Integration Selection */}
      {integrations.length > 0 && (
        <div className="mb-4 pb-4 border-b border-border">
          <label className="text-xs font-medium text-muted-foreground uppercase mb-2 block">
            Integration
          </label>
          <Select value={integrationId} onValueChange={setIntegrationId}>
            <SelectTrigger className="text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {integrations.map((integration) => (
                <SelectItem key={integration.id} value={integration.id.toString()}>
                  {integration.name} ({integration.type})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Configuration Inputs */}
      {actionType.inputs.length > 0 && (
        <div className="space-y-3 mb-4 pb-4 border-b border-border">
          <label className="text-xs font-medium text-muted-foreground uppercase">
            Configuration
          </label>
          {actionType.inputs.map((input) => (
            <div key={input.key}>
              <label className="text-xs font-medium text-foreground mb-1 block">
                {input.label}
                {input.required && <span className="text-red-500">*</span>}
              </label>
              {input.type === "textarea" ? (
                <Textarea
                  value={(config[input.key] as string) || ""}
                  onChange={(e) => handleConfigChange(input.key, e.target.value)}
                  placeholder={input.placeholder}
                  className="text-sm"
                  rows={3}
                />
              ) : input.type === "select" && input.options ? (
                <Select
                  value={(config[input.key] as string) || ""}
                  onValueChange={(value) => handleConfigChange(input.key, value)}
                >
                  <SelectTrigger className="text-sm">
                    <SelectValue placeholder={input.placeholder} />
                  </SelectTrigger>
                  <SelectContent>
                    {input.options.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : input.type === "json" ? (
                <Textarea
                  value={
                    typeof config[input.key] === "string"
                      ? (config[input.key] as string)
                      : JSON.stringify(config[input.key] || {}, null, 2)
                  }
                  onChange={(e) => {
                    try {
                      handleConfigChange(input.key, JSON.parse(e.target.value));
                    } catch {
                      handleConfigChange(input.key, e.target.value);
                    }
                  }}
                  placeholder={input.placeholder}
                  className="text-sm font-mono"
                  rows={4}
                />
              ) : (
                <Input
                  type={input.type}
                  value={(config[input.key] as string) || ""}
                  onChange={(e) => handleConfigChange(input.key, e.target.value)}
                  placeholder={input.placeholder}
                  className="text-sm"
                />
              )}
            </div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button
          size="sm"
          className="flex-1 bg-primary hover:bg-primary/90 text-white font-semibold"
          onClick={handleSave}
        >
          Save
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="flex-1"
          onClick={onClose}
        >
          Cancel
        </Button>
        <Button
          size="sm"
          variant="ghost"
          className="text-red-500 hover:bg-red-50"
          onClick={onRemove}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}
