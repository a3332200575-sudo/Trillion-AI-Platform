import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  AlertCircle,
  Clock,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface ExecutionStep {
  id: string;
  name: string;
  status: "pending" | "running" | "success" | "failed";
  duration?: number;
  output?: Record<string, unknown>;
  error?: string;
}

interface ExecutionPreviewProps {
  workflowName: string;
  steps: ExecutionStep[];
  isRunning: boolean;
  totalDuration: number;
  onRun: () => void;
  onPause: () => void;
  onReset: () => void;
}

export default function ExecutionPreview({
  workflowName,
  steps,
  isRunning,
  totalDuration,
  onRun,
  onPause,
  onReset,
}: ExecutionPreviewProps) {
  const [expandedStep, setExpandedStep] = useState<string | null>(null);

  const successCount = steps.filter((s) => s.status === "success").length;
  const failedCount = steps.filter((s) => s.status === "failed").length;
  const successRate =
    steps.length > 0 ? ((successCount / steps.length) * 100).toFixed(1) : 0;

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card className="p-4 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">
              Execution Preview
            </h3>
            <p className="text-sm text-muted-foreground">{workflowName}</p>
          </div>
          <div className="flex gap-2">
            {!isRunning ? (
              <Button
                size="sm"
                className="bg-accent hover:bg-accent/90 text-primary font-semibold"
                onClick={onRun}
              >
                <Play className="w-4 h-4 mr-2" />
                Run Preview
              </Button>
            ) : (
              <Button
                size="sm"
                variant="outline"
                onClick={onPause}
              >
                <Pause className="w-4 h-4 mr-2" />
                Pause
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={onReset}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Total Steps</p>
            <p className="text-2xl font-bold text-foreground">{steps.length}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Success Rate</p>
            <p className="text-2xl font-bold text-green-600">{successRate}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Duration</p>
            <p className="text-2xl font-bold text-primary">{totalDuration}ms</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Status</p>
            <p className="text-2xl font-bold text-accent">
              {isRunning ? "Running" : "Ready"}
            </p>
          </div>
        </div>
      </Card>

      {/* Execution Steps */}
      <div className="space-y-2">
        <h4 className="font-semibold text-foreground text-sm">Execution Flow</h4>

        <AnimatePresence>
          {steps.map((step, index) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card
                className="p-3 cursor-pointer hover:shadow-md transition-all"
                onClick={() =>
                  setExpandedStep(
                    expandedStep === step.id ? null : step.id
                  )
                }
              >
                <div className="flex items-center gap-3">
                  {/* Status Icon */}
                  <div className="flex-shrink-0">
                    {step.status === "success" && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-green-500"
                      >
                        <CheckCircle className="w-5 h-5" />
                      </motion.div>
                    )}
                    {step.status === "failed" && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-red-500"
                      >
                        <AlertCircle className="w-5 h-5" />
                      </motion.div>
                    )}
                    {step.status === "running" && (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity }}
                        className="text-accent"
                      >
                        <Zap className="w-5 h-5" />
                      </motion.div>
                    )}
                    {step.status === "pending" && (
                      <div className="text-muted-foreground">
                        <Clock className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  {/* Step Info */}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground text-sm">
                      {step.name}
                    </p>
                    {step.duration && (
                      <p className="text-xs text-muted-foreground">
                        {step.duration}ms
                      </p>
                    )}
                  </div>

                  {/* Status Badge */}
                  <Badge
                    className={`text-xs ${
                      step.status === "success"
                        ? "bg-green-100 text-green-800"
                        : step.status === "failed"
                        ? "bg-red-100 text-red-800"
                        : step.status === "running"
                        ? "bg-blue-100 text-blue-800"
                        : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    {step.status}
                  </Badge>
                </div>

                {/* Expanded Details */}
                <AnimatePresence>
                  {expandedStep === step.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t border-border"
                    >
                      {step.output && (
                        <div className="mb-3">
                          <p className="text-xs font-semibold text-foreground mb-2">
                            Output
                          </p>
                          <pre className="text-xs bg-muted p-2 rounded overflow-auto max-h-40 text-muted-foreground">
                            {JSON.stringify(step.output, null, 2)}
                          </pre>
                        </div>
                      )}

                      {step.error && (
                        <div>
                          <p className="text-xs font-semibold text-red-600 mb-2">
                            Error
                          </p>
                          <p className="text-xs text-red-500 bg-red-50 p-2 rounded">
                            {step.error}
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Empty State */}
        {steps.length === 0 && (
          <Card className="p-8 text-center text-muted-foreground">
            <Zap className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No execution steps yet</p>
            <p className="text-xs mt-1">Add actions to your workflow to preview</p>
          </Card>
        )}
      </div>
    </div>
  );
}
