import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface WorkflowCanvasProps {
  trigger: { type: string; config: Record<string, unknown> };
  actions: Array<{
    id: string;
    type: string;
    integrationId: number;
    config: Record<string, unknown>;
  }>;
  onTriggerClick: () => void;
  onActionClick: (actionId: string) => void;
  onActionRemove: (actionId: string) => void;
  actionTypes: Array<{
    id: string;
    name: string;
    icon: string;
  }>;
}

export default function WorkflowCanvas({
  trigger,
  actions,
  onTriggerClick,
  onActionClick,
  onActionRemove,
  actionTypes,
}: WorkflowCanvasProps) {
  const getTriggerIcon = () => {
    switch (trigger.type) {
      case "schedule":
        return "📅";
      case "webhook":
        return "🌐";
      case "event":
        return "🔔";
      case "manual":
        return "▶️";
      default:
        return "⚙️";
    }
  };

  const getActionIcon = (actionType: string) => {
    const type = actionTypes.find((t) => t.id === actionType);
    return type?.icon || "⚡";
  };

  return (
    <Card className="p-8 bg-white min-h-96 relative overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="w-full h-full"
          style={{
            backgroundImage:
              "linear-gradient(0deg, transparent 24%, rgba(0, 0, 0, 0.05) 25%, rgba(0, 0, 0, 0.05) 26%, transparent 27%, transparent 74%, rgba(0, 0, 0, 0.05) 75%, rgba(0, 0, 0, 0.05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(0, 0, 0, 0.05) 25%, rgba(0, 0, 0, 0.05) 26%, transparent 27%, transparent 74%, rgba(0, 0, 0, 0.05) 75%, rgba(0, 0, 0, 0.05) 76%, transparent 77%, transparent)",
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Trigger Node */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center mb-8"
        >
          <button
            onClick={onTriggerClick}
            className="group relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-primary/20 rounded-2xl blur-lg group-hover:blur-xl transition-all" />
            <div className="relative bg-white border-2 border-accent rounded-2xl px-6 py-4 hover:border-accent/80 hover:shadow-lg transition-all">
              <div className="text-3xl mb-2">{getTriggerIcon()}</div>
              <div className="font-semibold text-foreground capitalize">
                {trigger.type}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Click to configure
              </div>
            </div>
          </button>
        </motion.div>

        {/* Arrow Down */}
        {actions.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-center mb-8"
          >
            <div className="text-2xl text-accent animate-bounce">↓</div>
          </motion.div>
        )}

        {/* Action Nodes */}
        <AnimatePresence>
          <div className="space-y-6">
            {actions.map((action, index) => (
              <motion.div
                key={action.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.1 }}
                className="flex justify-center"
              >
                <div className="group relative w-full max-w-xs">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl blur-lg group-hover:blur-xl transition-all" />
                  <button
                    onClick={() => onActionClick(action.id)}
                    className="relative w-full bg-white border-2 border-primary/30 rounded-xl px-6 py-4 hover:border-primary hover:shadow-lg transition-all text-left"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="text-2xl mb-2">
                          {getActionIcon(action.type)}
                        </div>
                        <div className="font-semibold text-foreground capitalize">
                          {action.type.replace(/_/g, " ")}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Click to edit configuration
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onActionRemove(action.id);
                        }}
                        className="p-2 rounded-lg hover:bg-red-50 text-red-500 hover:text-red-600 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </button>

                  {/* Arrow Down Between Actions */}
                  {index < actions.length - 1 && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex justify-center mt-6"
                    >
                      <div className="text-2xl text-primary/60 animate-bounce">
                        ↓
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </AnimatePresence>

        {/* Empty State */}
        {actions.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="text-5xl mb-4">🔗</div>
            <p className="text-muted-foreground mb-4">
              No actions configured yet
            </p>
            <p className="text-sm text-muted-foreground">
              Add actions from the sidebar to build your workflow
            </p>
          </motion.div>
        )}
      </div>
    </Card>
  );
}
