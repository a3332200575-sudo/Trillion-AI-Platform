import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { X } from "lucide-react";
import { useState } from "react";

interface TriggerPanelProps {
  trigger: { type: string; config: Record<string, unknown> };
  triggerTypes: Array<{
    id: string;
    name: string;
    description: string;
    inputs: Array<{
      key: string;
      label: string;
      type: string;
      placeholder?: string;
      required?: boolean;
    }>;
  }>;
  onUpdate: (triggerType: string, config: Record<string, unknown>) => void;
  onClose: () => void;
}

export default function TriggerPanel({
  trigger,
  triggerTypes,
  onUpdate,
  onClose,
}: TriggerPanelProps) {
  const [selectedType, setSelectedType] = useState(trigger.type);
  const [config, setConfig] = useState<Record<string, unknown>>(trigger.config);

  const currentTriggerType = triggerTypes.find((t) => t.id === selectedType);

  const handleConfigChange = (key: string, value: unknown) => {
    setConfig((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    onUpdate(selectedType, config);
    onClose();
  };

  return (
    <Card className="p-4 border-2 border-accent bg-gradient-to-br from-accent/5 to-transparent">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Configure Trigger</h3>
        <button
          onClick={onClose}
          className="p-1 hover:bg-muted rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Trigger Type Selection */}
      <div className="space-y-2 mb-4">
        <label className="text-xs font-medium text-muted-foreground uppercase">
          Trigger Type
        </label>
        <div className="space-y-2">
          {triggerTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => {
                setSelectedType(type.id);
                setConfig({});
              }}
              className={`w-full text-left p-2 rounded-lg border transition-all ${
                selectedType === type.id
                  ? "border-accent bg-accent/10"
                  : "border-border hover:border-accent/50"
              }`}
            >
              <div className="font-medium text-sm text-foreground">
                {type.name}
              </div>
              <div className="text-xs text-muted-foreground">
                {type.description}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Configuration Inputs */}
      {currentTriggerType && currentTriggerType.inputs.length > 0 && (
        <div className="space-y-3 mb-4 pb-4 border-b border-border">
          <label className="text-xs font-medium text-muted-foreground uppercase">
            Configuration
          </label>
          {currentTriggerType.inputs.map((input) => (
            <div key={input.key}>
              <label className="text-xs font-medium text-foreground mb-1 block">
                {input.label}
                {input.required && <span className="text-red-500">*</span>}
              </label>
              {input.type === "textarea" ? (
                <Textarea
                  value={(config[input.key] as string) || ""}
                  onChange={(e) => handleConfigChange(input.key, e.target.value)}
                  placeholder={input.placeholder}
                  className="text-sm"
                  rows={3}
                />
              ) : (
                <Input
                  type={input.type}
                  value={(config[input.key] as string) || ""}
                  onChange={(e) => handleConfigChange(input.key, e.target.value)}
                  placeholder={input.placeholder}
                  className="text-sm"
                />
              )}
            </div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button
          size="sm"
          className="flex-1 bg-accent hover:bg-accent/90 text-primary font-semibold"
          onClick={handleSave}
        >
          Apply
        </Button>
        <Button size="sm" variant="outline" className="flex-1" onClick={onClose}>
          Cancel
        </Button>
      </div>
    </Card>
  );
}
