import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Star, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  icon: string;
  tags: string[];
  uses: number;
  rating: number;
  actions: Array<{
    type: string;
    config: Record<string, unknown>;
  }>;
  trigger: {
    type: string;
    config: Record<string, unknown>;
  };
}

interface TemplateLibraryProps {
  templates: WorkflowTemplate[];
  onUseTemplate: (template: WorkflowTemplate) => void;
}

const DIFFICULTY_COLORS = {
  beginner: "bg-green-100 text-green-800",
  intermediate: "bg-yellow-100 text-yellow-800",
  advanced: "bg-red-100 text-red-800",
};

export default function TemplateLibrary({
  templates,
  onUseTemplate,
}: TemplateLibraryProps) {
  const categories = Array.from(new Set(templates.map((t) => t.category)));

  return (
    <div className="space-y-6">
      {categories.map((category) => {
        const categoryTemplates = templates.filter((t) => t.category === category);

        return (
          <motion.div
            key={category}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h3 className="text-lg font-semibold text-foreground mb-4 capitalize">
              {category}
            </h3>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categoryTemplates.map((template) => (
                <motion.div
                  key={template.id}
                  whileHover={{ translateY: -4 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="p-4 h-full flex flex-col hover:shadow-lg transition-shadow">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="text-3xl">{template.icon}</div>
                      <div className="flex gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs font-medium text-foreground">
                          {template.rating}
                        </span>
                      </div>
                    </div>

                    {/* Title & Description */}
                    <h4 className="font-semibold text-foreground mb-1">
                      {template.name}
                    </h4>
                    <p className="text-xs text-muted-foreground mb-3 flex-1">
                      {template.description}
                    </p>

                    {/* Difficulty & Stats */}
                    <div className="flex gap-2 mb-3 flex-wrap">
                      <Badge
                        className={`text-xs ${
                          DIFFICULTY_COLORS[template.difficulty]
                        }`}
                      >
                        {template.difficulty}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        {template.uses} uses
                      </Badge>
                    </div>

                    {/* Tags */}
                    <div className="flex gap-1 mb-4 flex-wrap">
                      {template.tags.slice(0, 2).map((tag) => (
                        <span
                          key={tag}
                          className="text-xs px-2 py-1 rounded-full bg-accent/10 text-accent"
                        >
                          {tag}
                        </span>
                      ))}
                      {template.tags.length > 2 && (
                        <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                          +{template.tags.length - 2}
                        </span>
                      )}
                    </div>

                    {/* Action Count */}
                    <p className="text-xs text-muted-foreground mb-4">
                      {template.actions.length} actions
                    </p>

                    {/* Use Button */}
                    <Button
                      size="sm"
                      className="w-full bg-accent hover:bg-accent/90 text-primary font-semibold"
                      onClick={() => onUseTemplate(template)}
                    >
                      <Copy className="w-3 h-3 mr-2" />
                      Use Template
                    </Button>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
