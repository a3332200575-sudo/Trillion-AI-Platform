import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Sparkles,
  Send,
  Loader,
  Copy,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { trpc } from "@/lib/trpc";

interface AIPromptInputProps {
  onGenerate: (prompt: string, workflow: any) => void;
  isLoading?: boolean;
}

interface StreamingMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

export default function AIPromptInput({
  onGenerate,
  isLoading = false,
}: AIPromptInputProps) {
  const [prompt, setPrompt] = useState("");
  const [messages, setMessages] = useState<StreamingMessage[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [generatedWorkflow, setGeneratedWorkflow] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const generateWorkflow = trpc.ai.generateWorkflow.useMutation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingContent]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    // Add user message
    const userMessage: StreamingMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: prompt,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setPrompt("");
    setIsGenerating(true);
    setStreamingContent("");

    try {
      const result = await generateWorkflow.mutateAsync({ prompt });
      if (!result.success || !result.workflow) {
        throw new Error(result.error || "The AI could not generate a workflow");
      }

      const workflowDescription = result.rawDescription || result.workflow.description;
      setGeneratedWorkflow(result.workflow);

      // Stream the response
      let currentContent = "";
      for (let i = 0; i < workflowDescription.length; i++) {
        await new Promise((resolve) => setTimeout(resolve, 20));
        currentContent += workflowDescription[i];
        setStreamingContent(currentContent);
      }

      // Add assistant message
      const assistantMessage: StreamingMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: workflowDescription,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      setStreamingContent("");
    } catch (error) {
      const errorMessage: StreamingMessage = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: `Error: ${(error as Error).message}`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateWorkflow = () => {
    const lastAssistantMessage = messages.find(
      (m) => m.role === "assistant"
    );
    const lastUserMessage = [...messages].reverse().find((m) => m.role === "user");
    if (lastAssistantMessage && generatedWorkflow) {
      onGenerate(lastUserMessage?.content || "", generatedWorkflow);
      setIsOpen(false);
      setMessages([]);
      setGeneratedWorkflow(null);
    }
  };

  return (
    <div className="relative">
      {/* Floating Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-50 w-14 h-14 rounded-full bg-gradient-to-r from-accent to-blue-500 text-white shadow-lg hover:shadow-xl transition-shadow flex items-center justify-center"
      >
        <Sparkles className="w-6 h-6" />
      </motion.button>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed bottom-24 right-8 z-50 w-96 max-h-96 rounded-lg shadow-2xl overflow-hidden"
          >
            <Card className="h-full flex flex-col bg-slate-800 border-slate-700">
              {/* Header */}
              <div className="bg-gradient-to-r from-accent to-blue-500 p-4 text-white">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    <h3 className="font-semibold">AI Workflow Generator</h3>
                  </div>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="text-white/80 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
                <p className="text-sm text-white/80 mt-1">
                  Describe your workflow in natural language
                </p>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.length === 0 && !streamingContent && (
                  <div className="text-center text-slate-400 text-sm py-8">
                    <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>Describe what your workflow should do</p>
                    <p className="text-xs mt-2">
                      e.g., "Send daily email reports" or "Sync data to database"
                    </p>
                  </div>
                )}

                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-xs p-3 rounded-lg text-sm ${
                        message.role === "user"
                          ? "bg-accent text-primary rounded-br-none"
                          : "bg-slate-700 text-slate-100 rounded-bl-none"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{message.content}</p>
                      <p className="text-xs opacity-60 mt-1">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </motion.div>
                ))}

                {streamingContent && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-start"
                  >
                    <div className="max-w-xs p-3 rounded-lg text-sm bg-slate-700 text-slate-100 rounded-bl-none">
                      <p className="whitespace-pre-wrap">{streamingContent}</p>
                      <motion.span
                        animate={{ opacity: [0.5, 1] }}
                        transition={{ duration: 0.8, repeat: Infinity }}
                        className="inline-block ml-1"
                      >
                        ▌
                      </motion.span>
                    </div>
                  </motion.div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Actions */}
              {messages.length > 0 && !isGenerating && generatedWorkflow && (
                <div className="border-t border-slate-700 p-3 bg-slate-800/50 flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1 bg-accent hover:bg-accent/90 text-primary font-semibold"
                    onClick={handleGenerateWorkflow}
                  >
                    <Sparkles className="w-3 h-3 mr-1" />
                    Generate
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    onClick={() => {
                      setMessages([]);
                      setStreamingContent("");
                    }}
                  >
                    <RotateCcw className="w-3 h-3" />
                  </Button>
                </div>
              )}

              {/* Input */}
              <form onSubmit={handleSubmit} className="border-t border-slate-700 p-3 bg-slate-800/50">
                <div className="flex gap-2">
                  <Textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Describe your workflow..."
                    className="bg-slate-700 border-slate-600 text-white text-sm resize-none"
                    rows={2}
                    disabled={isGenerating}
                  />
                  <Button
                    type="submit"
                    size="sm"
                    disabled={!prompt.trim() || isGenerating}
                    className="bg-accent hover:bg-accent/90 text-primary"
                  >
                    {isGenerating ? (
                      <Loader className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </form>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
