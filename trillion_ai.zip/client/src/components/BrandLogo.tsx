/**
 * BrandLogo - TrillionAI circuit-node triangle logo
 * Represents autonomous AI agents and interconnected systems
 */
export function BrandLogo({ className = "w-10 h-10" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Triangle outline */}
      <path
        d="M20 4 L36 32 L4 32 Z"
        stroke="url(#logoGradient)"
        strokeWidth="1.5"
        fill="none"
      />

      {/* Node circles */}
      <circle cx="20" cy="8" r="2.5" fill="url(#logoGradient)" />
      <circle cx="32" cy="28" r="2.5" fill="url(#logoGradient)" />
      <circle cx="8" cy="28" r="2.5" fill="url(#logoGradient)" />

      {/* Center node */}
      <circle cx="20" cy="22" r="3" fill="url(#logoGradient)" />

      {/* Connection lines */}
      <line x1="20" y1="8" x2="20" y2="22" stroke="url(#logoGradient)" strokeWidth="1" opacity="0.6" />
      <line x1="20" y1="22" x2="32" y2="28" stroke="url(#logoGradient)" strokeWidth="1" opacity="0.6" />
      <line x1="20" y1="22" x2="8" y2="28" stroke="url(#logoGradient)" strokeWidth="1" opacity="0.6" />

      {/* Gradient definition */}
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1a1f3a" />
          <stop offset="100%" stopColor="#00d9ff" />
        </linearGradient>
      </defs>
    </svg>
  );
}
