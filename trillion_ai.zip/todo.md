
## Collaboration Reporting Controls
- [x] Add searchable IANA timezone selectors with regional optgroups for workspace and personal settings
- [x] Add dedicated immutable workspace timezone-policy history with actor, timezone, policy, and timestamp details
- [x] Add shared team reporting presets with custom date ranges and timezone context
- [x] Add protected create/list/delete preset procedures with role checks and audit events
- [x] Add preset application controls to the activity log and preserve preset timezone semantics
- [x] Apply migration 0013_wakeful_rictor.sql for shared reporting presets
- [x] Run TypeScript, 41/41 tests, production build, WebDev diagnostics, and browser console validation
