ALTER TABLE `workspaceMembers` ADD `inviteToken` varchar(96);--> statement-breakpoint
ALTER TABLE `workspaceMembers` ADD CONSTRAINT `workspaceMembers_inviteToken_unique` UNIQUE(`inviteToken`);