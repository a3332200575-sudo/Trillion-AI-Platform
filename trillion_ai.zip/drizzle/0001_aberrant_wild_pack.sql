CREATE TABLE `workflowVersions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workflowId` int NOT NULL,
	`userId` int NOT NULL,
	`version` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`trigger` enum('schedule','webhook','event','manual') NOT NULL,
	`triggerConfig` json,
	`actions` json,
	`changeSummary` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workflowVersions_id` PRIMARY KEY(`id`)
);
