CREATE TABLE `workspaceCommentMentions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`commentId` int NOT NULL,
	`mentionedUserId` int NOT NULL,
	`mentionedEmail` varchar(320) NOT NULL,
	`notifiedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workspaceCommentMentions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `workspaceActivity` ADD `workflowId` int;