CREATE TABLE `workflowComments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`workflowId` int NOT NULL,
	`authorUserId` int NOT NULL,
	`body` text NOT NULL,
	`resolved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `workflowComments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workspaceActivity` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`actorUserId` int,
	`eventType` varchar(80) NOT NULL,
	`entityType` varchar(40) NOT NULL,
	`entityId` int,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workspaceActivity_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workspacePresence` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workspaceId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('active','away') NOT NULL DEFAULT 'active',
	`currentWorkflowId` int,
	`currentPage` varchar(120),
	`lastSeenAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workspacePresence_id` PRIMARY KEY(`id`),
	CONSTRAINT `workspacePresence_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `workspaceMembers` ADD `inviteExpiresAt` timestamp;