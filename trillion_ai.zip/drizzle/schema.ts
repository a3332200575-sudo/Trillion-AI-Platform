import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Autonomous Agents - Represents AI agents that execute integrations
 */
export const agents = mysqlTable("agents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["fintech", "supply_chain", "healthcare", "ecommerce", "saas"]).notNull(),
  status: mysqlEnum("status", ["active", "paused", "error"]).default("active").notNull(),
  config: json("config").$type<Record<string, unknown>>(),
  performanceMetrics: json("performanceMetrics").$type<{
    executionsCount: number;
    successRate: number;
    averageExecutionTime: number;
    totalRevenue: number;
  }>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = typeof agents.$inferInsert;

/**
 * Integrations - Represents connected services (APIs, databases, platforms)
 */
export const integrations = mysqlTable("integrations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  agentId: int("agentId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  credentials: json("credentials").$type<Record<string, unknown>>(),
  status: mysqlEnum("status", ["connected", "disconnected", "error"]).default("connected").notNull(),
  lastSyncAt: timestamp("lastSyncAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = typeof integrations.$inferInsert;

/**
 * Workflows - Automation workflows executed by agents
 */
export const workflows = mysqlTable("workflows", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  agentId: int("agentId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  trigger: mysqlEnum("trigger", ["schedule", "webhook", "event", "manual"]).notNull(),
  triggerConfig: json("triggerConfig").$type<Record<string, unknown>>(),
  actions: json("actions").$type<Array<{
    type: string;
    integrationId: number;
    config: Record<string, unknown>;
  }>>(),
  retryPolicy: json("retryPolicy").$type<{
    maxAttempts: number;
    backoffMs: number;
    maxBackoffMs: number;
  }>(),
  isActive: boolean("isActive").default(true).notNull(),
  executionCount: int("executionCount").default(0).notNull(),
  successCount: int("successCount").default(0).notNull(),
  lastExecutedAt: timestamp("lastExecutedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Workflow = typeof workflows.$inferSelect;
export type InsertWorkflow = typeof workflows.$inferInsert;

/**
 * Workflow Versions - immutable snapshots created on workflow saves
 */
export const workflowVersions = mysqlTable("workflowVersions", {
  id: int("id").autoincrement().primaryKey(),
  workflowId: int("workflowId").notNull(),
  userId: int("userId").notNull(),
  version: int("version").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  trigger: mysqlEnum("trigger", ["schedule", "webhook", "event", "manual"]).notNull(),
  triggerConfig: json("triggerConfig").$type<Record<string, unknown>>(),
  actions: json("actions").$type<Array<{
    type: string;
    integrationId: number;
    config: Record<string, unknown>;
  }>>(),
  retryPolicy: json("retryPolicy").$type<{
    maxAttempts: number;
    backoffMs: number;
    maxBackoffMs: number;
  }>(),
  changeSummary: varchar("changeSummary", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WorkflowVersion = typeof workflowVersions.$inferSelect;
export type InsertWorkflowVersion = typeof workflowVersions.$inferInsert;

/**
 * Webhooks - signed inbound endpoints connected to workflows
 */
export const webhooks = mysqlTable("webhooks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  workflowId: int("workflowId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  endpointToken: varchar("endpointToken", { length: 96 }).notNull().unique(),
  signingSecret: varchar("signingSecret", { length: 128 }).notNull(),
  status: mysqlEnum("status", ["active", "disabled"]).default("active").notNull(),
  lastTriggeredAt: timestamp("lastTriggeredAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Webhook = typeof webhooks.$inferSelect;
export type InsertWebhook = typeof webhooks.$inferInsert;

/**
 * Webhook Deliveries - audit trail for inbound requests
 */
export const webhookDeliveries = mysqlTable("webhookDeliveries", {
  id: int("id").autoincrement().primaryKey(),
  webhookId: int("webhookId").notNull(),
  userId: int("userId").notNull(),
  status: mysqlEnum("status", ["accepted", "rejected", "failed"]).notNull(),
  requestHeaders: json("requestHeaders").$type<Record<string, string>>(),
  requestBody: json("requestBody").$type<Record<string, unknown>>(),
  responseStatus: int("responseStatus"),
  executionLogId: int("executionLogId"),
  error: text("error"),
  durationMs: int("durationMs"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WebhookDelivery = typeof webhookDeliveries.$inferSelect;
export type InsertWebhookDelivery = typeof webhookDeliveries.$inferInsert;

/**
 * Execution Logs - Track agent executions and results
 */
export const executionLogs = mysqlTable("executionLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  agentId: int("agentId").notNull(),
  workflowId: int("workflowId"),
  status: mysqlEnum("status", ["success", "failed", "pending"]).notNull(),
  input: json("input").$type<Record<string, unknown>>(),
  output: json("output").$type<Record<string, unknown>>(),
  error: text("error"),
  executionTime: int("executionTime"),
  attempts: int("attempts").default(1).notNull(),
  replayedFromId: int("replayedFromId"),
  revenue: decimal("revenue", { precision: 15, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ExecutionLog = typeof executionLogs.$inferSelect;
export type InsertExecutionLog = typeof executionLogs.$inferInsert;

/**
 * Pricing Plans - Subscription tiers
 */
export const pricingPlans = mysqlTable("pricingPlans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  tier: mysqlEnum("tier", ["starter", "professional", "enterprise"]).notNull(),
  monthlyPrice: decimal("monthlyPrice", { precision: 10, scale: 2 }).notNull(),
  maxAgents: int("maxAgents").notNull(),
  maxIntegrations: int("maxIntegrations").notNull(),
  maxWorkflows: int("maxWorkflows").notNull(),
  features: json("features").$type<string[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PricingPlan = typeof pricingPlans.$inferSelect;
export type InsertPricingPlan = typeof pricingPlans.$inferInsert;

/**
 * User Subscriptions - Track user's active plan
 */
export const userSubscriptions = mysqlTable("userSubscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  planId: int("planId").notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired"]).default("active").notNull(),
  currentPeriodStart: timestamp("currentPeriodStart").notNull(),
  currentPeriodEnd: timestamp("currentPeriodEnd").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = typeof userSubscriptions.$inferInsert;

/**
 * Collaboration workspaces - one personal workspace is created on demand for
 * each owner and can be shared with additional authenticated users.
 */
export const workspaces = mysqlTable("workspaces", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  timezonePolicy: mysqlEnum("timezonePolicy", ["member", "workspace"]).default("member").notNull(),
  timezone: varchar("timezone", { length: 120 }).default("UTC").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Workspace = typeof workspaces.$inferSelect;
export type InsertWorkspace = typeof workspaces.$inferInsert;

/**
 * Workspace membership and invitation state. Pending rows may not have a
 * userId yet; accepting an invite binds them to the authenticated user.
 */
export const workspaceMembers = mysqlTable("workspaceMembers", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  userId: int("userId"),
  email: varchar("email", { length: 320 }).notNull(),
  timezoneOverride: varchar("timezoneOverride", { length: 120 }),
  inviteToken: varchar("inviteToken", { length: 96 }).unique(),
  inviteExpiresAt: timestamp("inviteExpiresAt"),
  role: mysqlEnum("role", ["owner", "editor", "viewer"]).default("viewer").notNull(),
  status: mysqlEnum("status", ["active", "pending", "revoked"]).default("pending").notNull(),
  invitedBy: int("invitedBy").notNull(),
  inviteSentAt: timestamp("inviteSentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WorkspaceMember = typeof workspaceMembers.$inferSelect;
export type InsertWorkspaceMember = typeof workspaceMembers.$inferInsert;

/** Workflow-level sharing grants a workspace viewer or editor access. */
export const workflowShares = mysqlTable("workflowShares", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  workflowId: int("workflowId").notNull(),
  permission: mysqlEnum("permission", ["viewer", "editor"]).default("viewer").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WorkflowShare = typeof workflowShares.$inferSelect;
export type InsertWorkflowShare = typeof workflowShares.$inferInsert;

/** Immutable audit events for membership, invitations, and workflow sharing. */
export const workspaceActivity = mysqlTable("workspaceActivity", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  actorUserId: int("actorUserId"),
  eventType: varchar("eventType", { length: 80 }).notNull(),
  entityType: varchar("entityType", { length: 40 }).notNull(),
  entityId: int("entityId"),
  workflowId: int("workflowId"),
  metadata: json("metadata").$type<Record<string, unknown>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WorkspaceActivity = typeof workspaceActivity.$inferSelect;
export type InsertWorkspaceActivity = typeof workspaceActivity.$inferInsert;

/** Shared date-range presets that workspace members can reuse for reporting. */
export const workspaceReportingPresets = mysqlTable("workspaceReportingPresets", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  startDate: varchar("startDate", { length: 10 }).notNull(),
  endDate: varchar("endDate", { length: 10 }).notNull(),
  timezone: varchar("timezone", { length: 120 }).notNull(),
  createdBy: int("createdBy").notNull(),
  scheduleCronTaskUid: varchar("scheduleCronTaskUid", { length: 65 }),
  scheduleCron: varchar("scheduleCron", { length: 80 }),
  scheduleDeliveryEmail: varchar("scheduleDeliveryEmail", { length: 320 }),
  scheduleEnabled: boolean("scheduleEnabled").default(false).notNull(),
  lastDeliveredAt: timestamp("lastDeliveredAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WorkspaceReportingPreset = typeof workspaceReportingPresets.$inferSelect;
export type InsertWorkspaceReportingPreset = typeof workspaceReportingPresets.$inferInsert;

/** Mention recipients created from workflow comments; notifiedAt is set after delivery succeeds. */
export const workspaceCommentMentions = mysqlTable("workspaceCommentMentions", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  commentId: int("commentId").notNull(),
  mentionedUserId: int("mentionedUserId").notNull(),
  mentionedEmail: varchar("mentionedEmail", { length: 320 }).notNull(),
  notifiedAt: timestamp("notifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WorkspaceCommentMention = typeof workspaceCommentMentions.$inferSelect;
export type InsertWorkspaceCommentMention = typeof workspaceCommentMentions.$inferInsert;

/** Latest heartbeat per authenticated user; clients poll this lightweight table. */
export const workspacePresence = mysqlTable("workspacePresence", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  userId: int("userId").notNull().unique(),
  status: mysqlEnum("status", ["active", "away"]).default("active").notNull(),
  currentWorkflowId: int("currentWorkflowId"),
  currentPage: varchar("currentPage", { length: 120 }),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
});

export type WorkspacePresence = typeof workspacePresence.$inferSelect;
export type InsertWorkspacePresence = typeof workspacePresence.$inferInsert;

/** Comments are scoped to a shared workflow and inherit workspace membership. */
export const workflowComments = mysqlTable("workflowComments", {
  id: int("id").autoincrement().primaryKey(),
  workspaceId: int("workspaceId").notNull(),
  workflowId: int("workflowId").notNull(),
  authorUserId: int("authorUserId").notNull(),
  body: text("body").notNull(),
  resolved: boolean("resolved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WorkflowComment = typeof workflowComments.$inferSelect;
export type InsertWorkflowComment = typeof workflowComments.$inferInsert;
