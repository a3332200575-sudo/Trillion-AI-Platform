ALTER TABLE `workspaceReportingPresets` ADD `scheduleCronTaskUid` varchar(65);--> statement-breakpoint
ALTER TABLE `workspaceReportingPresets` ADD `scheduleCron` varchar(80);--> statement-breakpoint
ALTER TABLE `workspaceReportingPresets` ADD `scheduleDeliveryEmail` varchar(320);--> statement-breakpoint
ALTER TABLE `workspaceReportingPresets` ADD `scheduleEnabled` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `workspaceReportingPresets` ADD `lastDeliveredAt` timestamp;