ALTER TABLE `workspaceMembers` ADD `timezoneOverride` varchar(120);--> statement-breakpoint
ALTER TABLE `workspaces` ADD `timezonePolicy` enum('member','workspace') DEFAULT 'member' NOT NULL;--> statement-breakpoint
ALTER TABLE `workspaces` ADD `timezone` varchar(120) DEFAULT 'UTC' NOT NULL;