CREATE TABLE `webhookDeliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`webhookId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('accepted','rejected','failed') NOT NULL,
	`requestHeaders` json,
	`requestBody` json,
	`responseStatus` int,
	`error` text,
	`durationMs` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `webhookDeliveries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `webhooks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`workflowId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`endpointToken` varchar(96) NOT NULL,
	`secretHash` varchar(128) NOT NULL,
	`status` enum('active','disabled') NOT NULL DEFAULT 'active',
	`lastTriggeredAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `webhooks_id` PRIMARY KEY(`id`),
	CONSTRAINT `webhooks_endpointToken_unique` UNIQUE(`endpointToken`)
);
