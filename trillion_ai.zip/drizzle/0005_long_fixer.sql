ALTER TABLE `executionLogs` ADD `attempts` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `executionLogs` ADD `replayedFromId` int;--> statement-breakpoint
ALTER TABLE `workflows` ADD `retryPolicy` json;